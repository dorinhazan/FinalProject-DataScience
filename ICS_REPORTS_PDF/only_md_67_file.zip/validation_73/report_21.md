![](_page_0_Picture_2.jpeg)

O

#### RANSOMWARE

# Born This Way? Origins of LockerGoga

டு 10 min read

#### RELATED PRODUCTS

![](_page_0_Picture_7.jpeg)

This site uses cookies essential to its operation, for analytics, and for personalized content and ads. By continuing to browse this site, you acknowledge the use of cookies. Privacy statement

Manage My Cookie Settings

![](_page_1_Picture_0.jpeg)

4 paloalto" | 7 UNIT 42"

# Threat insights that matter.

Trusted expertise from leaders in incident response.

![](_page_1_Picture_4.jpeg)

# Table of Contents

Command Line

Description

-f

-

Log: Creates a log file off the root drive named cl.log.

File: Used to encrypt a single file.

Table 1. Supported command line arguments

# Encryption

LockerGoga uses the Cryptopp library to implementing RSA from scratch would be very time consuming and error prone. To encrypt files, (Strong RSA) RSA-OAEP MGF1(SHA-1) is used. The RSA public key found in this sample is:

| 000000000 |       |       |       |    | 4D 49 47 64 4D 41 30 47 |  |       |       |  | 43 53 71 47 53 49 62 33 |    |                         | MIGdMA0GCSqGSIb3  |
|-----------|-------|-------|-------|----|-------------------------|--|-------|-------|--|-------------------------|----|-------------------------|-------------------|
| 00000016  | ਧੇ ਪੈ |       | 51 45 |    | 42 41 51 55 41          |  | ব 1   |       |  | 34 47 4C 41 44 43 42    |    |                         | DQEBAQUAA4GLADCB  |
| 0000032   |       |       |       |    | 68 77 4B 42 67 51 43 46 |  |       |       |  | 66 33 43 54 59 79 41 79 |    |                         | hwKBgQCFf3CTYyAy  |
| 00000048  |       |       |       |    | 6F 79 5A 71 52 33 6E 48 |  | 63    |       |  | 4C 4A 2B 49 2F 71 69    |    |                         | oyZqR3nHcLJ+I/qi  |
| 00000064  |       |       |       |    | 2F 50 57 77 57 54 75 6C |  |       |       |  | 20 6C 4D 69 4E 32 54 47 |    |                         | /PWwWTul IMiN2TG  |
| 00000080  | 4 D   | 41    |       |    | 4D 62 34 39 75 58       |  | 51    |       |  | 32 79 43 34 4D 5A 76    |    |                         | MAMb49uXQ2yC4MZv  |
| 00000096  |       |       |       |    | 5A 76 4B 53 50 55 44 6F |  | 33    |       |  | 61 4D 67 5A 4A 71 30    |    |                         | ZvKSPUDo3aMgZJq0  |
| 00000112  |       |       |       |    | 78 75 52 53 42 34 58 6F |  |       |       |  | 73 6D 73 30 5A 39 51 4B |    |                         | xuRSB4Xosms0Z9QK  |
| 0000128   |       | 70 76 | 47    | 6C | 6A 4E 48 36             |  | 79    | 34    |  | 50 59 4E 39             | 38 | 2F                      | pvG1jNH6y4PYN98 / |
| 00000144  |       |       |       |    | 76 20 79 31 7A 4F 6B 34 |  |       | 70 45 |  | 69 53 68 43 32 49       |    |                         | v y1z0k4pEiShC2I  |
| 00000160  | 47    |       |       |    | 46 50 4A 32 47 71 33    |  |       |       |  | 4F 63 2B 41 78 4F 37    |    | 57                      | GFPJ2Gq30c+AxO7W  |
| 00000176  | 6E    | 2 F   |       |    | 62 42 76 35 34 32       |  |       |       |  | 52 51 30 67 50 55 77 7A |    |                         | o/bBv542RQ0qPUwz  |
| 00000192  | 79    |       |       |    | 54 53 66 71 6A 44 47    |  |       |       |  |                         |    | 35 33 35 73 38 57 73 76 | yTSfqjDG535s8Wsv  |
| 0000208   |       |       |       |    | 4B 73 79 77 49 42 45 51 |  | 3D 3D |       |  |                         |    |                         | KsywIBEQ==        |
|           |       |       |       |    |                         |  |       |       |  |                         |    |                         |                   |

Table 2. RSA Public key found in initial LockerGoga sample

Although RSA-OAEP MGF1 has features that make it more secure, the added computational overhead causes encryption to take longer and has difficulty handling large files. To mitigate this, the developers launch multiple child processes that work in parallel to maximize encryption speed. To overcome large files, the developers decided to encrypt chunks of a file every 80,000 bytes and skip the next 80,000 bytes of a file. Example:

#### Figure 1. Data encrypted in 80,000 byte chunks

Because of this, partial recovery of large files might be possible even without the decryption key.

Although the developers attempt to use a denylist of files and directories to skip, it was observed encrypting core Windows operating system files, which caused the operating system to become unstable and crash. This was observed when running the ransomware on a Windows 2012 machine.

# Early Development

Based on our analysis, we believe this variant is an early release of LockerGoga ransomware. The developers left behind command line parameters such as -r which allows the malware to run without encrypting anything. This can be used in conjunction with -1 (log) to test how the ransomware behaves. Both of these parameters are suggestive of an initial, or test, build. The -r specifically was not observed in later variants.

According to the Bleeping Computer report, the ransomware appeared to encrypt only the following specific file extensions: doc|dot|wbk|docx|dotx|docb|x1m|xlsx|xltx|x1sb|x1w|ppt|potx|potx|ppsx|s|dx|pdf.

Our analysis found that the malware does not use the code block that checks for specific file extensions. Instead, we observed that the malware encrypts all files except those in the denylist. It also has issues with large files, which is addressed in later variants.

# Development Cycle

Like other active software projects, the LockerGoga ransomware is under constant development with new variants being developed and used to attack victims. All these variants share similar characteristics and just like other professional development, each release contains improvements or new capabilities.

To counter this ongoing development cycle, security researchers have to focus on identifying new variants.

- · Ransomware note renamed from README NOW.txt to README LOCKED.TXT
- · Added the following command line parameters:

| Parameter | Description                       |
|-----------|-----------------------------------|
| T         | Inter process communication (IPC) |
| -S        | Slave (child process)             |
| -m        | Master Process                    |

- · Began using mutexes (example: SM-zzbdrimp) to identify processes for inter-process communication.
- Stopped using svchost|numeric value|exe as a process name and began using distinct hard-oded names for each sample.
- Uses undocumented Windows API calls (for example NtQuerySection)
- Changes administrator password to HuHuHUHoHo283283@dJD
- · Stopped creating a wipe file to erase free space and instead uses With command parameter /w to wipe free space on the host
- · Added importation of WS2 32.dll, possibly to support network communications
- · Changed the format and collection of data recorded in the log file
- · Updated encryption of files and directories. No longer encrypts all files on the host: instead targets specific file extensions and directories
- · Calls into Windows Restart Manager session for possible token elevation to overwrite trusted installer files
- · Uses the following digital signers:
	- ALISA LTD
	- KITTY'S LTD .
	- · MIKL LIMITED
- Logs off the current user
- · The inclusion of the word "Goga" in the binary and encrypted files

# Conclusion

LockerGoga's developers continue to add capabilities and launch new attacks. The addition of WS2 32.dll and use of undocumented Windows API calls indicates a level of sophistication beyond typical ransomware authors. The former could lead to the eventual inclusion of C2 communication or automated propagation, and the latter requires some working knowledge of Windows internals.

These features raise more questions about the actor's intent as ransomware is typically one of the least advanced forms of malware: Are they motivated by profits or something else? Has the motive change over time? Why would developers put such effort into their work only to partially encrypt files. Why do they include an email address and not seek payment through

WildFire properly identifies all of the malware samples listed in this report as malicious. Traps prevents execution of LockerGoga samples and AutoFocus customers can view LockerGoga samples using the LockerGoga tag.

Palo Alto Networks has shared our finding file samples and indicators of compromise, in this report with our fellow Cyber Threat Alliance members use this intelligence to rapidly deploy protections to their customers and to systematically disrupt malicious cyber actors. For more information on the Cyber Threat Alliance, visit www.cyberthreatalliance.org.

### Indicators of Compromise

#### LockerGoga Samples

ae7e9839b7fb750128147a9227d3733dde2faacd13c478e8f4d8d6c6c2fc1a55 f474a8c0f66dee3d504fff1e49342ee70dd6f402c3fa0687b15ea9d0dd15613a ffab69deafa647e2b54d8daf8c740b559a7982c3c7c1506ac6efc8de30c37fd5 c1670e190409619b5a541706976e5a649bef75c75b4b82caf00e9d85afc91881 65d5dd067e5550867b532f4e52af47b320bd31bc906d7bf5db889d0ff3f73041 31fdce53ee34dbc8e7a9f57b30a0fbb416ab1b3e0c145edd28b65bd6794047c1 32d959169ab8ad7e9d4bd046cdb585036c71380d9c45e7bb9513935cd1e225b5 e00a36f4295bb3ba17d36d75ee27f7d2c20646b6e0352e6d765b7ac738ebe5ee 6d8f1a20dc0b67eb1c3393c6c7fc859f99a12abbca9c45dcbc0efd4dc712fb7c 79c11575f0495a3daaf93392bc8134c652360c5561e6f32d002209bc41471a07 050b4028b76cd907aabce3d07ebd9f38e56c48c991378d1c65442f9f5628aa9e 1f9b5fa30fd8835815270£7951£624698529332931725c1e17c41fd3dd040afe 276104ba67006897630a7bdaa22343944983d9397a538504935f2ec7ac10b534 88d149f3e47dc337695d76da52b25660e3a454768af0d7e59c913995af496a0f c97d9bbc80b573bdeeda3812f4d00e5183493dd0d5805e2508728f65977dda15 06e3924a863f12f57e903ae565052271740c4096bd4b47c38a9604951383bcd1 a845c34b0f675827444d6c502c0c461ed4445a00d83b31d5769646b88d7bbedf 7bcd69b3085126f7e97406889f78ab74e87230c11812b79406d723a80c08dd26 ba15c27f26265f4b063b65654e9d7c248d0d651919fafb68cb4765d1e057f93f eda26a1cd80aac1c42cdbba9af813d9c4bc81f6052080bc33435d1e076e75aa0 7852b47e7a9e3f792755395584c64dd81b68ab3cbcdf82f60e50dc5fa7385125 14e8a8095426245633cd6c3440afc5b29d0c8cd4acefd10e16f82eb3295077ca

6e69548b1ae61d951452b65db15716a5ee2f9373be05011e897c61118c239a77 8cfbd38855d2d6033847142fdfa74710b796daf465ab94216fbbbe85971aee29 bdf36127817413f625d2625d3133760af724d6ad2410bea7297ddc116abc268f 5b0b972713cd8611b04e4673676cdff70345ac7301b2c23173cdfeaff564225c c7a69dcfb6a3fe433a52a71d85a7e90df25b1db1bc843a541eb08ea2fd1052a4

# Appendix

The latest variant of LockerGoga uses memory mapped files to communicate between processes. To illustrate this, we captured the memory of a section created by a child process.

| 000000000 |     |          |                   | 02 00 00 00 00 00 00 00 00 |       |                                                  |  | 00 00 00 00 01 00 00    |       |       | () () |       |            |    |                  |  |
|-----------|-----|----------|-------------------|----------------------------|-------|--------------------------------------------------|--|-------------------------|-------|-------|-------|-------|------------|----|------------------|--|
| 00000016  |     | D0 02 01 |                   | 00 CC 02 01 00             |       |                                                  |  | C8 02 01 00             | 30 00 | 0 0   | 00    | Đ     | I          | ਜੇ | 0                |  |
| 0000032   |     | 80 02 01 |                   | 00 F8 FF OF 00             |       |                                                  |  | 00 00 00 00             | 00 00 | 0 0   | 00    | ಲ     | øy         |    |                  |  |
| 00000048  |     |          |                   | FF FF FF FF 00 00 00 00    |       |                                                  |  | 01 00 00 00             | 24 00 | 00    | 00    | vývýv |            |    | ನ್ನ              |  |
| 00000064  |     |          |                   | 20 00 00 00 1C 00 00 00    |       |                                                  |  | 00 00 00 00 01 00       |       | 00    | 0 0   |       |            |    |                  |  |
| 00000080  |     |          |                   | FC FF FF FF F8 FF FF FF    |       |                                                  |  | F4 FF 01 00 OB 20       |       | 00 CO |       |       | üýýýøýýýôý |    | Д                |  |
| 00000096  |     |          |                   | DE FF FF FF 01 00 00 00    |       |                                                  |  | 01 00 00 00 38 00       |       | 01    | () () | Бууу  |            |    | 8                |  |
| 00000112  |     |          |                   | 01 00 04 21 10 01 00 00    |       |                                                  |  | 00 00 00 00 00 7A 70    |       |       | 63    |       | -          |    | zpc              |  |
| 00000128  |     |          |                   | 55 48 4A 76 5A 33 4A 68    |       |                                                  |  | 62 53 42 47 61 57 78    |       |       | 6C    |       |            |    | UHJvZ3JhbSBGaWx1 |  |
| 00000144  |     |          | 63 31 78 57 54 58 |                            | 64 68 |                                                  |  | 63 6D 56 63 56 6B       |       | 31 33 |       |       |            |    | c1xWTXdhcmVcVk13 |  |
| 00000160  | 5 9 |          |                   | 58 4A 6C 49 46 52 76       |       |                                                  |  | 62 32 78 7A 58 47       |       | 64 73 |       |       |            |    | YXJlIFRvb2xzXGds |  |
| 00000176  |     |          | 61 57 49 74 4D 69 |                            | 34 77 |                                                  |  | 4C 6D 52 73 62 41 3D 3D |       |       |       |       |            |    | aWItMi4wLmRsbA== |  |
| 0000192   |     |          |                   | 64 48 42 6A 63 48 4D 75    |       |                                                  |  | 5A 47 78 73 63 6D       |       | 56 7A |       |       |            |    | dHBjcHMuZGxscmVz |  |
| 00000208  |     |          |                   | 65 43 35 6B 62 47 77 75    |       |                                                  |  | 62 58 56 70 4E 46       |       | 3 d   | 66    |       |            |    | eC5kbGwubXVpNF9f |  |
| 00000224  |     |          |                   | 4F 48 64 6C 61 33 6C 69    |       |                                                  |  | 4D 32 51 34 59 6D       |       | 4A 33 |       |       |            |    | OHdla3liM2Q4YmJ3 |  |
| 00000240  |     |          |                   | 5A 54 68 68 5A 44 46 68    |       |                                                  |  | 4E 7A 51 77 4C 54 52 68 |       |       |       |       |            |    | ZThhZDFhNzQwLTRh |  |
| 0000256   |     |          |                   | 4E 32 59 74 4E 47 45 78    |       |                                                  |  | 59 53 30 35 4F 54 45 78 |       |       |       |       |            |    | N2YtNGExYS050TEx |  |
| 00000272  |     |          |                   | 4C 54 51 79 4D 57 51 30    |       |                                                  |  | 4D 6A 49 34 4D 7A 52 6C |       |       |       |       |            |    | LTQyMWQ0MjI4MzR1 |  |
| 0000288   |     |          |                   | 5A 46 78 42 63 33 4E 6C    |       |                                                  |  | 64 48 4E 63 55 6D 56 7A |       |       |       |       |            |    | ZFxBc3NldHNcUmVz |  |
| 00000304  |     |          |                   |                            |       | 62 33 56 79 59 32 56 7A  58 46 4A 6C 63 58 56 70 |  |                         |       |       |       |       |            |    | b3VyY2VzXFJlcXVp |  |

|                                                                     |  |  |  |  |  |  |  | 00000384   62 6D 63 3D 62 53 31 31  62 6E 42 73 59 58 52 6C   bmc=b\$11bnBsYXR1 |
|---------------------------------------------------------------------|--|--|--|--|--|--|--|---------------------------------------------------------------------------------|
|                                                                     |  |  |  |  |  |  |  |                                                                                 |
| 00000400   5A 43 35 77 62 6D 63 3D  00 00 00 00 00 00 00   ZC5wbmc= |  |  |  |  |  |  |  |                                                                                 |

#### Table 3. Child process mapped file

The 1ª byte (02) instructs the master process the data below. The data is base64 encoded in three parts and decodes to the following:

Part 1:

Unknown value

Part 2:

```
tpcps.dllresx.dll.mui4 8wekyb3d8bbwe8ad1a740-4a7f-4a1a-9911-
421d422834ed\Assets\Resources\RequiredPrintCapabilities.xmlze=48 altform-unplated.png
```
Part 3:

m-unplated.png

Example of initial variant of LockerGoga running on a host:

Figure 2. Initial LockerGoga running

Initial LockerGoga Ransom Note:

Greetings!

There was a significant flaw in the security system of your company.

You should be thankful that the flaw was exploited by serious people and not some rookies.

They would have damaged all of your data by mistake or for fun.

To confirm our honest intentions.

Send us 2-3 different random files and you will get them decrypted.

It can be from different computers on your network to be sure that our decoder decrypts everything.

Sample files we unlock for free (files should not be related to any kind of backups).

We exclusively have decryption software for your situation

DO NOT RESET OR SHUTDOWN - files may be damaged. DO NOT RENAME the encrypted files. DO NOT MOVE the encrypted files. This may lead to the impossibility of recovery of the certain files.

To get information on the price of the decoder contact us at: CottleAkela@protonmail.com;QyavauZehyco1994@02.pl The payment has to be made in Bitcoins. The final price depends on how fast you contact us. As soon as we receive the payment you will get the decryption tool and instructions on how to improve your systems security

#### Figure 3. Initial LockerGoga ransom note

Latest LockerGoga Ransom Note:

#### Greetings!

There was a significant flaw in the security system of your company.

You should be thankful that the flaw was exploited by serious people and not some rookies.

They would have damaged all of your data by mistake or for fun.

will lead to irreversible destruction of your data.

To confirm our honest intentions.

Send us 2-3 different random files and you will get them decrypted.

It can be from different computers on your network to be sure that our decoder decrypts everything.

Sample files we unlock for free (files should not be related to any kind of backups).

We exclusively have decryption software for your situation

DO NOT RESET OR SHUTDOWN - files may be damaged. DO NOT RENAME the encrypted files. DO NOT MOVE the encrypted files. This may lead to the impossibility of recovery of the certain files.

The payment has to be made in Bitcoins. The final price depends on how fast you contact us. As soon as we receive the payment you will get the decryption tool and instructions on how to improve your systems security

To get information on the price of the decoder contact us at:

MayarChenot(@protonmail.com

QicifomuEjijika@02.pl

Figure 4. Latest LockerGoga ransom note

#### Back to top

#### TAGS

LockerGoga

# Related Resources

![](_page_10_Picture_1.jpeg)

ewsletter

![](_page_11_Picture_0.jpeg)

# Peace of mind comes from staying ahead of threats. Contact us today.

Your Email

Subscribe for email updates to all Unit 42 threat research. By submitting this form, you agree to our Terms of Use and acknowledge our Privacy Statement.

![](_page_11_Picture_4.jpeg)

# Products and Services

Company

Popular Links

![](_page_11_Picture_8.jpeg)