# THRFAT ANALYSIS WCRY RANSOMWARE ANALYSIS

Counter Threat Unit Research Team May 18, 2017

# SUMMARY

In May 2017, SecureWorks® Counter Threat Unit® (CTU) researchers investigated and opportunistic WCry (also known as WanaCry, WanaCrypt, and Wana DecryptOr) ransomware campaign that impacted many systems around the world. Some affected systems have national importance. CTU® researchers link the ransomware to use of a separate worm component that exploited vulnerabilities in the Windows Server Message Block (SMB) v1 protocol. Microsoft addressed the SMBv1 vilherabilities in March 2017 with Security Bulletin MS17-010.

# DELIVERY

REQUEST DEMO

and the same of the country of the country of the country of

The worm leverages an SMBv1 exploit that originates from tools released by the Shadow Brokers threat group in April. The worn specifically scans for the existence of the DoublePulsar backdoor on compromised systems. If the DoublePulsar backdoor does not exist, then the SMB worm attempts to compromise the target using the Eternalblue SMBv1 exploit. Propagation relies on two first thread determines the local network subnet, the SMB worm scans local addresses beginning at the netblock and increasing by one to the end of the netblock. The second thread scans randomly chosen external IP addresses.

The SMB worm delivers itself to the compromised system as a DLL file payload. After the DLL is executed with a single exported function named PlayGame, it writes a copy of the original SMB worn to C:\Windows\mssecsvc.exe and then executes this file. The SMB worm then drops a secondary payload from its resources section to C:\Windows\tasksche.exe and executes this file. In the samples analyzed by CTU researchers, this secondary payload is the WCry ransomware.

# INFECTION

After encrypting the file system, WCry displays the ransom demand shown in Figure 1.

and the contraction of the comments of the comments of the comments of

| Wana DecryptOr 2.0                               |                                                                                                                                                                                                                                                                                                                                                                                                                                        |                                                                                            |  |  |  |  |  |  |
|--------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--|--|--|--|--|--|
|                                                  | Ooops, your files have been encrypted!                                                                                                                                                                                                                                                                                                                                                                                                 | English                                                                                    |  |  |  |  |  |  |
|                                                  | What Happened to My Computer?<br>Your important files are encrypted.<br>Many of your documents, photos, videos, databases and other files are no longer<br>accessible because they have been encrypted. Maybe you are busy looking for a way to<br>recover your files, but do not waste your time. Nobody can recover your files without<br>our decryption service.                                                                    |                                                                                            |  |  |  |  |  |  |
| Payment will be raised on                        | Can I Recover My Files?                                                                                                                                                                                                                                                                                                                                                                                                                |                                                                                            |  |  |  |  |  |  |
| 5/16/2017 04:35:49                               |                                                                                                                                                                                                                                                                                                                                                                                                                                        |                                                                                            |  |  |  |  |  |  |
| Time Left<br>বাবি প্রিনিং বিশিয়া বিপি           | Sure. We guarantee that you can recover all your files safely and easily. But you have<br>not so enough time.<br>You can decrypt some of your files for free. Try now by clicking <Decrypt>.<br>But if you want to decrypt all your files, you need to pay.<br>You only have 3 days to submit the payment. After that the price will be doubled.<br>Also, if you don't pay in 7 days, you won't be able to recover your files forever. |                                                                                            |  |  |  |  |  |  |
|                                                  | We will have free events for users who are so poor that they couldn't pay in 6 months.                                                                                                                                                                                                                                                                                                                                                 |                                                                                            |  |  |  |  |  |  |
| Your files will be lost on<br>5/20/2017 04:35:49 | How Do I Pav?<br>Payment is accepted in Bitcoin only. For more information, click <About bitcoin>.                                                                                                                                                                                                                                                                                                                                     |                                                                                            |  |  |  |  |  |  |
| Time Left<br>वान :: विनि :: विनि                 | Please check the current price of Bitcoin and buy some bitcoins. For more information,<br>click <How to buy bitcoins>.<br>And send the correct amount to the address specified in this window.<br>After your payment, click <Check Payment>. Best time to check: 9:00am - 11:00am                                                                                                                                                      |                                                                                            |  |  |  |  |  |  |
| About bitcoin<br>How to buy bitcoins?            | bitcoin<br>ACCEPTED HERE                                                                                                                                                                                                                                                                                                                                                                                                               | Send \$600 worth of bitcoin to this address:<br>12t9YDPgwueZ9NyMgw519p7AA8isjr6SMw<br>Copy |  |  |  |  |  |  |
| Contact Us                                       | Check Payment                                                                                                                                                                                                                                                                                                                                                                                                                          | Decrypt                                                                                    |  |  |  |  |  |  |

Figure 1. WCry (also known as Wana DecryptOr) ransom demand interface. (Source: SecureWorks)

The malware continually monitors this window to ensure it it it is closed. WCry also launches a small program named taskse.exe that enumerates active RDP sessions and ensures the window. Additionally, the malware changes the desktop wallpaper to the image in Figure 2.

![](_page_1_Picture_3.jpeg)

Figure 2. Desktop wallpaper set by WCry ransomware. (Source: SecureWorks)

WCry is distributed as an executable file that contains a password-protected ZIP archive in its resources section. When executed, this archive is unpacked (using the password "WNcry@2ol7") in the current directory and contains the following files:

- · b.wnry Bitmap image used as desktop wallpaper (shown in Figure 2)
- c.wnry Configuration containing Tor command and control (C2) addresses, and other data
- r.wnry Ransom demand text
- s.wnry ZIP archive containing Tor software to be installed on the victim's system; saved in TaskData directory
- · t.wnry Encrypted DLL containing file-encryption functionality
- u.wnry Main module of the WCry ransomware "decryptor"
- taskdl.exe WNCRYT temporary file cleanup program
- · taskse.exe Program that displays decryptor window to RDP sessions
- msg Directory containing Rich Text Format (RTF) ransom demands in multiple languages

WCry creates additional files during the infection:

- · 0000000.pky— Microsoft PUBLICKEYBLOB containing the RSA-2048 public key (The WCry threat actors presumably hold the private key.)
- · 00000000.res Data for C2 communication
- 0000000.eky Victim-unique RSA private key encrypted with embedded RSA public key
- 0000000.dky Decrypted RSA private key transmitted to victim after ransom payment
- f.wnry A list of randomly chosen files encrypted with an embedded RSA private key that allows WCry to "demonstrate" decryption to victims
- @WanaDecryptor@.exe Main module of the WCry ransomware "decryptor," identical to u.wnry
- · @Please\_Read\_Me@.txt -- Ransom demand text, identical to r.wnry

When started, WCry executes two commands:

- attrib +h .
- icacls . /grant Everyone:F /T /C /Q

WCry executes the following single command (formatted for readability) to complicate system and data recovery. If the malware is not running with elevated privileges, WCry executes this with the "runas" command.

```
cmd.exe /c vssadmin delete shadows /all /quiet &
wmic shadowcopy delete &
bcdedit /set {default} bootstatuspolicy ignoreallfailures &
bcdedit /set {default} recoveryenabled no &
wbadmin delete catalog -quiet
```
WCry terminates several services so that their data stores can be encrypted:

- · taskkill.exe /f /im mysqld.exe
- taskkill.exe /f /im sqlwriter.exe
- · taskkill.exe /f /im sqlserver.exe
- taskkill.exe /f /im MSExchange\*
- taskkill.exe /f /im Microsoft.Exchange.\*

WCry creates a batch file using a randomly generated large integer (e.g., 4663149485937.bat) that creates a shortcut to the malware executable (see Figure 3).

```
@echo off
echo SET ow = WScript.CreateObject ("WScript.Shell")> m.vbs
echo SET on = ow.CreateShortcut("C:\Users\Stephen\AppData\Local\Temp\(ManaDecryptore.exe.lnk")>> m.vbs
echo om.TargetPath = "C:\Users\Stephen\AppData\Local\Temp\@WanaDecryptor0.exe">> m.vbs
echo om. Save>> m.vbs
cscript.exe / / nologo m. vbs
del m.vbs
```
del /a %0

#### Figure 3. Batch file executed by WCry ransomware. (Source: SecureWorks)

The malware's current working directory is saved to the 'fwd'' registry value under the \SOFTWARE\WanaCryptOr key (see Figure 4). If WCry is running with elevated privileges, the key is created in the HKLM registry hive; otherwise, it is created in the HKCU hive.

| Registry Editor<br>File<br>Edit<br>View Favorites<br>Help                                           |                                |                          |                                                                | 0 x<br>0 |
|-----------------------------------------------------------------------------------------------------|--------------------------------|--------------------------|----------------------------------------------------------------|----------|
| D  Volatile<br>A<br>WanaCryptOr<br>-----<br>D  WOW6432Node<br>D SYSTEM<br>- 11 40<br>HKEY_USERS<br> | Name<br>ab] (Default)<br>ab wd | Type<br>REG_SZ<br>REG SZ | Data<br>(value not set)<br>C:\Users\Stephen\AppData\Local\Temp |          |
| Computer\HKEY_LOCAL_MACHINE\SOFTWARE\WanaCrypt0r                                                    |                                |                          |                                                                | 12       |

Figure 4. Metadata stored in registry by WCry ransomware. (Source: SecureWorks)

WCry creates a registry Run key value (see Figure 5) to ensure the ransomware GUI is displayed when victims log in or restart the computer.

|      | Registry Editor                |                                                                           |        |                                                    | 8<br>l<br>0 |
|------|--------------------------------|---------------------------------------------------------------------------|--------|----------------------------------------------------|-------------|
| File | Edit<br>Favorites Help<br>View |                                                                           |        |                                                    |             |
|      | ▷ · RenameFiles                | Name                                                                      | Type   | Data                                               |             |
|      | Run<br>RunOnce                 | ab) (Default)                                                             | REG SZ | (value not set)                                    |             |
|      | RunOnceEx                      | ab"  lamqlvksrbhpas380                                                    | REG_SZ | "C:\Users\Stephen\AppData\Local\Temp\tasksche.exe" |             |
|      | Setup<br>▷ - 山山                |                                                                           |        |                                                    |             |
|      |                                |                                                                           |        |                                                    |             |
|      |                                | Computer\HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Run |        |                                                    |             |

Figure 5. Run key created by WCry ransomware. (Source: SecureWorks)

# ENCRYPTION

WCry uses a combination of the RSA and AES algorithms to encrypt files. It uses the Windows Crypto AP for RSA encryption and random key generation; however, a third-party implementation of AES is statically linked within the malware. CTU researchers did not identify any flaws in the cryptographic implementation, so file recovery through decryption is likely not possible without a decrypted private key from the ransomware operators.

Prior to encryption, WCry enumerates all available disks on the system. This enumeration includes local drives (e.g., hard disks), removable drives (e.g., USB thumb drives (e.g., a remote file share mapped to a drive letter). The malware does not contain functionality to search the local network for unmapped file shares. WCry also searches for the presence of the Global\MsWinZonesCacheCounterMutexA mutex prior to file encryption and exits if the mutex exists.

WCry targets file extensions associated with productivity and database applications, and multimedia formats (see Figure 6). The encryption process skips files whose pathnames contain the directory names and language listed in Table 1.

.der .pfx .key .crt .csr .p12 .pem .odt .ott .sxw .stw .uot .3ds .max .3dm .ods .ots .sxc .stc .dif .slk .wb2 .odp .otp .sxd .std .uop .odg .sxm .mml .lay .lay6 .asc .sqlite3 .sqlitedb .sql .accdb .mdb .dbf .odb .frm .myd .myi .ibd .mdf .ldf .sln .suo .cpp .pas .asm .cmd .bat .ps1 .vbs .dip .dch .jsp .php .asp .java .jar .class .mp3 .wav .swf .fla .wmv .mpg .vob .mpeg .asf .avi .mov .mp4 .3gp .mkv .3g2 .flv .wma .mid .m3u .m4u .djvu .svg .psd .nef .tiff .cgm .raw .gif .png .bmp .jpg .jpeg .vcd .iso .backup .zip .rar .tgz .tar .bak .tbk .bz2 .PAQ .ARC .aes .gpg .vmx .vmdk .vdi .sldm .sldx .sti .602 .hwp .snt .onetoc2 .dwg .pdf .wk1 .wks .123 .rtf .csv .txt .vsdx .vsd .edb .eml .msg .ost .pst .ppam .ppsx .ppsm .pps .pot .pptm .pptx .ppt .xltm .xltx .xlc .xlm .xlt .xlw .xlsx .xls .dotx .dotm .dot .docm .docb .docx .doc

| Figure 6. File extensions targeted by WCry ransomware. (Source: SecureWorks, |  |  |  |
|------------------------------------------------------------------------------|--|--|--|
|------------------------------------------------------------------------------|--|--|--|

| Content.IE5    | Temporary Internet Files | \LocalSettings\Te | ppData\Local\Te |
|----------------|--------------------------|-------------------|-----------------|
|                |                          | mp                | mp              |
| (Program Files | \Program Files (x86)     | WINDOWS           | \ProgramData    |
| Intel          | This folder protects     |                   |                 |
|                | against ransomware.      |                   |                 |
|                | Modifying it will reduce |                   |                 |
|                | protection               |                   |                 |

Table 1. Whitelisted directory name components.

WCry generates a private RSA-2048 key pair specific to each infection and stores it on the local disk with an .eky extension (e.g., 0000000.eky) after encrypting it with an embedded RSA public key. This generated RSA key is used to encrypt the random AES-128 key generated for each encrypted file.

Each targeted file is opened, read, encrypted in memory, and then written to a new file in the malware's working directory using the filename format <random number>.WNCRYT. The files are then renamed to their original filename followed by the .WINCRY extension and moved to their original directory. The taskdl.exe process launched by the malware periodically deletes the remaining WNCRYT temporary files. The encryption process does not directly overwrite file data, so forensic recovery of file contents may be possible depending on the environment. The entire contents of the file are encrypted and saved with a custom header (see Figure 7).

|                                 | OB    | OF          | OD    |    | 09 OA OB OC | 03 04 05 06 07 08                               |  |  |          | 02    | 01    | 00   | Offset (h) |
|---------------------------------|-------|-------------|-------|----|-------------|-------------------------------------------------|--|--|----------|-------|-------|------|------------|
| WANACRY! TT .-                  | 97    | 15          | ਦੇ ਚੋ | 54 |             | 4E 41 43 52 59 21 00 01 00 00                   |  |  |          |       | 41    | 57   | 000000000  |
| -. 8. L35»8/3ªt   -             |       |             |       |    |             | 1F 9A 10 07 4C 33 8A BB 38 2F 33 AA 74 7C 96    |  |  |          |       |       | 2D   | 00000010   |
| .A. ujuaBnfSEêj ·               |       |             |       |    |             | 01 FB 6A F9 E5 42 6E 83 53 CA EA 6A 20 B7       |  |  |          |       | C4    | 16   | 00000020   |
| 0 . ! . peA } ¥ (29×N           | D7 4E |             | 8E 39 |    |             | 88 07 21 16 70 80 C1 7D A0 A5 28                |  |  |          |       |       | D2   | 00000030   |
| E 4. Eüü  . y»tx. ä             | Ed    | 1B          | 86 78 |    |             | CA AO 34 90 80 FC FB 03 09 OB FD BB             |  |  |          |       |       |      | 00000040   |
| [«ð;5¢¥3©;öÍG,                  | 8F 2F |             |       |    |             | AB FO A1 35 A2 A5 33 A9 A1 F6 EE 47 B8          |  |  |          |       |       | 5B   | 00000050   |
| LSüOL. . ߉ù5/cöàû               | EO FB |             |       |    |             | FC D3 4C 1E 16 DF 89 F9 35 2F 63 F6             |  |  |          |       | 53    | 4C   | 00000060   |
| "% .- .   . * U" " gqC. /<      | 2F 8B |             |       |    |             | 25 1D 96 11 A6 OA 2A D9 94 B6 71 C7 09          |  |  |          |       |       | 08   | 00000070   |
| ÖØ" ýÀ¤. SžÝüÜe >. ‰            | 03 89 |             |       |    |             | D8 22 FD C0 A4 12 53 9E DD FB DA 65 9B          |  |  |          |       |       | D6   | 00000080   |
| < 7 m . "øï< ' + , W. ê         | EA    | 06          | 57    |    |             | 37 84 06 84 F8 EF 8B A0 B4 87 82                |  |  |          |       | 88    | A8   | 00000090   |
| , } I . da ^ P 7 G . z Q . I ¥  |       |             |       |    |             | 7D 49 01 64 61 5E 50 37 47 OE 7A 51 00 CE A5    |  |  |          |       |       | 32   | 000000000  |
| â�ç^O` . A. NêÛYúEh             |       |             |       |    |             | AE E7 5E 4F 60 1B C2 04 4E EA D9 59 FA 45 68    |  |  |          |       |       | C2   | 000000B0   |
| "Z3xV4   h. A+1- "‰. .          |       |             |       |    |             | 56 BC A6 68 7F C4 87 69 96 84 89 00 03          |  |  |          | SA BD |       | 98   | 000000000  |
| Gj+ -MÜBW ûd                    | FB 64 |             |       |    |             | 6A 2B 7C 96 4D D9 42 57 05 OC 1F 02 16          |  |  |          |       |       | 47   | 000000D0   |
| Þð9}Rfúÿ. I^1™â.                |       |             |       |    |             | 39 7D 52 83 FA FF 19 49 5E 6C 99 5E E2 14       |  |  |          |       | FO    | DE   | 000000E0   |
| ' ÖfW. " 8° " " yNalap=         | 70 3D |             | BC    |    |             | 66 57 16 98 FO BO 84 A8 FD 4E E5                |  |  |          |       | D4    | 92   | 000000F0   |
| I % K . < . ÜH { + LQ           |       | 04 00 00 00 |       |    |             | 4B 1C 8B 14 DA 48 7B 86 4C 51                   |  |  |          |       | 25    | CE   | 00000100   |
| < n  Jäaa                       |       | EO E6       | 4A E4 |    |             | 6E 03 00 00 00 00 00 D9 0A 05 5F                |  |  |          |       |       | 8B   | 00000110   |
| 5 ^ Dz Y Þ> M Úm Œ î û ý Z ®    |       |             |       |    |             | 7A DD DE 3E 4D DA 6D 8C EE FB FD 5A AE          |  |  |          | ರ ಕ   | 51    | ਤੇ ਦ | 00000120   |
| GEOÍøoor -. . ÇO >i£            |       | 9B ED A3    |       |    |             | 80 D3 CC F8 6F 6F 72 2D 01 1B C7 D4             |  |  |          |       |       | 47   | 00000130   |
| . © . b ; x » m 9 ( G . è ú S î |       |             |       |    |             | A9 1C DE A1 A4 BB 6D 39 28 47 9D E8 FA 53 EE    |  |  |          |       |       | 12   | 00000140   |
| . V¶umæ*åQ§ßC . = İ             |       |             |       |    |             | 56 B6 B5 6D E6 2A E5 51 A7 DF C7 90 3D CD       |  |  |          |       | 1A 8D |      | 00000150   |
| i.SB4x1x4x+AUV ;@s              |       |             |       |    |             | 78 BC A4 B1 C3 DC 56 8B A1 AE 9A                |  |  | 53 DF BC |       | 09    | റ്റേ | 00000160   |
| AàóÇ.êxk¿ÜÜå¦üÉr                |       |             |       |    |             | CO EO F3 C7 1F EA A4 6B BF DB DC E5 A6 FC C9 72 |  |  |          |       |       |      | 00000170   |
|                                 |       |             |       |    |             |                                                 |  |  |          |       |       |      |            |

Figure 7. WCry file header prepended to encrypted file (encrypted AES key highlighted). (Source: SecureWorks)

The header follows the pattern shown in Figure 8, which allows the malware to identify previously decrypt them.

```
typedef struct _wana_hdr {
   uint8_t magic[8];
                                 // "WANACRY!"
    uint32_t key_len;
                                // Key length 0x0100 (256) bytes
   uint8_t key[256];
                                // Encrypted key
   uint32_t file_code;
                                 // File type code, 0x03 or 0x04
   uint64_t file_length;
                                // Length of original file
   uint8_t *encrypted_data;
                                // Ciphertext
  wana_hdr_t;
ﯩﺘﯩ
```
Figure 8. WCry encrypted file header. (Source: SecureWorks)

## PAYMENT

After infecting a system, WCry displays a timer that counts down the ransom amount increases (four days) and when files will be irrecoverable (seven days). WCry can be configured to demand different ransom amounts in dollars or bitcoins. CTU researchers observed WCry variants demanding Bitcoin payments equivalent to \$300 and \$600. The Bitcoin address is provided in the c.wnry configuration file and can vary across samples. If no configuration file is present, the malware uses a hard-coded Bitcoin address. CTU researchers have identified the following Bitcoin addresses associated with the WCry ransomware:

- · 115p7UMMnqoi1pMvkpHijcRdfJNXj6LrLn
- · 12t9YDPgwueZ9NyMgw519p7AA8isjr6SMw
- · 13AM4VW2dhxYgXeQepoHkHSQuy6NgaEb94 (hard-coded)

CTU researchers have no evidence that the WCry threat actors have the capability or intent to decrypt files for paying victims. Many ransomware families assign each victim a unique Bitcoin address so the threat actors can attribute a payment direction and associated decryption key. WCry does not include this feature, so the threat actor must rely on communication with the victim to make the connection

# COMMAND AND CONTROL (C2) TRAFFIC

WCry installs the Tor network anonymity software on the TaskData folder within the malware's working directory. The local Tor server is renamed and executed as taskhshes a SOCKS5 proxy server on the loopback interface (127.0.0.1) that listens on TCP port 9050. WCry connects to this proxy and attempts to contact the configured C2 hidden services:

- · gx7ekbenv2riucmf . onion
- · 57g7spgrzlojinas . onion
- xxlvbrloxvriy2c5 . onion
- 76jdd2ir2embyv47 . onion
- cwwnhwhlz52maqm7.onion

After connecting to a C2 server, the malware uses a custom encrypted protocol over TCP port 80 through to transmit encryption keys, to allow victims to communicate with the operators, and to check payment status. WCry does not exteal stored credentials, or receive and execute additional files.

# CONCLUSION

WCry is an opportunistic ransomware family whose propagation methods allow it to spread quickly. CTU researchers recommend that clients implement the following best practices to mitigate the threat:

- Apply the Microsoft security updates for MS17-010, including the updates for the Windows Sever 2003 legacy operating systems.
- Disable SMBv1 on systems where it is not need to communicate with Windows XP and Windows 2000 systems). Carefully evaluate the need for allowing SMBV1-capable systems on interconnected the associated risks.
- · Segment networks to isolate hosts that cannot be patched, and block SMBv1 from traversing those networks.
- · Scan networks for the presence of the DoublePulsar backdoor using plugins for tools such as Nmap.
- Use network auditing tools to scan networks for hosts that are vulnerabilities described in MS17-010.
- · Filter emails containing potentially dangerous file types such as executables, scripts, or macro-enabled documents.
- Implement a backup strategy that includes storing data using media. Backups to locally connected, network-attached, or cloud-based storage are often insufficient because ransomware frequently accesses and encrypts files stored on these systems.

# THREAT INDICATORS

The threat indicators in Table 2 can be used to detect activity related to WCry and associated delivery mechanisms. The domains may contain malicious content, so consider the risks before opening them in a browser.

| Indicator Type Context                  |                      |                |
|-----------------------------------------|----------------------|----------------|
| qx7ekbenv2riucmf.onion                  | Tor address          | WCry C2 server |
| 57g7spgrzlojinas.onion                  | Tor address          | WCry C2 server |
| xxlvbrloxvriy2c5.onion                  | Tor address          | WCry C2 server |
| 76jdd2ir2embyv47.onion                  | Tor address          | WCry C2 server |
| cwwnhwhlz52maqm7.onion                  | Tor address          | WCry C2 server |
| Microsoft Security Center (2.0) Service | Service display name | WCry SMB worm  |

| mssecsvc2.0                                                      | Service name | WCry SMB worm                      |
|------------------------------------------------------------------|--------------|------------------------------------|
| C:\Windows\mssecsvc.exe                                          | Filename     | WCry SMB worm                      |
| C:\Windows\Tasksche.exe                                          | Filename     | WCry SMB worm payload              |
| C:\Windows\qeriuwjhrf                                            | Filename     | WCry SMB worm payload cor          |
| db349b97c37d22f5ea1d1841e3c89eb4                                 | MD5 hash     | WCry SMB worm                      |
| e889544aff85ffaf8b0d0da705105dee7c97fe26                         | SHA1 hash    | WCry SMB worm                      |
| 24d004a104d4d54034dbcffc2a4b19a11f39008a575aa614ea04703480b1022c | SHA256 hash  | WCry SMB worm                      |
| Global\MsWinZonesCacheCounterMutexW                              | Mutex        | WCry exclusion flag                |
| %PROGRAMDATA%\%RAND%\0000000.eky                                 | Filename     | WCry encryption key                |
| 63fb6dd827559c0ed40c4c3725f7fc0a                                 | MD5 hash     | WCry encryption key                |
| 8e7211b1455dedfe1f84cc60a7ed593f78dfb6e1                         | SHA1 hash    | WCry encryption key                |
| 24076e8485c72e4f9cf997c1f3670337231e401a043505e489606fff5758150f | SHA256 hash  | WCry encryption key                |
| 00000000.pky                                                     | Filename     | WCry public key                    |
| f5c0755e5f08dabf1119c193e96539a6                                 | MD5 hash     | WCry public key                    |
| 5109c0738c126e65db8a92e1ff24f3291837f627                         | SHA1 hash    | WCry public key                    |
| c863b4b4780d6ce53827049d3733863283aaeb4d4ae806fc2c5cfbd9eb236ab8 | SHA256 hash  | WCry public key                    |
| 00000000.res                                                     | Filename     | WCry C2 communication dat          |
| 492c258c5bcbdd812fddd99b2427da99                                 | MD5 hash     | WCry C2 communication data (0000   |
| 0c16196d93b076f4648a9b1b027e7735845cab20                         | SHA1 hash    | WCry C2 communication data (0000   |
| 6fa17600177c2032c3c3a3c06df6cf7d8dba1d32db146d9dd87aecf3f39fb898 | SHA256 hash  | WCry C2 communication data (0000   |
| b.wnry                                                           | Filename     | WCry ransom demand desktop wa      |
| c17170262312f3be7027bc2ca825bf0c                                 | MD5 hash     | WCry ransom demand desktop wallpar |
| f19eceda82973239a1fdc5826bce7691e5dcb4fb                         | SHA1 hash    | WCry ransom demand desktop wallpar |
| d5e0e8694ddc0548d8e6b87c83d50f4ab85c1debadb106d6a6a794c3e746f4fa | SHA256 hash  | WCry ransom demand desktop wallpar |
| c.wnry                                                           | Filename     | WCry configuration file            |
| fa44d43242f0bcc6d64569e4869e4913                                 | MD5 hash     | WCry configuration file (c.wnı     |
| 29da372c816ac0d636657a76ab7712ae8106cb45                         | SHA1 hash    | WCry configuration file (c.wn      |
| 3324483d27e716feb408b5d16b82540731faf435b9325497df779d72e7a6b765 | SHA256 hash  | WCry configuration file (c.wnı     |
| f.wnry                                                           | Filename     | WCry decryption demonstration 1    |
| @Please_Read_Me@.txt                                             | Filename     | WCry ransom note                   |

| r.wnry                                                           | Filename    | WCry ransom note                       |
|------------------------------------------------------------------|-------------|----------------------------------------|
| 3e0020fc529b1c2a061016dd2469ba96                                 | MD5 hash    | WCry ransom note                       |
| c3a91c22b63f6fe709e7c29cafb29a2ee83e6ade                         | SHA1 hash   | WCry ransom note                       |
| 402751fa49e0cb68fe052cb3db87b05e71c1d950984d339940cf6b29409f2a7c | SHA256 hash | WCry ransom note                       |
| s.wnry                                                           | Filename    | WCry ZIP archive containing Tor s‹     |
| ad4c9de7c8c40813f200ba1c2fa33083                                 | MD5 hash    | WCry ZIP archive containing Tor s‹     |
| d1af27518d455d432b62d73c6a1497d032f6120e                         | SHA1 hash   | WCry ZIP archive containing Tor s‹     |
| e18fdd912dfe5b45776e68d578c3af3547886cf1353d7086c8bee037436dff4b | SHA256 hash | WCry ZIP archive containing Tor s‹     |
| taskdl.exe                                                       | Filename    | WCry temporary file cleanup pro        |
| 4fef5e34143e646dbf9907c4374276f5                                 | MD5 hash    | WCry temporary file cleanup program    |
| 47a9ad4125b6bd7c55e4e7da251e23f089407b8f                         | SHA1 hash   | WCry temporary file cleanup program    |
| 4a468603fdcb7a2eb5770705898cf9ef37aade532a7964642ecd705a74794b79 | SHA256 hash | WCry temporary file cleanup program    |
| tasksche.exe                                                     | Filename    | WCry installer                         |
| 84c82835a5d21bbcf75a61706d8ab549                                 | MD5 hash    | WCry installer                         |
| 5ff465afaabcbf0150d1a3ab2c2e74f3a4426467                         | SHA1 hash   | WCry installer                         |
| ed01ebfbc9eb5bbea545af4d01bf5f1071661840480439c6e5babe8e080e41aa | SHA256 hash | WCry installer                         |
| taskse.exe                                                       | Filename    | WCry RDP session decryptor displ       |
| 8495400f199ac77853c53b5a3f278f3e                                 | MD5 hash    | WCry RDP session decryptor display too |
| be5d6279874da315e3080b06083757aad9b32c23                         | SHA1 hash   | WCry RDP session decryptor display too |
| 2ca2d550e603d74dedda03156023135b38da3630cb014e3d00b1263358c5f00d | SHA256 hash | WCry RDP session decryptor display too |
| t.wnry                                                           | Filename    | WCry file encryption DLL               |
| 5dcaac857e695a65f5c3ef1441a73a8f                                 | MD5 hash    | WCry file encryption DLL               |
| 7b10aaeee05e7a1efb43d9f837e9356ad55c07dd                         | SHA1 hash   | WCry file encryption DLL               |
| 97ebce49b14c46bebc9ec2448d00e1e397123b256e2be9eba5140688e7bc0ae6 | SHA256 hash | WCry file encryption DLL               |
| @WanaDecryptor@.exe                                              | Filename    | WCry decryptor                         |
| u.wnry                                                           | Filename    | WCry decryptor                         |
| 7bf2b57f2a205768755c07f238fb32cc                                 | MD5 hash    | WCry decryptor (u.wnry and @WanaDec    |
| 45356a9dd616ed7161a3b9192e2f318d0ab5ad10                         | SHA1 hash   | WCry decryptor (u.wnry and @WanaDec    |
| b9c5d4339809e0ad9a00d4d3dd26fdf44a32819a54abf846bb9b560d81391c25 | SHA256 hash | WCry decryptor (u.wnry and @WanaDec    |
| @WanaDecryptor@.exe.Ink                                          | Filename    | WCry decryptor shortcut                |

### ABOUT THE AUTHOR

### COUNTER THREAT UNIT RESEARCH TEAM

Secureworks Counter Threat Unit™ (CTU) researchers for the media, publish technical analyses for the security community, and speak about emerging threats at security conferences. Leveraging Security technologies and a network of industry contacts, the CTU™ research team tracks threat actors and arabity, uncovering new attack techniques and threats. This process enables CTU researchers to identify threats as they emerge and develop countermeasures that protect customers before damage can occur.

→

BACK TO MORE THREAT ANALYSES AND ADVISORIES

## NOW TRENDING ...

- → 2024 Global State of the Threat Report
- → Modernize Your Security Operation Center with XDR
- → MDR Done Right

![](_page_8_Picture_9.jpeg)

REPORT

THREAT INTELLIGENCE EXECUTIVE REPORT VOLUME 2025 NUMBER 1

READ MORE

## ADDITIONAL RESOURCES

![](_page_9_Picture_1.jpeg)

RESEARCH WCRY RANSOMWARE CAMPAIGN

READ NOW

Get the latest updates and news from Secureworks.

SUBSCRIBE NOW

PLATFORM

### Detection & Response

XDR Log Management MITRE ATT&CK Coverage

Network Security

ndr

### Endpoint Security

edr ngav

### Identity Security idr

OT Security Operational Technology

### Vulnerability Management

Vulnerability Risk Prioritization

### WHY SECUREWORKS

Why Secureworks Customer Trust Compare Secureworks At Your Side ROI Calculator Artificial Intelligence Corporate Responsibility Corporate Overview Counter Threat Unit

#### SERVICES

### Managed Detection & Response MDR Overview Threat Hunting MDR for OT MDR for Microsoft

Consulting Consulting Services Overview Risk Assessment Security Preparedness Resiliency Testing

Professional Services Professional Services Overview Taegis Onboarding Steady State Services

Incident Response About Emergency Incident Response Emergency Breach Hotline

### SOLUTIONS