![](_page_0_Picture_0.jpeg)

# KillDisk Variant Hits Latin American Finance Industry

In January, we saw a variant of the disk-wiping KillDisk malware hitting several financial institutions in Latin America. Last May, we uncovered a master boot record (MBR)-wiping malware in the same region.

By: Fernando Merces, Byron Gelera, Martin Co June 07, 2018 Read time: 4 min (1021 words)

![](_page_0_Picture_6.jpeg)

In January, we saw a variant of the disk-wiping KillDisk malware hitting several financial institutions in Latin America. One of these attacks was related to a foiled heist on the organization's system connected to the Society for Worldwide Interbank Financial Telecommunication's (SWIFT) network.

Last May, we uncovered a master boot record (MBR)-wiping malware in the same region. One of the affected organizations was a bank whose systems were rendered inoperable for several days, thereby disrupting operations

This website uses cookies for website functionality, traffic analytics, personalization, social media functionality and advertising. Our Cookie Notice provides more information and explains how to amend your cookie settings. Learn more

for almont a world and line itling coursiis

Cookies Settings

Accept

![](_page_1_Picture_0.jpeg)

Business

This kind of notification is common in systems affected by MBR-wiping threats and not in other malware types such as ransomware, which some people initially believed to be the culprit. Trend Micro products detect this threat as TROJ\_KILLMBR.EE and TROJ\_KILLDISK.IUE.

The nature of this payload alone makes it difficult to determine if the attack was motivated by an opportunistic cybercriminal campaign or part of a coordinated attack like the previous attacks we observed last January.

![](_page_1_Picture_4.jpeg)

Figure 1. Error screen after the boot sector is overwritten

This website uses cookies for website functionality, traffic analytics, personalization, social media functionality and advertising. Our Cookie Notice provides more information and explains how to amend your cookie settings. Learn more

Q

![](_page_2_Picture_0.jpeg)

engineering), we were still able to verify that it has a routine that wipes the first sector of the machine's physical disk, as shown in Figure 2. We haven't found any other new or notable routines in the sample we have. There is no evident command-and-control (C&C) infrastructure or communication, or ransomware-like routines coded into the sample. There are no indications of network-related behavior in this malware.

| 0040114D<br>0040114E | 50<br>6A FF    | PUSH EAX<br>BUSH EFECEEEEE |                           |
|----------------------|----------------|----------------------------|---------------------------|
| 00401150             | 68 40 OF 7C 00 | PUSH swagp.7COF40          | 7COF40:"MBR Killer Setup" |
| 00401155             | 57             | PUSH EDIT                  |                           |
| 00401156             | 56             | PUSH ESI                   | esi :Call                 |
| 00401157             | E8 41 9E 42 00 | CALL swaqp.82AF9D          |                           |
| 0040115C             | FF 75 Oc       | PUSH DWORD PTR SS: EBP+C]  |                           |
|                      |                |                            |                           |

![](_page_2_Picture_4.jpeg)

Figure 2. The malware named "MBR Killer" (highlighted, top) and a code snippet showing its routine of wiping the disk's first sector (bottom)

![](_page_2_Figure_6.jpeg)

Figure 3. How the malware carries out its MBR-wiping routine

This website uses cookies for website functionality, traffic analytics, personalization, social media functionality and advertising. Our Cookie Notice provides more information and explains how to amend your cookie settings. Learn more

Q

![](_page_3_Picture_0.jpeg)

![](_page_3_Picture_2.jpeg)

- 3. It will try to perform the routines above (steps 1-2) on II. IPHYSICALDRIVE1, II. \PHYSICALDRIVE2, \\.\PHYSICALDRIVE3, and so on, as long as a hard disk is available.
- 4. It will then force the machine to shut down via the API ExitWindows.

When calling the APIs, the main executable will drop the component file %User Temp%/ns{5 random characters}.tmp/System.dll. The main executable will then load the dynamic-link library (DLL) file, which has the export function "Call" used to call for the APIs.

# Mitigation and best practices

The destructive capabilities of this malware, which can render the affected machine inoperable, underscore the significance of defense in depth: arraying security to cover each layer of the organization's IT infrastructure, from gateways and endpoints to networks and servers. Here are some best practices that organizations can adopt to defend against this kind of threat:

![](_page_4_Picture_0.jpeg)

- Secure mission-critical infrastructure. Secure the infrastructure used to store and manage personal and corporate data. For financial institutions, SWIFT has a Customer Security Programme that provides mandatory and advisory controls for their local SWIFT infrastructure. Some of these include virtual patching, vulnerability scanning, application control, and integrity monitoring of SWIFT-related applications.
- Enforce the principle of least privilege. Restrict access to mission-critical data. Network segmentation limits user or program access to the network; data categorization organizes data by importance to minimize further exposure to threats or breaches. Restrict access to and use of tools reserved for system administrators (for example, PowerShell, command-line tools) to prevent them from being abused. Disable outdated and unneeded system or application components.
- · Proactively monitor online premises. Deploy additional security mechanisms to further hinder attackers. Firewalls and intrusion detection and prevention systems help against network-based attacks, while application control and behavior monitoring prevent the execution of suspicious and unwanted files or malicious routines. URL categorization also helps prevent access to malware-hosting sites.
- · Foster a culture of cybersecurity. Many threats rely on social engineering to succeed. Awareness of the telltale signs of spam and phishing emails, for instance, significantly helps thwart email-based threats.
- Create a proactive incident response strategy. Complement defensive measures with incident response strategies that provide actionable threat intelligence and insights to help IT and information security teams actively hunt for, detect, analyze, correlate, and respond to threats.

## Trend Micro Solutions

Trend Micro™ XGen™ security provides a cross-generational blend of threat defense techniques against a full range of threats for data centers, cloud environments, networks, and endpoints. It features high-fidelity machine learning to secure the gateway and endpoint data and applications and protects physical, virtual, and cloud workloads. With capabilities like web/URL filtering, behavioral analysis, and custom sandboxing, XGen nratacts againet today's nurnace huilt threate that hvinace traditional

This website uses cookies for website functionality, traffic analytics, personalization, social media functionality and advertising. Our Cookie Notice provides more information and explains how to amend your cookie settings. Learn more

Q

|                                                                                           | Business                                                                                |  |  |  |
|-------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|--|--|--|
|                                                                                           |                                                                                         |  |  |  |
|                                                                                           | • a3f2c60aa5af9d903a31ec3c1d02eeeb895c02fcf3094a049a3bdf3aa3d714c8 —<br>TROJ KILLMBR.EE |  |  |  |
| ● 1a09b182c63207aa6988b064ec0ee811c173724c33cf6dfe36437427a5c23446 -<br>TRO  KILLDISK.IUE |                                                                                         |  |  |  |
|                                                                                           |                                                                                         |  |  |  |
|                                                                                           |                                                                                         |  |  |  |

#### Tags

Malware | Endpoints | Research | Network

## Authors

Fernando Merces Sr. Threat Researcher

Byron Gelera Threats Analyst

Martin Co Threats Analyst

![](_page_6_Picture_0.jpeg)

Business

Q

#### CrazyHunter Campaign Targets Taiwanese Critical Sectors

Strengthen Security with Cyber Risk Advisory

ZDI-23-1527 and ZDI-23-1528: The Potential Impact of Overly Permissive SAS Tokens on PC

Manager Supply Chains

See all articles >

| Resources            | > |
|----------------------|---|
| Support              | > |
| About Trend          | > |
| Country Headquarters | > |
|                      |   |

![](_page_6_Picture_9.jpeg)

![](_page_7_Picture_0.jpeg)

![](_page_7_Picture_2.jpeg)

## Claim your 30-day trial

Privacy

Legal

Terms of Use

Accessibility

Sitemap

Copyright ©2025 Trend Micro Incorporated. All rights reserved.