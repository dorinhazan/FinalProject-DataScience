![](_page_0_Picture_0.jpeg)

![](_page_0_Figure_3.jpeg)

![](_page_1_Figure_0.jpeg)

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_1_Figure_3.jpeg)

#### Show details >

QUISERCENTRICS Cookiebot

# Since when does Kaspersky Lab detect the threat?

We have been proactively detecting the original vector attack since it began on the morning of October 24. The attack lasted until midday, although ongoing attacks were detected at 19.55

Moscow time. The server from which the Bad rabbit dropper was distributed went down in the evening (Moscow time).

# How is it different to ExPetr? Or it is the same ma ware?

Our observations suggest that this been a targeted attack against corporate networks. using methods similar to those used

This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

QUISERCENTRICS Cookiebot

![](_page_2_Figure_5.jpeg)

The downloaded file named install\_flash\_player.exe needs to be manually launched by the victim. To operate correctly, it needs elevated administrative privileges which it attempts to obtain using the standard UAC prompt. If started, it will save the malicious DLL as C:Windowsinfpub.dat and launch it using rund||32.

![](_page_3_Figure_3.jpeg)

# Pseudocode of the procedure that creates the task which launches the malicious executable

What's more, infpub.dat acts as a typical file encrypting ransomware: it finds the victim's data files using an embedded extension list and encrypts them using the criminal's public RSA-2048 key.

## This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_4_Figure_4.jpeg)

Show details >

QUISERCENTRICS Cookiebot

# 14-61

Exponent: 65537 (0x10001)

The executable dispci.exe appears to be derived from the code base of the legitimate utility DiskCryptor. It acts as the disk encryption module which also installs the modified bootloader and prevents the normal boot-up process of the infected machine.

An interesting detail that we noticed when analyzing the sample of this threat: it looks like the criminals behind this malware are fans of the famous books & TV show series Game Of Thrones. Some of the strings used throughout the code are the names of different characters from this series.

#### This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

QUISERCENTRICS Cookiebot

![](_page_5_Figure_3.jpeg)

#### 2 RSA-2048

It is a default encryption scheme for ransomware.

An interesting fact is that the ransomware enumerates all running processes and compares the hashed name of each process with embedded hash values. It is important to mention that the hashing algorithm is similar to the ExPetr one.

| A- volo artis = = f. D = ] B-1 l- '+ - = = ] F = Dotus hools van varians = ' |  |  |  |  |  |  |  |  |
|------------------------------------------------------------------------------|--|--|--|--|--|--|--|--|
|                                                                              |  |  |  |  |  |  |  |  |
|                                                                              |  |  |  |  |  |  |  |  |
|                                                                              |  |  |  |  |  |  |  |  |
|                                                                              |  |  |  |  |  |  |  |  |
|                                                                              |  |  |  |  |  |  |  |  |

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_6_Figure_3.jpeg)

#### Show details >

QUISERCENTRICS Cookiebot

email address to "AO Kaspersky Lab" to receive information about new posts on the site. I understand that I can withdraw this consent at any time via e-mail by

clicking the "unsubscribe" link that I find at the bottom of any e-mail sent to me for the purposes mentioned above.

Subscribe

QUISERCENTRICS Cookiebot

#### This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_7_Figure_5.jpeg)

the DiskCryptor driver dcrypt.sys (which is installed into C:Windowscscc.dat). The ransomware sends the necessary

IOCTL codes to this driver. Some functions are taken as is from the sources of DiskCryptor (drv\_ioctl.c), others seem to be implemented by the malware developers.

The disk partitions on the infected machine are encrypted by the DiskCryptor driver using the AES cipher in XTS mode. The password is generated by dispci.exe using the WinAPI function CryptGenRandom and has a length of 32 symbols.

### This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_8_Figure_4.jpeg)

#### Show details >

QUISERCENTRICS Cookiebot

enoi young

As part of our analysis, we extracted the password generated by the malware during a debugging session and attempted to enter this password when the system was locked after reboot. The password indeed worked and the boot-up process continued.

![](_page_9_Figure_3.jpeg)

Assessing the Y, and How, of the XZ Utils incident

XZ backdoor story -Initial analysis

> QUSERCENTRICS Cookiebot

Show details >

#### This website uses cookies

![](_page_10_Figure_5.jpeg)

#### Key derivation algorithm

The encrypted password, along with information about the infected system is written into Readme file as "personal installation key#2".

#### This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

QUISERCENTRICS Cookiebot

![](_page_11_Figure_4.jpeg)

![](_page_12_Figure_3.jpeg)

- Trojan-Ransom.Win32.Gen.ftl
- Trojan-Ransom.Win32.BadRabbit
- · DangerousObject.Multi.Generic
- PDM:Trojan.Win32.Generic
- · Intrusion.Win.CVE-2017-0147.sa.leak

![](_page_13_Figure_0.jpeg)

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_13_Figure_3.jpeg)

else no random string Kaspersky Lab experts are working on a detailed analysis of multibyte2wide to find possible flaws in its cryptographic routines.

sorry for nag

Reply

As part of the full list of embedded hashes of process names, I see three McAfee Endpoint Security 10.x processes (0xE5A05A00 mcshield.exe {McAfee Scanner Service}; 0xC8F10976 mfevtps.exe {McAfee Process Validation Service}; 0x923CA517 McTray.exe {McTray Application}), kindly clarify what role they play Runtime flags initialization routine.

### Reply

FRBA

Posted on October 26, 2017. 1:24 pm

This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

QUISERCENTRICS Cookiebot

![](_page_14_Figure_6.jpeg)

# // LATEST WEBINARS

![](_page_15_Picture_0.jpeg)

![](_page_15_Figure_3.jpeg)

by clicking the "unsubscribe" link that l find at the bottom of any e-mail sent to me for the purposes mentioned above.

| kasnerskv | THREATS | CATEGORIES | OTHER SECTIONS              |
|-----------|---------|------------|-----------------------------|
|           |         |            |                             |
|           |         |            | QUISERCENTRICS<br>Cookiebot |

#### This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_16_Figure_4.jpeg)

Show details >