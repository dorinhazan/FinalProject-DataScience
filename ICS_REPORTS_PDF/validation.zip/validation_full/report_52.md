![](_page_0_Picture_0.jpeg)

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_0_Figure_3.jpeg)

GReAT Ideas. Powered by SAS: threat hunting and new techniques

DMITRY BESTUZHEV, COSTIN RAIU, PIERRE DELCHER, BRIAN BARTHOLOMEW, BORIS LARIN, ARIEL JUNGHEIT, FABIO ASSOLINI

![](_page_1_Figure_0.jpeg)

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_1_Figure_3.jpeg)

Show details >

#### This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_2_Figure_3.jpeg)

Procedure for selecting the appropriate shellcode option

Since the binary being analyzed is a 32-bit executable file, we are interested in how it manages to execute 64-bit code in its address space. The screenshot shows a shellcode snippet for executing 64-bit processor instructions:

Ransomware in the CIS

QUSERCENTRICS Cookiebot

# This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_3_Figure_5.jpeg)

After executing the command for RVA addresses 6 and 7, the long return address is stored at the top of the stack in the format selector:offset, and takes the form 0x23:0x0C. In the stack at offset 0x11, a DWORD is placed whose low-order word contains the selector 0x33 and whose high-order word encodes the instruction retf, the opcode of which is equal to 0xCB.

#### This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

QUISERCENTRICS Cookiebot

![](_page_4_Figure_3.jpeg)

# Returning to 32-bit mode

The retf command makes a far intrasegment jump to the address 0x23:0x0C (it was placed in the instruction stack at the very start of the shellcode, at the RVA address 6-7). This technique of

executing 64-bit code in a 32-bit process address space is called Heaven's Gate, and was first described around ten years ago.

# Trojan configuration

Stored in encrypted form in the body of each Sodin sample is a configuration block containing the settings and data required for the Troian to work

This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_5_Figure_5.jpeg)

| nname | ransom note file name template          | any time via e-mail by                                                  |
|-------|-----------------------------------------|-------------------------------------------------------------------------|
| exp   | use of exploit for privilege escalation | clicking the "unsubscribe"<br>link that I find at the                   |
| ımg   | text for desktop wallpaper              | bottom of any e-mail sent<br>to me for the purposes<br>mentioned above. |
|       |                                         | Subscribe                                                               |
|       |                                         | QUISERCENTRICS<br>Cookiebot                                             |

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_6_Figure_3.jpeg)

Show details >

under the name pk\_key, while the private key is encrypted using the ECIES algorithm with the sub\_key key and stored in the registry under the name sk\_key. The ECIES implementation in this case includes the Curve25519 elliptic curve, the SHA3-256 cryptographic hash, and the AES-256 block cipher in CFB mode. Other ECIES implementations have been encountered in Trojans before, for example, in SynAck targeted ransomware.

Curiously, the same private session key is also encrypted with another public key hardcoded into the body of the Trojan, regardless of the configuration. We will call it the public skeleton key. The encryption result is stored in the registry under the name 0\_key. It turns out that someone who knows the private key corresponding to the public skeleton key is able to decrypt the victim's files, even without the private key for sub\_key. It seems like the Trojan developers built a loophole into the algorithm

#### This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_7_Figure_3.jpeg)

Show details >

In addition to the fields discussed above, there is also a nonce (random initialization 8 bytes for the Salsa20 cipher), file\_pub\_crc32 (checksum for file\_pub), flag\_fast (if set, only part of the data in the file is encrypted), zero\_encr\_by\_salsa (null dword encrypted by the same Salsa20 key as the file contents seemingly to check the correctness of the decryption).

The encrypted files receive a new arbitrary extension (the same

# This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_8_Figure_4.jpeg)

Show details >

Fragment of the desktop wallpaper created by the ransomware

# Network communication

If the corresponding flag is set in the configuration block, the Trojan sends information about the infected machine to its servers. The transmitted data is also encrypted with the ECIES algorithm using vet another hardcoded nublic kev

# This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_9_Figure_5.jpeg)

| ഠട  | OS version                      |
|-----|---------------------------------|
| bit | architecture                    |
| dsk | information about system drives |
| ext | extension of encrypted files    |
|     |                                 |

QUISERCENTRICS Cookiebot

# This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our site with our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_10_Figure_3.jpeg)

More information about Kaspersky cybersecurity services can be found here: 

#### New product

Let's go Next: redefine your business's cybersecurity

> QUISERCENTRICS Cookiebot

oc

# This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

![](_page_11_Figure_6.jpeg)

MALWARE DESCRIPTIONS

Attackers distributing a miner and the

![](_page_11_Picture_9.jpeg)

How ToddyCat tried to hide behind AV

RESEARCH

A journey into forgotten Null Session MALWARE DESCRIPTIONS

TookPS: DeepSeek isn't the only game in

| ClipBanker  Irojan via | software      | and MS-RPC<br>interfaces, part 2 | town               |
|------------------------|---------------|----------------------------------|--------------------|
| SourceForge            |               |                                  | VASILY KOLESNIKOV. |
| AMR                    | ANDREY GUNKIN | HAIDAR KABIBO                    | OLEG KUPREEV       |

# // LATEST WEBINARS

#### This website uses cookies

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

QUISERCENTRICS Cookiebot

![](_page_12_Figure_4.jpeg)

นเจบบขนายน a บบเทที่มีเพิ่ม AFT 1 สเเลนห on Russian organizations dubbed Operation ForumTroll, which exploits zero-day vulnerabilities in Google Chrome.

and | TE > useu III rue > nue vinne as shifts in its targets, such as an increase in attacks against the maritime and logistics sectors.

| / SUBSCRIBE TO OUR<br>WEEKLY E-MAILS        | Email                                                                                                                                                   | ><br>Subscriber             |
|---------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| The hottest research right in your<br>inbox | l agree to provide my email address<br>to "AO Kaspersky Lab" to receive<br>information about new posts on the<br>site. I understand that I can withdraw |                             |
|                                             |                                                                                                                                                         | JUSERI:FUTKICS<br>Cookiebot |

We use cookies to personalise content and ads, to provide social media features and to analyse our traffic. We also share information about your use of our social media, advertising and analytics partners who may combine it with other information that you've provided to them or that they've collected from your use of their services.

| Necessary   |                    |
|-------------|--------------------|
| Preferences | o                  |
| Statistics  | o                  |
| Marketing   | C                  |
|             | Show details     > |