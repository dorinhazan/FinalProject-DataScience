Democracy Dies in Darkness

## More than 150 countries affected by massive cyberattack, Europol says

May 14, 2017

By Elizabeth Dwoskin and Karla Adam

Europol confirmed Sunday that computer networks in more than 150 countries and more than 200,000 people had been affected by one of the biggest cybersecurity attacks in recent history. "It is the biggest ransomware attack ever," Europol spokesman Jan Op Gen Oorth said.

The number of affected networks and individuals is likely to go up, he said, because "many workers left their computer turned on last Friday and will probably find out that they are also affected by the malware on Monday morning."

Although the investigation is ongoing, Europol thinks the malware began to spread Friday from Britain's National Health Service. It then affected other networks including Germany, Spain, China, Russia and India.

"It remains unclear what the motivation was. Usually, 'ransomware' attacks are designed to be revenue sources, but in this case the ransom was quite low," Op Gen Oorth said. According to Europol, only few companies or individuals have so far opted to pay the ransom of \$300 or more, following law enforcement recommendations.

Organizations around the world faced potentially substantial costs after hackers threatened to keep computers disabled unless victims paid a ransom to receive a decryption key.

The malware hit Britain's beloved but creaky National Health Service particularly hard, causing widespread disruptions and interrupting medical procedures across hospitals in England. The government said that 48 of the NHS's 248 organizations were affected, but by Saturday evening all but six were back to normal.

When asked if the British government paid any ransom in this situation, a Downing Street spokesman said Saturday that it had not. Amber Rudd, Britain's home secretary, also advised against others paying ransom.

In Germany, people posted pictures on social media of scheduling screens at train stations displaying the ransomware message. Deutsche Bahn, Germany's national railway service, tweeted that its train service had not been compromised and that it was working full speed to solve the problems. According to DPA news agency, Deutsche Bahn's video surveillance technology also was hit.

Other targets in Europe included Telefónica, the Spanish telecom giant; the French carmaker Renault; and a local authority in Sweden, which said about 70 computers were infected.

It was still unclear who was behind the sophisticated attack.

"We're not able to tell you who is behind that attack. That work is still ongoing," Rudd told the BBC. She said that it has affected "up to 100 countries" and that it wasn't specifically targeted at Britain's NHS.

The attack was notable because it took advantage of a security flaw in Microsoft software found by the National Security Agency for its surveillance tool kit. Files detailing the capability were leaked online last month, though after Microsoft, alerted by the NSA to the vulnerability, had sent updates to patch the hole.

Still, countless systems were left vulnerable, either because system administrators failed to apply the patch or because they used outdated software.

It was a jarring reminder of a stubborn reality facing security experts: Companies and other organizations collectively spent \$73 billion on cybersecurity measures in 2016, according to the research firm IDC. Yet systems around the world were crippled by human error - failure to do routine software updates and employees unknowingly clicking on email attachments that contained the malware.

"This was a completely preventable attack - to the extent that organizations have comprehensive patching systems in place," said Paul Lipman, chief executive of the cybersecurity firm BullGuard. "However, life is never that simple."

On Friday, Microsoft released additional security updates to Windows and guidelines for consumers and businesses to protect themselves.

It's possible that the malware didn't spread further because of the enterprising work of a 22-year-old British cybersecurity researcher.

The researcher, whose Twitter handle is @MalwareTechBlog, realized the hackers had designed a "kill switch," which involved a domain name that enabled them to stop the attack from spreading if the victims paid the ransoms. The researcher bought the domain name of the kill switch, and when the site went live, the attack stopped spreading.

The move didn't help organizations that were already affected by the attack, but experts said that it limited the spread of the virus. The researcher, however, warned in a blog post that the hackers could alter the code and try again.

## Hospitals called ideal targets

Health-care IT experts said it was no surprise that hospitals so easily fell victim to the ransomware attack. Health systems have faced hundreds of ransomware attacks in the past two years.

They are the ideal target for this type of malware due to a "perfect storm" of factors, said Avi Rubin, technical director of the Information Security Institute at Johns Hopkins University. For one, Rubin said, the data that they have is incredibly time-sensitive, making them most susceptible to ransomware.

"If no one ever paid these ransoms, the hackers would have no reason to launch these attacks," Rubin said. "But I'm not the one sitting in a hospital in need of immediate medical attention."

Hospitals also lag far behind other in upgrading their security and doing basic software updates. Healthcare organizations in general spend 2 to 4 percent of their operating budgets on information technology, compared with 25 to 35 percent for financial services, said John D. Halamka, chief information officer of the Beth Israel Deaconess Medical Center and Harvard Medical School.

"We spend billions on new technology" he said. "Yet the reality is that we're still as vulnerable as our most gullible employee."

Health-care organizations in the United States are also subject to additional regulations, which constrain their ability to do updates. Many updates require systems to go dark for some period of time, and many hospitals are not allowed to put critical systems out of use.

Poorer hospitals are particularly vulnerable. While wealthy hospitals have effectively built cybersecurity war rooms over the past two years, some smaller hospitals "don't have enough budget to keep the lights on," said Rubin. They often cannot afford to back up data, perhaps the most critical tool in fighting ransomware.

Cybersecurity researchers were far more surprised that sophisticated telecommunications firms, such as Spain's Telefónica, were so vulnerable. "This just goes to show that even the largest, most resource-rich enterprises can be brought low by something as simple as a skipped patch," said Lipman.

## Russia hit hard

The malware, known as WanaCryptor 2.0, or WannaCry, also affected systems for FedEx, major telecommunications firms, Brazil's social security administration, and many others around the world.

TMT post, a Chinese online news outlet focusing on the Internet industry, reported that a number of Chinese universities had been affected by the attack.

Several schools - including Nanchang University, Shandong University of Electronic Science and Technology of China — issued alerts on their Weibo social-media feeds, warning staff and students to back up important files and not to open suspicious emails.

According to Chinese magazine Caijing, some students' graduation theses and projects have reportedly been encrypted.

In Russia, hacking attacks were confirmed Saturday at the Health Ministry, the state-run Russian Railways and the telecommunications company Megafon, along with the Interior Ministry, which manages the police force. There were also reports that the powerful Investigative Committee, which investigates high-level crime, and several other telecommunications companies had been targeted.

The Interior Ministry said that 1,000 of its computers had been blocked by prompts demanding payment. By Friday evening, the ministry said it had "contained" the attack and denied that any of its information had been stolen.

Jakub Kroustek, a malware researcher with Avast, a security software company in the Czech Republic, said in a blog post that Russia was the most-affected country so far. "We are now seeing more than 75,000 detections of WanaCryptor 2.0 in 99 countries," he wrote Friday night.

Kaspersky Lab, a Moscow-based Internet security firm, also said that the attacks were mostly in Russia.

One reason Russia may have been hit so hard is the use of outdated software by government agencies.

"Russia has a very rickety, out-of-date infrastructure, using not just outdated software but-of-date software," said Mark Galeotti, a senior researcher at the Institute of International Relations Prague.

According to Galeotti, one Interior Ministry official in 2013 estimated that 40 percent of the ministry's computers could be using pirated Windows software, which is widely available in Russia for download or at local computer markets.

In Brazil, the attack struck at the heart of the government - employee computers at the Justice Ministry and Brazil's social security administration were infected. The local media also reported that the attack locked up computers in the country's labor courts and the public prosecutor's office.

In Britain, which is in the middle of an election campaign, the cyberattack triggered criticism of the NHS's aging computer systems, particularly the use of Windows XP, an outdated version of the Microsoft operating system that doesn't have the same level of defense against cyberattacks as newer operating systems.

The opposition Labour Party's Jonathan Ashworth tweeted that the government had been complacent over cybersecurity. "We need answers on whether funding squeeze compromised security," he wrote.

Rudd, the home secretary, stressed that there was no evident data had been compromised but said that there were lessons to learn.

She told the BBC that Windows XP was "not a good platform for keeping your data as secure as the modern ones because you can't download the effective patches and anti-virus software."

"I would expect NHS trusts to learn from this and to make sure that they do upgrade," she said.

Adam reported from London: Rick Noack in London; Andrew Roth in Moscow; Luna Lin in Beijing; Griff Witte and Stephanie Kirchner in Berlin; Marina Lopes in Sao Paulo; and Michael Birnbaum in Tallinn, Estonia, contributed to this report.