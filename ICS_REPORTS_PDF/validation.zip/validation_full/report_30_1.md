![](_page_0_Picture_0.jpeg)

![](_page_0_Picture_1.jpeg)

Manage My Cookie Settings

O

![](_page_1_Picture_0.jpeg)

4 paloalto" | 7 UNIT 42"

# Threat insights that matter.

Trusted expertise from leaders in incident response.

![](_page_1_Picture_4.jpeg)

# Table of Contents

| e | enabled                                                      |  |
|---|--------------------------------------------------------------|--|
|   | Ensure all WildFire session information settings are enabled |  |

|        |                           | Cortex<br>XDR              | Configure Malware Security Profile                                                                                         |
|--------|---------------------------|----------------------------|----------------------------------------------------------------------------------------------------------------------------|
|        |                           | Cortex<br>XSOAR            | Deploy XSOAR Playbook - Phishing Investigation - Generic<br>V2                                                             |
|        |                           |                            | Deploy XSOAR - Endpoint Malware Investigation                                                                              |
| Execut | Scheduled Task            | Cortex<br>XDR              | Enable Anti-Exploit                                                                                                        |
| ion    | (T1053)                   |                            | Enable Anti-Malware Protection                                                                                             |
|        | User Execution<br>(T1204) | NGFW                       | Ensure that User-ID is only enabled for internal trusted<br>interfaces                                                     |
|        |                           |                            | Ensure that 'Include/Exclude Networks' is used if User-ID is<br>enabled                                                    |
|        |                           |                            | Ensure that the User-ID Agent has minimal permissions if<br>User-ID is enabled                                             |
|        |                           |                            | Ensure that the User-ID service account does not have<br>interactive logon rights                                          |
|        |                           |                            | Ensure remote access capabilities for the User-ID service<br>account are forbidden.                                        |
|        |                           |                            | Ensure that security policies restrict User-ID Agent traffic<br>from crossing into untrusted zones                         |
|        |                           | Threat<br>Preven<br>tion t | Ensure that antivirus profiles are set to block on all decoders<br>except 'imap' and 'pop3'                                |
|        |                           |                            | Ensure a secure antivirus profile is applied to all relevant<br>security policies                                          |
|        |                           |                            | Ensure an anti-spyware profile is configured to block on all<br>spyware severity levels, categories, and threats           |
|        |                           |                            | Ensure DNS sinkholing is configured on all anti-spyware<br>profiles in use                                                 |
|        |                           |                            | Ensure passive DNS monitoring is set to enabled on all anti-<br>spyware profiles in use                                    |
|        |                           |                            | Ensure a secure anti-spyware profile is applied to all security<br>policies permitting traffic to the Internet             |
|        |                           | DNS<br>Securit<br>y        | Enable DNS Security in Anti-Spyware profile                                                                                |
|        |                           | URL                        | Ensure that PAN-DB URL Filtering is used                                                                                   |
|        |                           |                            | Ensure that URL Filtering uses the action of "block" or<br>"override" on the <enterprise approved value> URL<br>categories |
|        |                           | Filtorin                   |                                                                                                                            |

|                |                                               | WildFir<br>e           | Ensure that WildFire file size upload limits are maximized                                              |
|----------------|-----------------------------------------------|------------------------|---------------------------------------------------------------------------------------------------------|
|                |                                               |                        | Ensure forwarding is enabled for all applications and file<br>types in WildFire file blocking profiles  |
|                |                                               |                        | Ensure a WildFire Analysis profile is enabled for all security<br>policies                              |
|                |                                               |                        | Ensure forwarding of decrypted content to WildFire is<br>enabled                                        |
|                |                                               |                        | Ensure all WildFire session information settings are enabled                                            |
|                |                                               |                        | Ensure alerts are enabled for malicious files detected by<br>WildFire                                   |
|                |                                               |                        | Ensure 'WildFire Update Schedule' is set to download and<br>install updates every minute                |
|                |                                               | Cortex                 | Enable Anti-Exploit                                                                                     |
|                |                                               | XDR<br>Cortex<br>XSOAR | Enable Anti-Malware Protection                                                                          |
|                |                                               |                        | Deploy XSOAR Playbook - Phishing Investigation - Generic<br>V2                                          |
|                |                                               |                        | Deploy XSOAR Playbook - Cortex XDR - Isolate Endpoint                                                   |
|                |                                               |                        | Deploy XSOAR - Block Account Generic                                                                    |
|                | Bootkit (T1067)                               |                        | Enable Anti-Exploit                                                                                     |
| Persist        |                                               | Cortex<br>XDR          | Enable Anti-Malware Protection                                                                          |
| ence           | Scheduled Task<br>(T1053)                     |                        | Enable Anti-Exploit                                                                                     |
|                |                                               |                        | Enable Anti-Malware Protection                                                                          |
| Privile<br>ge  |                                               |                        | Enable Anti-Exploit                                                                                     |
| Escala<br>tion |                                               |                        | Enable Anti-Malware Protection                                                                          |
| Crede          | Credential in<br>Files (T1080)                |                        | Enable Anti-Exploit                                                                                     |
| ntial<br>Acces |                                               |                        | Enable Anti-Malware Protection                                                                          |
| S              |                                               |                        | Configure Restrictions Security Profile                                                                 |
| Discov<br>ery  | File and<br>Directory<br>Discovery<br>(T1083) |                        | XDR monitors for behavioral events via BIOCs along a<br>causality chain to identify discovery behaviors |
|                | Process<br>Discovery<br>(T1057)               |                        | XDR monitors for behavioral events via BIOCs along a<br>causality chain to identify discovery behaviors |
|                | Automated                                     |                        | Enable Anti-Exploit                                                                                     |

| Comm<br>and<br>and<br>Contro | Custom<br>Command and<br>Control (T1094) | NGFW                       | Ensure application security policies exist when allowing<br>traffic from an untrusted zone to a more trusted zone          |
|------------------------------|------------------------------------------|----------------------------|----------------------------------------------------------------------------------------------------------------------------|
|                              |                                          |                            | Ensure 'Service setting of ANY' in a security policy allowing<br>traffic does not exist                                    |
|                              |                                          |                            | Ensure 'Security Policy' denying any/all traffic to/from IP<br>addresses on Trusted Threat Intelligence Sources Exists     |
|                              |                                          | Threat<br>Preven<br>tion t | Ensure that antivirus profiles are set to block on all decoders<br>except 'imap' and 'pop3'                                |
|                              |                                          |                            | Ensure a secure antivirus profile is applied to all relevant<br>security policies                                          |
|                              |                                          |                            | Ensure an anti-spyware profile is configured to block on all<br>spyware severity levels, categories, and threats           |
|                              |                                          |                            | Ensure DNS sinkholing is configured on all anti-spyware<br>profiles in use                                                 |
|                              |                                          |                            | Ensure passive DNS monitoring is set to enabled on all anti-<br>spyware profiles in use                                    |
|                              |                                          |                            | Ensure a secure anti-spyware profile is applied to all security<br>policies permitting traffic to the Internet             |
|                              |                                          | DNS<br>Securit<br>y        | Enable DNS Security in Anti-Spyware profile                                                                                |
|                              |                                          |                            | Ensure that PAN-DB URL Filtering is used                                                                                   |
|                              |                                          | URL<br>Filterin<br>g       | Ensure that URL Filtering uses the action of "block" or<br>"override" on the <enterprise approved value> URL<br>categories |
|                              |                                          |                            | Ensure that access to every URL is logged                                                                                  |
|                              |                                          |                            | Ensure all HTTP Header Logging options are enabled                                                                         |
|                              |                                          |                            | Ensure secure URL filtering is enabled for all security policies<br>allowing traffic to the Internet                       |
|                              |                                          | Cortex<br>XSOAR            | Deploy XSOAR Playbook - Block IP                                                                                           |
|                              |                                          |                            | Deploy XSOAR Playbook - Block URL                                                                                          |
|                              |                                          |                            | Deploy XSOAR Playbook - Hunting C&C Communication<br>Playbook                                                              |
|                              |                                          |                            | Deploy XSOAR Playbook - PAN-OS Query Logs for Indicators                                                                   |
|                              | Data Encrypted<br>for Impact<br>(T1486)  | Cortex<br>XDR              | Enable Anti-Malware Protection                                                                                             |
| Impact                       |                                          |                            | Enable the "Anti-Ransomware" security module in your<br>security profile                                                   |
|                              |                                          | Cortex                     | Deploy XSOAR Playbook - Ransomware Manual for incident                                                                     |

# Conclusion

EKANS is a relatively new ransomware, and we still continue to investigate the threat, that's active targeting vulnerable enterprises for financial gain.

Although we haven't seen EKANS leveraging compromised RDP, one of ransomware's top intrusion vectors are unsecured RDP ports. It's always good practice to close those ports if they are not needed, or secure them. We encourage having the proper protections and best practices in place to prevent EKANS into getting into, or executing within, your network.

ICS asset owners should particularly be aware of this ransomware as it tries to kill ICS-related processes, so reviewing their security posture against this threat is recommended.

The suggested courses of action in this report are based on the information currently available to Palo Alto Networks and the capabilities within Palo Alto Networks' products and services.

# Additional Resources

- • EKANS Ransomware Analysis Updates
	- · Matrix Enterprise | MITRE ATT&CK®
	- · Best Practices from Palo Alto Networks
	- Script and the decoded strings from the EKANS/Snake ransomware

#### Back to top

#### TAGS

Ekans

< Threat Research Center

Next: Attackers Cryptojacking Docker Images to Mine for > Monero

# Related Resources

![](_page_5_Picture_16.jpeg)

Cascading Shadows: An Attack Chain Approach to Avoid Detection and Complicate Analysis

![](_page_6_Picture_1.jpeg)

Slow Pisces Targets Developers With Coding Challenges and Introduces New Customized Python Malware

Infostealer ) ( DPRK ) ( Cryptocurrency

## ewsletter

은 지 42 Get updates from Unit 42 Sma Logi

Peace of mind comes from staying ahead of threats. Contact us today.

Your Email

Subscribe for email updates to all Unit 42 threat research. By submitting this form, you agree to our Terms of Use and acknowledge our Privacy Statement.

![](_page_6_Picture_10.jpeg)

## Products and Services

## Company

#### Popular Links

![](_page_7_Picture_0.jpeg)

Privacy

Trust Center

Terms of Use

Documents

Copyright © 2025 Palo Alto Networks. All Rights Reserved