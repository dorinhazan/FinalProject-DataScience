REQUEST DEMO

# THRFAT ANALYSIS REVIL/SODINOKIBI RANSOMWARE

Counter Threat Unit Research Team September 24, 2019

# SUMMARY

The REvil (also known as Sodinokibi) ransomware was first identified on April 17, 2019. It is used by the financially motivated GOLD SOUTHFIELD threat group, which distributes ransomware via exploit techniques, RDP servers, and backdoored software installers. Secureworks® Counter Threat Unit™ (CTU) analysis suggests that REvil is ikely associated with the GandCrab ransomware due to similar code and the emergence of REvil as GandCrab activity declined. CTU™ researchers attribute GandCrab threat group.

REvil can perform the following tasks. Most of these capabilities are configurable, which allows an attacker to fine-tune the payload.

- Exploit the CVE-2018-8453 vulnerability to elevate privileges
- Terminate blacklisted processes prior to encryption to eliminate resource conflicts
- Wipe the contents of blacklisted folders
- Encrypt non-whitelisted files and folders on local storage devices and network shares
- · Exfiltrate basic host information

# CONFIGURATION

The REvil sample analyzed by CTU researchers stored the encoded configuration as a resource named .m69 (see Figure 1) within the unpacked binary. The first 32 bytes of this resource form the key used to decode the configuration. The remaining bytes are the encoded configuration.

| Sodinokibi_unpacked.exe                                                                                                                                                                    |                        |                          |            |                 |            |            |            |             |            |              |             |           |              |            |                |                                                 | ×         |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------|--------------------------|------------|-----------------|------------|------------|------------|-------------|------------|--------------|-------------|-----------|--------------|------------|----------------|-------------------------------------------------|-----------|
| Name                                                                                                                                                                                       | Virtual Size           |                          |            | Virtual Address |            |            | Raw Size   |             |            |              | Raw Address |           |              |            | Reloc Address  | Inenumbers                                      | N<br>Reli |
| 00000240                                                                                                                                                                                   | 00000248               |                          |            | 0000024C        |            |            | 00000250   |             |            | 00000254     |             |           | 0000258      | 000025C    | 000            |                                                 |           |
| Dword<br>Byte[8]                                                                                                                                                                           |                        |                          | Dword      |                 |            | Dword      |            |             |            | Dword        |             |           | Dword        | Dword      | Wo             |                                                 |           |
| 0000A000<br>.text                                                                                                                                                                          |                        |                          | 00001000   |                 |            | 0000A000   |            |             |            | 00001000     |             |           | 000000000    | 000000000  | 000            |                                                 |           |
| .rdata                                                                                                                                                                                     | 00010000               |                          |            | 0000B000        |            |            | 00010000   |             |            | 0000B000     |             |           | 000000000    | 000000000  | 000            |                                                 |           |
| .data                                                                                                                                                                                      | 00002000               |                          |            | 0001B000        |            |            | 00002000   |             |            | 0001B000     |             |           | 000000000    | 000000000  | 000            |                                                 |           |
| .m69                                                                                                                                                                                       | 0000D000               |                          |            | 0001 D000       |            |            | 0000D000   |             |            | 0001 DO00    |             |           | 0000000000   | 000000000  | 000            |                                                 |           |
| .reloc                                                                                                                                                                                     | 00001000               |                          |            | 0002A000        |            |            | 00001000   |             |            | 0002A000     |             |           | 000000000    | 000000000  | 000 V          |                                                 |           |
| <                                                                                                                                                                                          |                        | Configuration Resource   |            |                 |            |            |            |             |            |              |             |           |              |            |                |                                                 | >         |
| 1                                                                                                                                                                                          |                        | C                        |            | ill             |            |            |            |             |            |              |             |           | Decoding Key |            |                | Encoded Configuration                           |           |
|                                                                                                                                                                                            |                        |                          |            |                 |            |            |            |             |            |              |             |           |              |            |                |                                                 |           |
| Offset<br>000000000                                                                                                                                                                        | 0<br>1<br>56           | 2<br>3<br>50<br>62       | র্য<br>54  | 5               | 6          | 7<br>63    | 8          | 9<br>ਵ ਰੇ   | A          | в            | C<br>62     | D         | F            | F<br>69    | ASC11          |                                                 |           |
| 00000010                                                                                                                                                                                   | 6F<br>45<br>70         | 4C<br>38                 | 50         | 61<br>76        | 64<br>67   | 79         | 4 4<br>73  | 6B          | 54<br>4 E  | 50<br>6F     | 56          | 45<br>79  | 71<br>45     | 4 D        |                | oVPbZadcDYTPBEqi<br>EpL8PvgyskNoVyEM            |           |
| 00000020<br>00000030                                                                                                                                                                       | De<br>6C<br>C4<br>79   | E5<br>CE<br>88<br>AF     | ਕੇ ਦ<br>F8 | 64<br>76        | 00<br>22   | 00<br>84   | F7<br>60   | 22<br>101   | 00<br>BF   | 8F<br>410    | 18<br>5F    | 43<br>15  | 45<br>14     | 51<br>A3   | TO AS BELL - " | 1040<br>Ay   ev "   mNiM__gle                   |           |
| 00000040                                                                                                                                                                                   | 72<br>1B               | 45<br>BB                 | 98         | 98              | E 9        | 11         | 3 d        | 18          | 70         | 66           | 8 ਰੋ        | ਰੇ ਰੇ     | CC           | DC         |                | +r*>>    u=9 · pf                               |           |
| 00000050<br>00000060                                                                                                                                                                       | 9D<br>C8<br>18<br>6 E. | 23<br>A2<br>CF<br>3D     | EA<br>E ਰੇ | 34<br>11        | 0C<br>12.9 | E9<br>12   | 11<br>10   | 0C<br>65    | DE<br>56   | AD<br>25     | 88<br>71    | 48<br>013 | 00<br>23     | 00<br>F1   |                | E#cê4 léalb-l                                   |           |
| 0000070                                                                                                                                                                                    | E9<br>64               | FD<br>00                 | 25         | 51              | 34         | 85         | ਕੇ ਰੋ      | 0D          | EE         | 11           | 3 ਦ         | 32        | 54           | FO         |                | n+I=é ui î eV%qFi#n<br>édý . %Q: II . 1-1>2Z8   |           |
| 00000080                                                                                                                                                                                   | 73<br>B5               | E6<br>E 9                | OD         | 80              | ਰੇ ਪੈਂ     | ਰੇ I       | F9         | 6B          | C3         | 13           | 28          | 4 F       | 25           | C1         |                | psæù . II ukall (O%A                            |           |
| 00000090<br>000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 | 28<br>C4<br>63<br>OB   | 90<br>06<br>C2<br>25     | F1<br>0B   | EA<br>ട് ഇ      | BB<br>ਰੇ 5 | CD<br>ਦ ਰੇ | CC<br>4C   | 93<br>29    | 19<br>ਰੇ ਤ | 5D<br>84     | B2<br>ਰੇ ਦ  | 86<br>D4  | EE<br>ЗВ     | BB<br>08   |                | (A -ne>>ÍÌI - ] 2 lî»<br>0, 0 11 11 ( 11 10 : 0 |           |
| 0000000000                                                                                                                                                                                 | CA<br>54               | A4<br>AC                 | 03         | DC              | 53         | AD         | ਦ ਰੋ       | C3          | ਰੇ ਰੇ      | । ਰੇ         | 87          | 08        | 7C           | F7         |                | EZ¤-LÜS-iÃI HIO =                               |           |
| 0000000000                                                                                                                                                                                 | F5<br>16               | 9F<br>6E                 | B5         | Ba              | C3         | 5 E        | 5B         | 03          | 51         | 18           | C5          | 0C        | 1D           | ਤੇ ਰੇ      |                | 2-1np1 1 A ^ [ -C -- Å  <br>9                   |           |
| 0000000000<br>0000000000                                                                                                                                                                   | 7D<br>3F<br>4 4<br>128 | AF<br>17<br>87<br>ਰੇ ਪੈਂ | B5<br>76   | AB<br>B3        | FC<br>48   | 4 D<br>OD  | ਿਰੇ<br>41  | 5F<br>CC    | E6<br>7E   | 27<br>ਇੱਕ ਰੋ | A1<br>A6    | BA<br>45  | 01<br>IDC    | 23<br>33   |                | } ? + p < uME o' i e<br>#<br>Jèllv3H.AÍ~ù ¥i3   |           |
| 00000000000                                                                                                                                                                                | 0D<br>92               | 53<br>53                 | 6E         | FC              | 29         | 89         | CB         | CB          | ਕੇ ਰੇ      | 93           | FB          | 14        | 7E           | E5         |                | SSnu) IEEI Iûqra                                |           |
| 00000100                                                                                                                                                                                   | EF<br>EC               | 78<br>67                 | 6A         | B5              | CB         | 40         | AE         | 8 ਦ         | 6F         | ਕੇ ਰੇ        | aD          | ਦੇ ਰੇ     | 62           | FC         |                | iixqjpE@® oI Ybu                                |           |
| 00000110                                                                                                                                                                                   | 05<br>A4               | CD<br>013                | 05         | 63              | 6C         | 13         | C1         | 88          | ਦ ਰੇ       | 6A           | 9D          | 77        | 96           | 0A         |                | ■   IQ   cluAlij w   .                          |           |
| 00000120<br>00000130                                                                                                                                                                       | 22<br>C2<br>86<br>88   | 12<br>24<br>E4<br>D6     | BC<br>Be   | 05<br>82        | E8<br>A5   | 94<br>E0   | 92<br>34   | 21<br>63    | ਿਰੇ<br>D7  | 81<br>63     | BD<br>75    | A7<br>50  | E1<br>C8     | 16<br>ਰੇ 3 |                | "Al ** El. IE XS 9-<br>    a0     *à : cxcuPE   |           |
| 00000140                                                                                                                                                                                   | B4<br>6B               | 2B<br>IDID               | 8B         | 8 4             | FC         | 7D         | 50         | 35          | aD         | 8C           | 55          | 312       | E0           | 68         |                | k+i  u}\?  U>ak                                 |           |
| 00000150                                                                                                                                                                                   | A6<br>C2               | CE<br>8C                 | 79         | EA              | 20         | 07         | BE         | 44          | D4         | CB           | 51          | 53        | B4           | 60         |                | AÆ�yê . - ¾JOEQS                                |           |
| 00000160                                                                                                                                                                                   | 50<br>61               | 60<br>EII                | A0         | F6              | 30         | B8         | 11         | 7C          | E7         | 68           | 50          | 01        | ਰ ਤੋ         | 46         |                | a à à c< chF IF                                 |           |
| 00000170<br>0000180                                                                                                                                                                        | 35<br>FO<br>3F<br>C5   | 7B<br>1212<br>38<br>F8   | 83<br>A0   | AB<br>0E        | A1<br>1C   | 138<br>E5  | ਰੇਤੇ<br>55 | 83<br>AE    | 9D<br>A7   | 3F<br>E9     | ਿਰੇ<br>Ea   | 11<br>26  | C2<br>17     | BB<br>De   |                | 58 1 «lell ?E A>><br>?A80 F aU®Séé&- O          |           |
| 00000190                                                                                                                                                                                   | 50<br>A7               | 3 E<br>33                | Ba         | 64              | ਰੇ 3       | 88         | FC         | CD          | 30         | 53           | FF          | F3        | BB           | 47         |                | ]S > 3 - d     u I = Spó> G                     |           |
| 000001A0                                                                                                                                                                                   | a8<br>Al               | A3<br>BA                 | ਕੇ ਰੇ      | 1F              | 55         | CA         | F7         | A3          | 18         | 05           | A2          | 81        | BA           | 52         | 118811         | E=£+O¢<br>a R                                   |           |
| 000001B0                                                                                                                                                                                   | 07<br>AD               | E3<br>30                 | BC         | 22              | F9         | F7         | 79         | 30          | EB         | EC           | 0 ਰੇ        | 46        | D4           | 78         |                | ·- a0%" u=y0ei . FOx                            |           |
| 000001C0<br>000001D0                                                                                                                                                                       | 8C<br>70<br>54<br>EF   | 54<br>ਦੇ ਰੇ<br>2E<br>EF  | B8<br>9D   | 50<br>72        | 88<br>9F   | 97<br>A6   | DF<br>E3   | ਕੇ ਰੇ<br>18 | F2<br>32   | 88<br>BC     | 12<br>F6    | D1<br>FO  | E7<br>E1     | 79<br>43   |                | I ZY , BIOINGy<br>1Z.1 r   a+2408aC             |           |
| 00001E0                                                                                                                                                                                    | 38<br>40               | B1<br>61                 | F6         | 63              | 45         | E4         | 8C         | AB          | ED         | DC           | 87          | E8        | 76           | FC         |                | @8+aocEal «íU lèvu                              |           |
| 00000150                                                                                                                                                                                   | 8 ਰੋ<br>ਰੇ 5           | 8 ਰੇ<br>8 D              | B0         | DD              | 01         | DD         | вз         | 15 0        | 82         | 63           | 14          | 62        | 45           | 02         |                | 1111 * Y 3 y 3 y 1 c 9 bE-                      |           |

Figure 1. REvil executable resource containing the encoded configuration and the decode key. (Source: Secureworks)

The decoded value is a JSON-formatted string that configurable REvil elements. In the sample shown in Figure 2, word-wrapping was disabled due to the value length within the "dmn" and "hbody" configuration keys. As a result, the values in these keys are truncated.

![](_page_1_Picture_3.jpeg)

Figure 2. REvil decoded configuration JSON. (Source: Secureworks)

Table 1 lists the configuration keys and their purpose. An additional REvil configuration parameter not located within the configuration JSON is the "-nolan" switch, which can be passed to the ransomware executable at runtime. By default, REvil attached network shares and encrypt their contents. Passing the -nolan switch to the REvil executable disables this functionality.

Key | Definition

| dbg   | True/false value used by the malware author during development (referenced only when determining if the victim is<br>Russian)             |
|-------|-------------------------------------------------------------------------------------------------------------------------------------------|
| dmn   | Semicolon-delimited list of fully qualified domain names that represent REvil command and control (C2) servers                            |
| exp   | True/false value that determines if REvil attempt to elevate privileges by exploiting a local privilege escalation<br>(LPE) vulnerability |
| fast  | True/false value that determines how files larger than 65535 bytes are encrypted                                                          |
| img   | Base64-encoded value of the text placed at the top of the background image created and set by REvil                                       |
| nbody | Base64-encoded value of the ransomware note text dropped in folders where files were encrypted                                            |
| nname | Filename string of the ransomware note dropped in folders where files were encrypted                                                      |
| net   | True/false value that determines if REvil should attempt to exfiltrate basic host and malware information to the                          |
|       | configured C2 servers listed in the dmn key                                                                                               |
| pid   | Integer value that is only referenced if the "net" key is set to send basic host and malware information to the C2 server;                |
|       | likely associated with the sub key and could be a campaign or affiliate identifier                                                        |
| sub   | Integer value that is only referenced when sending basic host and malware information to the C2 server if configured                      |
|       | to do so via the net key; likely associated with the "pid" config key and could be a campaign or affiliate identifier                     |
| pk    | Base64-encoded value representing the attacker's public key used to encrypt files                                                         |
| prc   | An array of strings representing process names that REvil attempts to terminate prior to encrypting and/or wiping                         |
|       | folders to prevent resource conflicts                                                                                                     |
| wipe  | True/false value that determines if REvil attempts to wipe blacklisted folders specified in the wfid key                                  |
| wfld  | An array of strings representing blacklisted folder name values; if the wipe key is configured, then REvil attempts to                    |
|       | delete (wipe) these folders prior to encrypting                                                                                           |
| wht   | Contains the following subkeys representing whitelisted values that REvil will not encrypt:                                               |
|       | · ext - Whitelisted file extensions                                                                                                       |
|       | fld - Whitelisted folder name values                                                                                                      |
|       | fls - Explicit whitelisted filenames                                                                                                      |

Table 1. REvil configuration keys and definitions.

# DELIVERY

When REvil was first discovered, it was delivered to targets via exploitation of Oracle WebLogic vulnerabilities. Since then, the threat actors have expanded delivery to include malicious spam campaigns, RDP attacks, and other attack vectors. There are reports that the threat actors leveraged a strategic web compromise (SWC) to deliver REvil by compromising the Italian WinRAR installation executable with an instance of the SWC resulted in the infection of unsuspecting WinRAR customers' systems. In other reports, threat actors breached at least three managed service providers (MSPs) and used the access to deploy REvil to the MSPs' customers. The diversity and complexity of delivery mechanisms employed by the REvil threat actors in a high level of sophistication.

# EXECUTION FLOW

Figure 3 highlights the execution flow of REvil's core functionality. Subsequent sections describe each of these tasks.

![](_page_3_Figure_0.jpeg)

## Create mutex and validate runtime privileges

Figure 4 depicts the initial high-level functionality REvil exhibits when executed. The malware dynamically resolves the system library functions that it leverages by comparing the CRC32 hash of function names for a given library to a list of precalculated hashes stored within the REvil binary. REvil then loads functions whose CRC32-hashed hashes. This control evades detection via static analysis.

![](_page_3_Figure_3.jpeg)

Figure 4. REvil decompiled pseudocode depicting initial high-level functionality. (Source: Secureworks)

Once all functions are resolved, REvil verifies that there of itself running on the host by attempting to create a mutex using a hard-coded value as its name (e.g., C19C0A84-FA11-3F9C-C3BC-0BCB16922ABF). Because the value is hard-coded rather than determined by a configuration variable or dynamically generated at runtime based on the host's characteristics, it can be used as an indicator to detect or prevent a REvil infection.

If mutex creation is successful, REvil queries the "exp" key within its configuration and attempts to elevate privileges using an LPE exploit if this key is enabled. REvil executes either 32-bit or 64-bit shellcode depending on the host's architecture. The code appears to exploit OVE-2018-8453 using a method similar to one detailed by researchers.

Regardless of whether exploitation is configured to run, REvil verifies that it is currently running with administrative rights by ensuring its TokenElevationType is set to TokenElevationTypeFull and its integrity level is set to a minimum level of High. If the process is running with Low integrity, REvil terminates the current process and launches of itself via ShellExecute using the "runas" command, which executes the new instance with administrative rights.

REvil performs another privilege-related validation within its main function prior to profiling host information. If REvil's current process is running with system-level integrity, then the security context of the first explorer.exe process it finds running on the compromised system.

# Prepare for encryption

This phase of REvil's execution flow generates and stores encryption and victim metadata elements.

## Generate unique ID (UID)

REvil generates a unique identifier (UD) for the host using process. The UD is part of the payment URL referenced in the dropped ransom note.

- 1. Obtains the volume serial number for the system drive
- 2. Generates a CRC32 hash of the volume serial number using the hard-coded seed value of 0x539
- 3. Generates a CRC32 hash of the value returned by the CPUD assembly instruction using the CRC32 hash for the volume serial number as a seed value
- 4. Appends the volume serial number to the CPUID CRC32 hash

For example, the volume serial number F284306B results in a CRC32 hash value of "Intel(R) Core(TM) i7-4850HQ CPU @ 2.30GHz" results in a CRC32 hash value of F3FD1FCF. REvil appends the volume serial number (F284306B) to the CPUD CRC32 hash (F3FD1FCF) to create the UID string "F3FD1FCFF284306B".

## Generate encryption keys

REvil determines if it has already generated and stored the session encryption keys in the host's registry key/value pairs generated within either the HKEY\_LOCAL\_MACHINE (HKLM) or HKEY\_CURRENT\_USER (HKCU) hives. The malware defaults to using the HKLM registry hive. However, if writing to this hive is unsuccessful (likely due to lack of privileges), it uses HKCU. All REvil samples observed by CTU researchers as of this publication use the hard-coded "Software\rectg" registry subkey. The associated values could indicate a REvil infection.

|        |  | Registry value   Registry value description                                           |  |  |  |  |
|--------|--|---------------------------------------------------------------------------------------|--|--|--|--|
| pk_key |  | Session public key                                                                    |  |  |  |  |
| sk_key |  | Session private key encrypted with the attacker's public key in REvil's configuration |  |  |  |  |
| 0_key  |  | Session private key encrypted with the public key embedded in REvil's binary          |  |  |  |  |

### Table 2. Registry values containing REvil session encryption keys.

REvil generates a session public/private keypair if the registry values do not exist. The 32-byte session public key is stored as pk\_key within the recfg registry without encoding or encryption. The session private key is encrypted using the attacker's public key, which is stored in the pk\_key of REvil's JSON configuration. The resulting 88-byte encrypted value is then stored as sk\_key within the recfg registry subkey.

Finally, the original unencrypted session private key is encrypted using a different public key that is hard-coded within the REvil binary. In the analyzed sample, the ASCII representation of this embedded 32-byte key is

79CD20FCE73EE1B81A433812C156281A04C92255E0D708B9F0B1F1CB9130635. The resulting 88-byte encrypted session private key is stored as 0\_key within the recfg registry subkey.

### Generate random file extension

REvil checks the Software\recfg registry key for the rnd\_ext value. This value contains the random extension generated at runtime that is appended to encrypted files. If this registry value does not exist, the malware generates a random string of lowercase letters (az) and numbers (0-9) ranging from five to ten characters in length (inclusive) and preceded by a period (e.g., 9781xsd4). This string is assigned to the rnd\_ext value within the recfg registry subkey.

### Profile host information

REvil profiles the compromised host by collecting the following information:

- · Current username
- Hostname
- Workgroup/domain name
- · Locale
- · Russian keyboard layout (true/false)
- Operating system product name
- · Fixed drive details

The malware converts the information into a "stat" JSON data structure and adds additional keys associated with the malware. The values assigned to these keys are specific to the campaign and host, but the following data includes example variables:

```
{
"bit": 86,
"bro": false,
"dsk": "QwADAAAAAPDf/xgAAAAA0LxsFQAAAA==",
"grp": "WORKGROUP",
"lng": "en-US",
"net": "VICTIM-HOSTNAME",
"os": "Windows 8.1 Pro",
"pid": "7",
"pk": "nAjfiPcoIyeIwwCkM1hLhXo5HUQMtrAB+7m8eHzerho=",
"sk":
"ww8h065kK3Tm7Thg/Y0nT3tSLReYMJUoaVVIkkDq8/L/5k1IcaoVFKkDtKcrdap6Q1mZZd+B6oAD2McVjLnWuGr/RJWfwH
5cnTppruevrgog==",
"sub": "3",
"uid": "F3FD1FCFF284306B",
"unm": "VICTIM-USERNAME",
"ver": 257
```
}

Table 3 defines the keys used in the stat JSON data structure.

| Description<br>Key |                                                                                                                            |
|--------------------|----------------------------------------------------------------------------------------------------------------------------|
| bit                | CPU architecture of the host (86 refers to x86 or 32-bit CPU)                                                              |
| bro                | True/false value indicating if a Russian keyboard layout was detected                                                      |
| dsk                | Base64-encoded binary value describing the host's fixed drive including the drive letter, drive type, total size, and free |
|                    | space                                                                                                                      |
| grp                | Host's workgroup name                                                                                                      |
| Ing                | Host's locale information                                                                                                  |
| net                | Host's hostname                                                                                                            |
| OS                 | Host's operating system                                                                                                    |
| pid                | Unknown integer value obtained from the ransomware's configuration; likely associated with the sub key and could be        |
|                    | a campaign or affiliate identifier                                                                                         |
| pk                 | Base64-encoded attacker's public key obtained from the ransomware's configuration and used in the file encryption          |
|                    | process                                                                                                                    |
| sk                 | Base64-encoded encrypted session private key generated at runtime and encrypted using the attacker's public key            |
| sub                | Unknown integer value obtained from the ransomware's configuration; likely associated with the pid key and could be        |
|                    | a campaign or affiliate identifier                                                                                         |
| uid                | UID value generated at runtime comprised of the CRC32 hash of both the host's volume serial number and CPUD                |
| unm                | Victim's username                                                                                                          |
| ver                | Unknown hard-coded value that could be the ransomware executable version number                                            |

Table 3. REvil stat JSON data structure keys and definitions.

REvil encrypts the stat JSON data structure with the same algorithm used to encrypt the session private key stored to the registy. However, a different hard-coded public key is dedicated to encrypting this host profile information. In the ASCII representation of these embedded key bytes is "367D49308535C2C368604B4B7ABE8353ABE68E42F9C662A5D06AADC6F17DF61D", The resulting encrypted data is then stored within a registry value named "stat" located in the \Software\recfg\ registry values stored by REvil during this execution phase.

| मी                                                                          |        |                                                              |                                                  | Registry Editor                                                                                                                                                                                                                                                                                                                                                                                                                                |
|-----------------------------------------------------------------------------|--------|--------------------------------------------------------------|--------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| File<br>Edit                                                                | View   | Help<br>Favorites                                            |                                                  |                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| Policies<br>Python                                                          | A      | Name<br>ab (Default) REG SZ                                  | Type                                             | Data<br>(value not set)                                                                                                                                                                                                                                                                                                                                                                                                                        |
| DJo samon<br>rectg<br>Registered A<br>TechSmith<br>ThinPrint<br>VMware, Inc |        | no O key<br>90 pk_key<br>ab rnd_ext<br>fio sk_key<br>no stat | REG_BINARY<br>REG BINARY<br>REG SZ<br>REG BINARY | 77 ae 76 e6 4a ec a5 cb f6 83 c3 28 3f 4b 08 a5 7f 6f e6 65 71 23 0b eb 34 ec 75 fa 01 fb 77 fd 78 7b<br>b5 da a9 bf 3c 5c 8b ca 25 88 0d 70 9b ee 6a 37 ad ef 83 f5 13 85 ca 38 dd 0c ed 02 32 09 70 02<br>9781xsd4<br>c3 0f 21 d3 ae 64 2b 74 e6 ed 38 60 fd 8d 27 4f 7b 52 2d 17 98 30 95 28 69 55 48 92 40 ea f3 ff ff e6<br>REG BINARY d2 b4 16 42 bb a1 de 3f d5 ab 7c de 45 1e bb 90 6f be 23 12 9b 17 a4 c5 7d 07 1a 82 32 80 8f 7f d8 |
| Volatile                                                                    | V<br>> | <                                                            | Computer\HKEY_LOCAL_MACHINE\SOFTWARE\recfg       | ::.                                                                                                                                                                                                                                                                                                                                                                                                                                            |

Figure 5. Registry key and values created by REvil. (Source: Secureworks)

### Configure ransom note

Figure 6 shows the Base64-decoded ransom note template stored in the nbody key of REvil's configuration. As indicated by the red arrows, the variable placeholders {EXT}, {UID}, and {KEY} appear on lines 5, 20, 24, 31, and 36.

| 1<br>2               | ---- Welcome. Again. ======                                                                                                                                                                                     |
|----------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 3                    | [+] Whats Happen? [+]                                                                                                                                                                                           |
| 4<br>ഗ               | Your files are encrypted, and currently unavailable. You can check it: all files on                                                                                                                             |
| ნ                    | you computer has expansion {EXT}.<br>By the way, everything is possible to recover (restore), but you need to follow our<br>instructions. Otherwise, you cant return your data (NEVER).                         |
| 7<br>8<br>g          | [+] What guarantees? [+]                                                                                                                                                                                        |
| 10                   | Its just a business. We absolutely do not care about you and your deals, except<br>getting benefits. If we do not do our work and liabilities - nobody will not<br>cooperate with us. Its not in our interests. |
| II                   | To check the ability of returning files, You should go to our website. There you<br>can decrypt one file for free. That is our guarantee.                                                                       |
| 12                   | If you will not cooperate with our service - for us, its does not matter. But you<br>will lose your time and data, cause just we have the private key. In practise -<br>time is much more valuable than money.  |
| 13<br>14             | [+] How to get access on website? [+]                                                                                                                                                                           |
| 15<br>16<br>17       | You have two ways:                                                                                                                                                                                              |
| 18                   | 1) [Recommended] Using a TOR browser!                                                                                                                                                                           |
| 19<br>20             | a) Download and install TOR browser from this site:  Open our website:                                                                                                             |
| 21                   |                                                                                                                                      |
| 22                   | 2) If TOR blocked in your country, try to use VPN! But you can use our secondary<br>website. For this:                                                                                                          |
| 23<br>24<br>25       | a) Open your any browser (Chrome, Firefox, Opera, IE, Edge)<br>b) Open our secondary website:                                                                                         |
| 26<br>27             | Warning: secondary website can be blocked, thats why first variant much better and<br>more available.                                                                                                           |
| 28<br>29             | When you open our website, put the following data in the input form:<br>Key :                                                                                                                                   |
| 30<br>31<br>32<br>33 | {KEY}                                                                                                                                                                                                           |
| 34<br>35             | Extension name:                                                                                                                                                                                                 |
| 36<br>37             | {EXT}                                                                                                                                                                                                           |
| 38                   |                                                                                                                                                                                                                 |
| 39<br>40             | !!! DANGER !!!                                                                                                                                                                                                  |
| 41                   | DONT try to change files by yourself, DONT use any third party software for<br>restoring your data or antivirus solutions - its may entail damge of the private<br>key and, as result, The Loss all data.       |
| 42                   | 111 111 111                                                                                                                                                                                                     |
| 43<br>44             | ONE MORE TIME: Its in your interests to get your files back. From our side, we (the<br>best specialists) make everything for restoring, but please should not interfere.<br>iii iii iii                         |

Figure 6. REvil's Base64-decoded ransom note template with variable placeholders. (Source: Secureworks)

Figure 7 shows contents of the ransomware note template with the variable placeholders populated with their corresponding values:

- · {EXT}- Replaced with the random extension (e.g., 9781xsd4) that was generated at runtime, stored within the rnd\_ext registry value, and appended to encrypted filenames
- {UID} Replaced with the UID value comprised of the host's volume serial number and CPUID (The inclusion of this UID in the URIs provided to victims post-encryption indicates that the threat actors can use it to identify and track unique victims.)
- {KEY} Replaced with the Base64-encoded representation of the encrypted stat data in Table 3

![](_page_7_Picture_0.jpeg)

Figure 7. REvil's ransom note populated with values calculated at runtime. (Source: Secureworks)

REvil generates the ransom note's filename using a similar the value stored within the "mame" key in its configuration and replaces the {EXT} variable placeholder with its corresponding value. In the analyzed sample, the nname key value "{EXT}-HOW-TO-DECRYPT.txt" led to the ransom note filename 9781xsd4-HOW-TO-DECRYPT.txt.

### Configure background image text

REvil formats the text placed in the upper center of the new background image displayed after encryption occurs. REvil obtains the value stored within its ing key, Base64-decodes it, and replaces the {EXT} variable placeholder with the resulting value. In the analyzed sample, "You are infected! Read {EXT}-HOW-TO-DECRYPT.xt!" became "You are infected! Read 9781xsd4-HOW-TO-DECRYPT.txt!"

### Check for command-line switches

REvil checks for command-line switches passed to the executable when it was launched sample supports a single command-line switch: -nolan. By default, REvil encrypts the contents of local fixed hard drives and network-attached shares. If the -nolan command-line switch is passed when the binary is launched, REvil ignores network-connected resources.

## Validate target is whitelisted

The malware calls User32.dl's GetKeyboardLayoutList function, inspects the keyboard identifier, and returns true if the result ends in a value between \x18 thru \x44 inclusive. This result mest is whitelisted based on the host's configured keyboard layout. The malware inspects only the lower byte of the full keyboard identifier, so all systems using the listed in Table 4 are immune to

REvil. Despite the large number of potential matches, CTU researchers suspect that the malware author intended to identify Russian keyboards based on several other links to the Russia-based GandCrab ransomware.

| Keyboard locale                            | ldentifier | Keyboard locale |            |                                 | Identifier                   |            |
|--------------------------------------------|------------|-----------------|------------|---------------------------------|------------------------------|------------|
| Albanian                                   |            |                 | 0x0000041c |                                 | Persian (Standard)           | 0x00050429 |
| Armenian Eastern                           |            |                 | 0x0000042b |                                 | Romanian (Legacy)            | 0x00000418 |
| Armenian Phonetic                          |            |                 | 0x0002042b |                                 | Romanian (Programmers)       | 0x00020418 |
| Armenian Typewriter                        |            |                 | 0x0003042b |                                 | Romanian (Standard)          | 0x00010418 |
| Armenian Western                           |            |                 | 0x0001042b |                                 | Russian                      | 0x00000419 |
| Azerbaijani (Standard)                     |            |                 | 0x0001042c |                                 | Russian - Mnemonic           | 0x00020419 |
| Azerbaijani Cyrillic                       |            |                 | 0x0000082c |                                 | Russian (Typewriter)         | 0x00010419 |
| Azerbaijani Latin                          |            |                 | 0x0000042c |                                 | Sami Extended Finland-Sweden | 0x0002083b |
| Belarusian                                 |            |                 | 0x00000423 |                                 | Sami Extended Norway         | 0x0001043b |
| Bosnian (Cyrillic)                         |            |                 | 0x0000201a |                                 | Serbian (Cyrillic)           | 0x00000c1a |
| Central Kurdish                            |            |                 | 0x00000429 |                                 | Serbian (Latin)              | 0x0000081a |
| Croatian                                   |            |                 | 0x0000041a |                                 | Setswana                     | 0x00000432 |
| Devanagari-INSCRIPT                        |            |                 | 0x00000439 |                                 | Slovak                       | 0x0000041b |
| Estonian                                   |            |                 | 0x00000425 |                                 | Slovak (QWERTY)              | 0x0001041b |
| Faeroese                                   |            |                 | 0x00000438 |                                 | Slovenian                    | 0x00000424 |
| Finnish with Sami                          |            |                 | 0x0001083b |                                 | Sorbian Extended             | 0x0001042e |
| Georgian                                   |            |                 | Ox00000437 |                                 | Sorbian Standard             | 0x0002042e |
| Georgian (Ergonomic)                       |            | 0x00020437      |            | Sorbian Standard (Legacy)       | 0x0000042e                   |            |
| Georgian (QWERTY)                          |            | 0x00010437      |            | Swedish                         | 0x0000041d                   |            |
| Georgian Ministry of Education and Science |            | 0x00030437      |            | Swedish with Sami               | 0x0000083b                   |            |
| Schools                                    |            |                 |            |                                 |                              |            |
| Georgian (Old Alphabets)                   |            | 0x00040437      |            | Tajik                           | 0x00000428                   |            |
| Hindi Traditional                          |            | 0x00010439      |            | Tatar                           | 0x00010444                   |            |
| Kazakh                                     |            | 0x0000043f      |            | Tatar (Legacy)                  | 0x00000444                   |            |
| Kyrgyz Cyrillic                            |            |                 | 0x00000440 |                                 | Thai Kedmanee                | 0x0000041e |
| Latvian (Standard)                         |            | 0x00020426      |            | Thai Kedmanee (non-ShiftLock)   | 0x0002041e                   |            |
| Latvian (Legacy)                           |            | 0x00010426      |            | Thai Pattachote                 | 0x0001041e                   |            |
| Lithuanian                                 |            | 0x00010427      |            | Thai Pattachote (non-ShiftLock) | 0x0003041e                   |            |
| Lithuanian IBM                             |            | 0x00000427      |            | Turkish F                       | 0x0001041f                   |            |
| Lithuanian Standard                        |            | 0x00020427      |            | Turkish QoETO.exe               | 0x0000041f                   |            |
| Macedonia (FYROM)                          |            | 0x0000042f      |            | Turkmen                         | 0x00000442                   |            |
| Macedonia (FYROM) - Standard               |            | 0x0001042f      |            | Ukrainian                       | 0x00000422                   |            |
| Maltese 47-Key                             |            | 0x0000043a      |            | Ukrainian (Enhanced)            | 0x00020422                   |            |
| Maltese 48-key                             |            | 0x0001043a      |            | Urdu                            | 0x00000420                   |            |
| Norwegian with Sami                        |            | 0x0000043b      |            | Uzbek Cyrillic                  | 0x00000843                   |            |
| Persian                                    |            |                 | 0x00000429 |                                 | Vietnamese                   | 0x0000042a |

Table 4. Keyboard locales immune to REvil.

The malware authors likely leverage REvil's dbg configuration key during development to bypass the value will typically be set to false. If the target host is whitelisted and the dbg value is set to false, REvil terminates its excution. If the dbg configuration key value is set to true or the target host is not whitelisted, REvil executes the next phase of its infection.

## Terminate blacklisted processes

To eliminate potential resource conflicts that could impede or encrypt files, the malware attempts to terminate blacklisted processes. It retrieves the list of blacklisted process names stored within the pro configuration key, iteratity running processes, and compares the lowercase process names to the ist of blacklisted process names .f it identifies a match, REvil attempts to terminate the running process using the kernel32.dll TerminateProcess function. In the analyzed sample, the only blacklisted process listed in the prc configuration key is mysql.exe. This key is a contain one or more attacker-supplied values.

## Delete shadow copies

To ensure that the compromised system is unable to restore from backup, REvil deletes shadow copies and disables recovery mode by executing the following command via ShellExecute. The length and uniqueness of this command allow for the development of high-fidelity detection controls

cmd.exe /c vssadmin.exe Delete Shadows /All /Quiet & bcdedit /set {default} recoveryenabled No & bcdedit /set {default} bootstatuspolicy ignoreallfailures

## If configured, wipe blacklisted folders

REvil wipes the contents of blacklisted folders if the wipe key is set to true. The list of blacklisted folder names from the wfld key, searches local fixed drives and network shares that match the blacklisted names, and then erases the file contents of blacklisted folders and subfolders. The folder is not deleted.

In the analyzed sample, the wfld contiguration key contained a single value of "backup", which wiped the contents of folders with this name. REvil only wipes folders whose name exactly equals a blacklisted value. In this case, it would wipe the contents of folders named "backup" but would skip folders named "backup1" or "database backup".

# Encrypt files

REvil's encryption process starts by iterating through all fixed drives and verifying that they are not whitelisted. The malware compares subkeys located within the wht configuration key to the fid subkey), filename (using the fls subkey), or file extension (using the ext subkey) (see Figure 8).

![](_page_9_Picture_6.jpeg)

Figure 8. REvil configuration excerpt depicting whitelisted folders, filenames, and file extensions that should not be encrypted. (Source: Secureworks)

If a folder is whitelisted, REvil ignores the entire of that folder. If a file is not whitelisted, REvil queues it and performs the following encryption process:

- 1. Reads the file contents into a buffer
- 2. Encrypts the contents of the buffer
- 3. Writes the encrypted contents of the briginal file, overwriting the original file content
- 4. Renames the original file with the previously generated random extension

When encrypting files, REvil uses I/O completion ports (/OCPs) to efficiently manage simultaneous asynchronous activities such as file reading, encrypting, and writing, This implements in extremely fast encryption, as IOCPs and multi-threaded processing let REvil fully leverage all of the host's available processing resources.

The malware appears to encrypt files with the Salsa20 stream cipher. The encryption uses a unique key for each file session public key in the Software) recfglpk\_key registry key/value. The only way to decrypt files encrypted by REvil is to obtain one of the following keys from the threat actor:

- · The unencrypted session private key that was generated, and stored within the sk\_key and 0\_key registry values
- The attacker's private key associated with the REvil configuration (The public key was used to encrypt the session private key.)

Once encrypting all applicable files in a folder, the ransom note in that folder and moves to another folder. After REvil encrypts of all eligible files on local fixed drives, it checks if the binary when launched. If so, REvil does not encrypt mapped network shares. If not, REvil encrypts all non-whitelisted files on mapped network shares.

## Change desktop wallpaper

If the encryption process is successful, REvil changes the desktop background to make the victim aware of the malware generates a bitmap image one pixel at a time using sem-random integer values for pixel color that is unique for each infection. The previously generated message (e.g., You are infected! Read 9781xsd4-HOW-TO-DECRYPT.xt!) is placed at the top center of the image in white text. REvil saves the host's %Temp% directory using a random filename consisting of lowercase letters and numbers between 3 and 13 characters in length appended with the ".bmp" extension (e.g., C:\Users\ <user>\AppData\Local\Temp\cd2sxy.bmp). REvil calls the user32.dll SystemParametersInfoW function to set the image as the desktop background (see Figure 9).

![](_page_10_Picture_1.jpeg)

Figure 9. Example desktop background displayed on a victim's host-encryption. (Source: Secureworks)

## lf configured, contact C2 server

REvil can send the victim's stat information to one or more C2 servers. The net configuration key value to determine if C2 communication should take place. If the value is true, REvil iterates through all of the C2 domains specified within the dmn configuration key and builds a semi-random URL for each C2 server using the following pattern, in which the protocol is hard-coded as "https":

### 

The C2 domain is followed by two URI subpaths. The first is set to a value randomly chosen from the following array of hard-coded values: ("wp-content", "static", "content", "include", "news", "data", "admin"). The second is set to a value randomly chosen from the following array of hard-coded values: ["images", "pictures", "image", "temp", "graphic", "assets", "pics", "game"].

REvil generates a random resource name between 2 and 18 characters in length consisting of only lowercase letters ranging from a z. Characters are generated two at a time, so the resource name length is always an even number. The extension is set to a value randomly chosen from the following array of hard-coded values: "[jpg", "png", "gif"]. Figure 10 depicts several examples of generated C2 URLs.

```





```

```

```
Fiaure 10. Example C2 server URLs generated by REvil. (Source: Secureworks)

REvil sends the encrypted stat data containing the host profile and malware information to the C2 URL via the HTTP POST method. Detection of the associated network traffic is challenging because REvil uses the HTTPS protocol, which encrypts the network communication. The malware reads the subsequent C2 server response but implements no logic to act on the received data. This deficit eliminates the possibility for remote access trojan (RAT) functionality. Finally, REvil terminates execution.

# DECRYPTION WEBSITE

The ransom note instructs the victim to use a unique URL to decrypt their files. The URL leads to an attacker-controlled website that displays the form shown in Figure 11. Victims must provide the key and extension name included in the ransom note is the Base64-encoded representation of the encrypted stat data stored in the registry.

#### 1. Enter the key here:

![](_page_11_Picture_1.jpeg)

2. Enter the extension name and click submit:

Extension name

SUBMIT

Figure 11. REvil ransom payment key and extension form. (Source: Secureworks)

The victim is then informed of the cost in Bitcoin to decrypt their files (see Figure 12).

# Your computer has been infected

![](_page_12_Picture_1.jpeg)

Your documents, photos, databases and other important files encrypted

![](_page_12_Picture_3.jpeg)

![](_page_12_Picture_4.jpeg)

To decrypt your files you need to buy our special software -9781xsd4-Decryptor

You can do it right now. Follow the instructions below. But remember that you do not have much time

# 9781xsd4-Decryptor price

#### You have 3 days, 23:59:32 Current price 0.20319454 втс ~ 2,500 USD \* If you do not pay on time, the price will be doubled After time ends 0.40638908 BTC \* Time ends on Jul 12, 22:12:16 = 5,000 USD Bitcoin address: 3E9F7gE3upQ8rgsPjwiKH7ugfdneypPjqj \* BTC will be recalculated in 5 hours with an actual rate. CHAT SUPPORT INSTRUCTIONS Buy Bitcoins with Bank How to decrypt files? Account or Bank Transfer You will not be able to decrypt the files yourself. If you try, you will lose Coinmama your files forever. Korbit To decrypt your files you need to buy our special software - 9781xsd4-Decryptor. Coinfloor \* If you need guarantees, use trial decryption below. Coinfinity 0 How to buy 9781xsd4-Decryptor? BitPanda 0 1. Create a Bitcoin Wallet (we recommend Blockchain info) BTCDirect 2. Buy necessary amount of Bitcoins. Current price for buying is 0.20319454 BTC Buy Bitcoin with 3. Send 0.20319454 BTC to the following Bitcoin address: Credit/Debit Card 3E9F7gE3upQ8rgsPjwiKH7ugfdneypPjqj o CEXio \* This receiving address was created for you, to identify your transactions CoinMama 0 4. Wait for 3 confirmations o Huobi 5. Reload current page after, and get a link to download-

Figure 12. REvil ransom payment details and instructions. (Source: Secureworks)

The site provides instructions for how to purchase Bitcoin and chat with support. It also offers a trial decryption (see Figure 13) to prove that the victim can decrypt the files.

## Trial decryption

Upload your file for test 9781xsd4-Decryptor.

- \* This file should be an encrypted image. Example
- o your-file-name.jpg.9781xsd4
- o your-file-name.png.9781xsd4

| o your-file-name.gif.9781xsd4 |  |  |  |  |  |  |  |  |
|-------------------------------|--|--|--|--|--|--|--|--|
|                               |  |  |  |  |  |  |  |  |

| * This file should be an encrypted image. |  |
|-------------------------------------------|--|
| Browse                                    |  |
|                                           |  |

Figure 13. REvil ransom trial decryption offer. (Source: Secureworks)

The analyzed sample requested that payment be sent to the Bitcoin address 3E9F7gE3upQ8rgsPjwiKH7ugfdheypPjgj. No payments have been made as of this publication (see Figure 14).

| Summary             |                                          |
|---------------------|------------------------------------------|
| Address             | 3E9F7gE3upQ8rgsPjwiKH7ugfdneypPjqj       |
| Hash 160            | 88975624eb26ac578b1911ae12f65593ff916025 |
| Transactions        |                                          |
| No.<br>Transactions | 0                                        |
| Total<br>Received   | 0 BTC                                    |
| Final<br>Balance    | 0 BTC                                    |

Figure 14. Contents of Bitcoin wallet associated with REvil infection. (Source: Secureworks)

# THE GANDCRAB CONNECTION

Based on several similarities between REvil and GandCrab, CTU researchers assess that the GOLD GARDEN threat groups overlap or are linked.

## Nearly identical string decoding function

The strongest characteristic linking the REvil and GandCrab malware families is the nearly identical functions used for decoding strings at runtime. Figure 15 shows the decompiled pseudocode for the string decoding function in both malware focused on the FOR-loop sections outlined in red.

![](_page_14_Figure_0.jpeg)

Figure 15. Decompiled pseudocode for string decoder function in REvil (right). (Source: Secureworks)

Because these functions have no unique characteristics that obviously confirm code sharing and the REvil and GandCrab FOR-loops are identical, CTU researchers extracted the opcodes (outlined in Figure 16) and searched the VirusTotal dataset for samples containing this opcode pattern. This search yielded 286 unique samples, and all matches were confirmed to be either GandCrab or Evil's decryptor). CTU researchers have not identified other malware families using this opcode pattern, suggesting that the logic is unique to REvil and GandCrab and supporting the theory that these malware families share code.

![](_page_14_Figure_3.jpeg)

Figure 16. Opcodes for FOR-loop within REvil and GandCrab string decoder function. (Source: Secureworks)

# Similar URL building logic

REvil and GandCrab also use the same method to build URLs. There are similarities between the decompiled pseudocode for REvil's BuildURL function (see Figure 17) and GandCrab's BuildURL function (see Figure 18).

![](_page_15_Figure_0.jpeg)

Figure 17. Decompiled pseudocode for REvil's BuildURL function. (Source: Secureworks)

![](_page_15_Figure_2.jpeg)

Figure 18. Decompiled pseudocode for GandCrab's BuildURL function. (Source: Secureworks)

## Circumstantial evidence

Circumstantial evidence also suggests that the same threat actors could be responsible for REvil and GandCrab:

- The REvil file decryptor executable reported]y contains a "D:\gc6\\core\\src\\common\\debug.c" debug path that reflects the folder structure created by the malware author during development. Some researchers view 'gc6'' to be a reference to GandCrab v6, which could indicate that REvil is GandCrab v6.
- REvil was dropped on hosts in conjunction with GandCrab on April 17, 2019. The GandCrab threat actors announced their retirement on May 31. After May 31, REvil activity increased and the delivery methods expanded and became more sophisticated.

· Both REvil and GandCrab whitelisted similar keyboard locales to prevent infection of Russia-based hosts. Malware authors commonly whitelist regions where they reside to prevent scrutiny from local law enforcement, so the REvil and GandCrab malware authors likely reside in the same region.

# CONCLUSION

Given the diverse and advanced delivery mechanisms, code complexity, and resources utilized by REvil, CTU researchers assess that this ransomware will replace GandCrab as a widespread threat. As of this publication, REvil does not contain would enable it to spread laterally during an infection. It would need to be dropped or downloaded via malware with this capability.

The best way to limit the damage from ransomware is to maintain and veify current backups of valuable data. CTU researchers recommend that organizations employ a 3-2-1 backup strategy to ensure successful restoration of data in the event of a ransomware attack.

# THREAT INDICATORS

The threat indicators in Table 5 can be used to detect activity related to REvil ransomware. The table the C2 servers configured within the analyzed sample due to the large number of domains.

| Indicator                                                        | Type | Context |             |                  |                  |
|------------------------------------------------------------------|------|---------|-------------|------------------|------------------|
| 512b538ce2c40112009383ae70331dcf                                 |      |         | MD5 hash    | REvil executable |                  |
| d3a0c325121ab4775ab48bbb7b2ef21c0f123109                         |      |         |             | SHA1 hash        | REvil executable |
| 25ac4873ae4f955032f8f0e8ed4ec78df2e2ce814454b7b5abd9489feb4e30c3 |      |         | SHA256 hash | REvil executable |                  |
| 112983B0-B4C9-4F9B-96C4-E5394FB8A5B4                             |      |         | Mutex       | Created by REvil |                  |
| 1DB960B8-E5C3-F077-5D68-EEE2E637EE0B                             |      |         | Mutex       | Created by REvil |                  |
| 206D87E0-0E60-DF25-DD8F-8E4E7D1E3BF0                             |      |         | Mutex       | Created by REvil |                  |
| 3555A3D6-37B3-0919-F7BE-F3AAB5B6644A                             |      |         | Mutex       | Created by REvil |                  |
| 552FFA80-3393-423d-8671-7BA046BB5906                             |      |         |             | Mutex            | Created by REvil |
| 6CAC559B-02B4-D929-3675-2706BBB8CF66                             |      |         |             | Mutex            | Created by REvil |
| 859B4E91-BAF1-3DBB-E616-E9E99E851136                             |      |         | Mutex       | Created by REvil |                  |
| 879EBE58-4C9F-A6BE-96A3-4C51826CEC2F                             |      |         | Mutex       | Created by REvil |                  |
| 95B97D2B-4513-2041-E8A5-AC7446F12075                             |      |         | Mutex       | Created by REvil |                  |
| BF29B630-7648-AADF-EC8A-94647D2349D6                             |      |         | Mutex       | Created by REvil |                  |
| C126B3B3-6B51-F91C-6FDF-DD2C70FA45E6                             |      |         | Mutex       | Created by REvil |                  |
| C19C0A84-FA11-3F9C-C3BC-0BCB16922ABF                             |      |         | Mutex       | Created by REvil |                  |
| C817795D-7756-05BF-A69E-6ED0CE91EAC4                             |      |         | Mutex       | Created by REvil |                  |
| D382D713-AA87-457D-DDD3-C3DDD8DFBC96                             |      |         | Mutex       | Created by REvil |                  |
| DAE678E1-967E-6A19-D564-F7FCA6E7AEBC                             |      |         | Mutex       | Created by REvil |                  |
| FB864EC7-B361-EA6D-545C-E1A167CCBE95                             |      |         | Mutex       | Created by REvil |                  |
| FDC9FA6E-8257-3E98-2600-E72145612F09                             |      |         | Mutex       | Created by REvil |                  |

Table 5. Indicators for this threat.

TAGS: Threat Analysis Research

## ABOUT THE AUTHOR

### COUNTER THREAT UNIT RESEARCH TFAM

Secureworks Counter Threat Unit™ (CTU) researchers for the media, publish technical analyses for the security community, and speak about emerging threats at security conferences. Leveraging Security technologies and a network of industy contacts, the CTU™ research team tracks threat actors and analyzes and theats. This process nat threats. This process enables CTV researchers to identify threats as they emerge and develop countermeasures that protect customers before damage can occur.

→

# NOW TRENDING...

- → 2024 Global State of the Threat Report
- → Modernize Your Security Operation Center with XDR
- → MDR Done Right

![](_page_17_Picture_4.jpeg)

REPORT

## THREAT INTELLIGENCE EXECUTIVE REPORT VOLUME 2025 NUMBER 1

READ MORE

## ADDITIONAL RESOURCES

![](_page_18_Picture_0.jpeg)

BLOG

# THREE CYBERSECURITY PLATFORM PREDICTIONS FOR 2024

READ NOW

Get the latest updates and news from Secureworks.

SUBSCRIBE NOW

### PLATFORM

Detection & Response XDR Log Management MITRE ATT&CK Coverage

Network Security ndr

Endpoint Security edr

#### NGAV Identity Security idr

OT Security Operational Technology

#### Vulnerability Management

Vulnerability Risk Prioritization

### WHY SECUREWORKS

Why Secureworks Customer Trust Compare Secureworks At Your Side ROI Calculator Artificial Intelligence Corporate Responsibility Corporate Overview Counter Threat Unit

### SERVICES

Managed Detection & Response MDR Overview Threat Hunting

MDR for OT MDR for Microsoft

#### Consulting

Consulting Services Overview Risk Assessment Security Preparedness Resiliency Testing

#### Professional Services

Professional Services Overview Taegis Onboarding Steady State Services

Incident Response About Emergency Incident Response Emergency Breach Hotline

### SOLUTIONS

#### Industries

Education Industry Financial Industry Manufacturing Industry

#### Need

Accelerate Security Maturity Consolidate Security Tools Microsoft Security