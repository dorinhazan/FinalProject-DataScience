# Connection timed out (Error code 522

#### Visit cloudflare.com for more information.

2025-04-17 14:14:58 UTC

![](_page_0_Picture_3.jpeg)

### What happened?

The initial connection between Cloudflare's network and the origin web server timed out. As a result, the web page can not be displayed.

## What can I do?

lf you're a visitor of this website:

Please try again in a few minutes.

### If you're the owner of this website:

Contact your hosting provider letting them know your web server is not completing requests. An Error 522 means that the request was able to connect to your web server, but that the request didn't finish. The most likely cause is that something on your server is hogging resources. Additional troubleshooting information here.

Cloudflare Ray ID: 931c8735cc39e224 · Your IP: Click to reveal · Performance & security by Cloudflare