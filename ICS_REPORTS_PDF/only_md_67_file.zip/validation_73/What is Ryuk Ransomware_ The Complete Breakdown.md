## Big Game Hunting with Ryuk: Another Lucrative Targeted Ransomware

January 10, 2019

![](_page_0_Picture_5.jpeg)

WIZARD SPIDER is a sophisticated eCrime group that has been operating the Ryuk ransomware since August 2018, targeting large organizations for a high-ransom return. This methodology, known as "big game hunting," signals a shift in operations for WIZARD SPIDER. This actor is a Russia-based criminal group known for the operation of the TrickBot banking malware that had focused primarily on wire fraud in the past.

The actor name GRIM SPIDER was introduced into CrowdStrike's nomenclature in September 2018 for the group that operates the Ryuk ransomware as a distinct sub-group of the WIZARD SPIDER criminal enterprise. However, in June 2019, further evidence emerged that allowed CrowdStrike to assess with high confidence that Ryuk is in fact operated as part of the core WIZARD SPIDER actor group. CrowdStrike Intelligence will now solely use the actor name WIZARD SPIDER in association with TrickBot and Ryuk. The GRIM SPIDER actor name has been deprecated. Similar to Samas and BitPaymer, Ryuk is specifically used to target enterprise environments. Code comparison between versions of Ryuk and Hermes ransomware indicates that Ryuk was derived from the Hermes source code and has been under steady development since its release. Hermes is commodity ransomware that has been observed for sale on forums and used by multiple threat actors.

However, Ryuk is only used by WIZARD SPIDER and, unlike Hermes, Ryuk has only been used to target enterprise

|  |  | A TI I I P |  |  |
|--|--|------------|--|--|
|  |  |            |  |  |

Recent

Video

Category

![](_page_1_Picture_1.jpeg)

![](_page_1_Picture_2.jpeg)

Download the 2021 Global Threat Report

## 1. Ryuk Ransom Notes

The Ryuk ransom note is written to a file named RyukReadMe . txt. A number of different ransom note templates have been observed. The body of the template is static with the exception of the email address and the Bitcoin (BTC) wallet address, which may change. The email addresses usually contain one address at protonmail.com and another address at tutanota.com. The email names typically are esoteric actors and directors, but Instagram models have also been observed. Interestingly, the ransom note in Figure 3 is remarkably similar to the BitPaymer ransom notes. As of this writing, it remains unclear if WIZARD SPIDER is copying the TTPs (tactics, techniques and procedures) and ransom notes of BitPaymer, or whether the groups may share information with each other.

Your network has been penetrated.

All files on each host in the network have been encrypted with a strong algorithm.

Backups were either encrypted or deleted or backup disks were formatted. Shadow copies also removed, so F8 or any other methods may damage encrypted data but not recover.

We exclusively have decryption software for your situation No decryption software is available in the public.

DO NOT RESET OR SHUTDOWN - files may be damaged. DO NOT RENAME OR MOVE the encrypted and readme files. DO NOT DELETE readme files. This may lead to the impossibility of recovery of the certain files.

To get info (decrypt your files) contact us at KurtSchweickardt@protonmail.com KurtSchweickardt@tutanota.com

BTC wallet: 14hVKm7Ft2rxDBFTNkkRC3kGstMGp2A4hk

Ryuk

No system is safe

Figure 3. Ryuk Ransom Note Bearing Strong Resemblance to

Featured

Recent

Video

Category

Start Free Trial

included their BTC address and email addresses. However, recent variants of Ryuk no longer contain the BTC address - only the email addresses. The ransom note states that the victim will

Your network has been penetrated.

All files on each host in the network have been encrypted with a strong algorithm.

Backups were either encrypted Shadow copies also removed, so F8 or any other methods may damage encrypted data but not recover. We exclusively have decryption software for your situation. More than a year ago, world experts recognized the impossibility of deciphering by any means except the original decoder. No decryption software is available in the public. Antiviruse companies, researchers, IT specialists, and no other persons cant help you encrypt the data. DO NOT RESET OR SHUTDOWN - files may be damaged. DO NOT DELETE readme files. To confirm our honest intentions. Send 2 different random files and you will get it decrypted. It can be from different computers on your network to be sure that one key decrypts everything. 2 files we unlock for free To get info (decrypt your files) contact us at CliffordGolden93@protonmail.com or

CliffordGolden93@tutanota.com

You will receive btc address for payment in the reply letter

Ryuk

No system is safe

Figure 4. Ryuk Ransom With BTC Address Removed Early Ryuk binaries with the removal of the BTC address contained a PDB path ofC:\Users\Admin\Documents\Visual Studio 2015\Projects\ConsoleApplication54new crypted try to clean\x64\Release\ConsoleApplication54.pdb. This PDB path started appearing on Nov. 29, 2018. The removal of the BTC addresses occurred a day after the U.S. Department of Justice

unsealed indictments for two individuals involved in facilitating cashouts from Samas Bitcoin addresses.

#### Ransom Payments

Based on observed transactions to known Ryuk BTC addresses, the ransom demand varies significantly. This suggests that WIZARD SPIDER (like INDRIK SPIDER with BitPaymer) calculates the ransom amount based on the size and value of the victim organization. To date, the lowest observed ransom was for 1.7 BTC and the highest was for 99 BTC. With 52 known transactions spread across 37 BTC addresses (as of this writing), WIZARD SPIDER has made 705.80 BTC, which has a current value of \$3.7 million (USD). With the recent decline in BTC to USD value, it is likely GRIM SPIDER has netted more. The tables in the Appendix

include a set of known Ryuk BTC addresses extracted from Ryuk

binaries, which are believed to be only a subset of the Ryuk BTC

| Featured         |
|------------------|
| Recent           |
| Video            |
| Category         |
| Start Free Trial |
|                  |

Falcon® Intelligence™® believes that the initial compromise is performed through TrickBot, which is typically distributed either via spam email or, through the use of the Emotet (developed and

an avid supporter of WIZARD SPIDER, predominantly distributing TrickBot to Emotet victims in the U.K., the U.S., and Canada. Some of TrickBot's modules (such as pwg rab) could aid in recovering the credentials needed to compromise environments — the SOCKS module in particular has been observed tunneling PowerShell Empire traffic to perform reconnaissance and lateral movement. Through CrowdStrike IR engagements, WIZARD SPIDER has been observed performing the following events on the victim's network, with the end goal of pushing out the Ryuk binary:

- An obfuscated PowerShell script is executed and connects to a remote IP address.
- · A reverse shell is downloaded and executed on the compromised host.
- PowerShell anti-logging scripts are executed on the host.
- Reconnaissance of the network is conducted using standard Windows command line tools along with external uploaded tools.
- · Lateral movement throughout the network is enabled using Remote Desktop Protocol (RDP).
- · Service User Accounts are created.
- · PowerShell Empire is downloaded and installed as a service.
- · Lateral movement is continued until privileges are recovered to obtain access to a domain controller.
- PSEXEC is used to push out the Ryuk binary to individual hosts.
- · Batch scripts are executed to terminate processes/services and remove backups, followed by the Ryuk binary.

## 3. From Hermes to Ryuk: Similarities & Differences

Hermes ransomware, the predecessor to Ryuk, was first distributed in February 2017. Only one month after its release, a decryptor was written for Hermes, followed by the release of version 2.0 in April 2017, which fixed vulnerabilities in its cryptographic implementation. Since this release, the only way for a victim to recover files is with the private encryption key, which is obtained by paying the ransom. In late August 2017, Hermes

version 2.1 was released. Hermes was originally sold on forums for

\$300 USD. When purchased, the buyer received a build that

supported two email addresses, a decryptor and a unique RSA key

| Acres of the property | STILING |  |
|-----------------------|---------|--|
|                       | LU      |  |
|                       |         |  |

Recent

Video

Category

Start Free Trial

Financial Telecommunication (SWIFT) compromise at the Far Eastern International Bank (FEIB) in Taiwan. Hermes' role in the SWIFT attack is described in more detail in the Attribution section

kit. In mid-August 2018, a modified version of Hermes, dubbed Ryuk, started appearing in a public malware repository. Ryuk was tailored to target enterprise environments and some of the modifications include removing anti-analysis checks. These checks include querying the Process Environment Block (PEB) to see if the field is BeingDebugged, or querying the PEB to see if the field NtG Loba LF Lag has been set; checking to see if the host is running VirtualBox by calling the instruction CPUID; and ensuring that the host language is not Russian, Ukrainian, or Belarusian. From a process and file perspective, Hermes and Ryuk target files in a similar fashion. The core differences are Ryuk's logic that handles file access, and the use of a second, embedded public RSA key. The following are characteristics that have not changed:

- · Encrypts files using RSA-2048 and AES-256
- Stores keys in the executable using the proprietary Microsoft SIMPLEBLOB format
- Encrypts mounted devices and remote hosts
- o Uses a file marker of HERMES to mark or check if a file has been encrypted

Another notable difference between Hermes and Ryuk is how the encryption keys are created. Hermes starts the encryption initialization by first generating an RSA public and private key pair — referred to as a "victim key." An AES-256 key is generated and the victim's RSA private key is encrypted in AES-CBC mode. The attacker-controlled public RSA key is used to encrypt the AES key (previously used to encrypt the victim's RSA private key). Then, for each file encrypted, an AES key is generated, which is used to encrypt the file. Finally, the AES key for each file is encrypted with the victim's RSA public key, then stored at the end of the file. Ryuk contains the same logic, but no longer generates the victimspecific RSA key pair. Instead, Ryuk has two public RSA keys embedded in the executable, and what was previously the victim's RSA private key is encrypted and embedded in the executable. Because Ryuk does not generate a victim-specific RSA key pair, all hosts can be decrypted with the same decryption key. This might appear to be a design flaw but is not, since Ryuk has a unique key for each executable. If a single executable is used for a single victim environment, then there are no repercussions if the private keys are leaked because it will only decrypt the damage from a single Ryuk executable. Thus, it is highly likely that Ryuk pregenerates the RSA key pairs for each victim. This is arguably more

Featured

Recent

Video

Category

commonly observed) and the Ryuk executable payload. Recovery of Ryuk droppers are rare, due to the Ryuk executable payload deleting the dropper when executed. Upon execution, the dropper constructs an installation folder path. The folder path is created by calling GetWindowsDirectoryWand then inserting a null byte at the fourth character of the path. This is used to create a string that contains the drive letter path. If the host operating system is Windows XP or earlier, the string Documents and Settings\Default User\is appended to the drive letter path. lf the host is Windows Vista or newer, the string users\Public\ is appended to the drive letter path. For Windows XP, an example folder path would be C : \Documents and Settings\Default User\,and for Window Vista or higher, the path would be C : \Users\Public . A random executable file name is then constructed. It is created by calling \_\_s rand with a seed value returned from calling Get FickCount, then\_rand is continuously called until five alphabetic characters are concatenated together. The extension . exe is then appended. The dropper checks whether the host is 32-bit or 64-bit by calling I sWow64P rocess and writes one of two embedded payload executables corresponding to the host's architecture. The newly written executable is then run by calling She L LExecuteW. The Ryuk payload executable written by the dropper is the Ryuk component that contains the core logic for encrypting files on the host. Ryuk is under constant development. In recent months, Ryuk binaries have continued to deviate further and further from the original Hermes source code, with the threat actors adding and removing functionality often. In November 2018, Falcon Intelligence identified new functionality added to Ryuk that included an anti-analysis infinite loop, a ping-like request to an IP address once the encryption process was completed, and the addition of an appended file extension for encrypted files. Of these three new features, only the file extension is still present in an executable compiled on Dec. 20, 2018.

#### File Encryption

Compared to other families of ransomware, Ryuk has very few safeguards to ensure stability of the host by not encrypting system

files. For example, many ransomware families contain extensive lists of file extensions or folder names that should not be മ്പരവേനിമർ (whitalistad) hut Runk റമിം ഡhitalists threa മുന്മനട്ടിരുന്നു.

Featured

Recent

Video

Category

Start Free Trial

111 and 1117 mms, pur 11000 nave noch romuveu in roven vuilus.

The following folder names are also whitelisted and not encrypted.

。 Chrome

- 。 Windows
- o Microsoft
- o AhnLab

This is only a small subset of folder names that should be whitelisted in order to ensure stability on the host. While doing dynamic analysis, it was not uncommon to observe Ryuk attempting to encrypt files related to the Windows Bootloader (C : \Boot) or other critical files and folders. Due to the absence of proper whitelisting, an infected machine can become unstable over time and unbootable if restarted. As mentioned in the Hermes to Ryuk section, Ryuk uses a combination of symmetric (AES) and asymmetric (RSA) encryption to encrypt files. Without the private key provided by WIZARD SPIDER, the files cannot be decrypted and are unrecoverable. A thread is created for the encryption of each file and each file is encrypted with its own AES key. After the file has been encrypted, a file extension of . RYK is appended to the file. All directories will have a ransom note of (RyukReadMe. txt) written to the directory. Ryuk attempts to encrypt all mounted drives and hosts that have Address Resolution Protocol (ARP) entries (IP addresses) and it enumerates all mounted drives by calling GetLogicalDrives. For each mounted drive, Ryuk calls GetDriveTypeW to determine the drive's type. If the drive type is not a CD-ROM, files on the drive are encrypted. To retrieve IP addresses that have ARP entries, Ryuk calls Get LpNet Lab Le. It iterates through all entries and then tries to enumerate files and folders on the remote host and encrypt the files.

#### Persistence

Current builds of Ryuk no longer contain persistence functionality. Previously, to remain persistent on the host, Ryuk created a registry entry under the Run key using Windows cmd . exe shell. The following command line was used to write to the Registry Run Key name svchos to

HKEY\_CURRENT\_USER\SOFTWARE\Microsoft\Windows\Cu rrentVersion\Run with the value being the path to the Ryuk executable.

#### Process Injection

Featured Recent Video

Category

Start Free Trial

เนทที่เกิด มายขององจ. แ น proveoo เงานนาน เทณเ เจ ทบเ และทับน csrss.exe, explorer.exe, lsaas.exe, orisrunning under NT AUTHORITY system account, Ryuk will inject itself into this single process. By ensuring that the process is not running

WriteProcessMemory and CreateRemoteThread to inject itself into the remote process.

### Process/Service Termination and Anti-Recovery Commands

Unlike other families of ransomware, Ryuk does not contain process/service termination and anti-recovery functionality embedded in the executable. In the past, Ryuk did contain these capabilities, but they have been removed and are contained within two batch files. The batch file kill. bat contains commands for stopping services, disabling services and killing processes. The processes and services are stopped to ensure no open handles exist for files that will be encrypted. The following figure is a subset ofeach.command.net stop avpsus /y net stop McAfeeDLPAgentService /y net stop mfewc /y net stop BMR Boot Service /y net stop NetBackup BMR MTFTP Service /y … sc config SQLTELEMETRY start= disabled sc config SQLTELEMETRY\$ECWDB2 start= disabled sc config SQLWriter start= disabled sc config SstpSvc start= disabled … taskkill /IM mspub.exe /F taskkill /IM mydesktopqos.exe /F taskkill /IM mydesktopservice.exe /FFigure1.Process/Services Termination kill.bat Commands CrowdStrike has observed another batch file, named windows . bat, which makes file recovery more difficult on the victim's machine. It should be noted that file names can be arbitrarily changed by the threat actors. The contents of the batch file are shown below in Figure 2. vs s admin Delete Shadows /all /quiet vssadmin resize shadowstorage /tor=c: /on=c: /maxsize=401MB vssadmin resize shadowstorage /for=c: /on=c: /maxsize=unbounded vssadmin resize shadowstorage /tor=d: /on=d: /maxsize=401MB vssadmin resize shadowstorage /for=d: /on=d: /maxsize=unbounded vssadmin resize shadowstorage /for=e: /on=e: /maxsize=401MB vssadmin resize shadowstorage /for=e: /on=e: /maxsize=unbounded vssadmin resize shadowstorage /for=f: /on=f: /maxsize=401MB vssadmin resize shadowstorage /for=f: /on=f: /maxcize=unhounded vccadmin recite

Featured

Recent

Video

Category

Start Free Trial

/ yuici ucu / J / 1 / Y / y / u / ^ i viii viii val / v / ^ i var c:\\*.wbcat c:\\*.bkf c:\Backup\*.\* c:\backup\*.\* c:\\*.set c:\\*.win c:\\*.dsk del /s /f /q d:\\*.VHD d:\\*.bac d:\\*.bak d:\\*.wbcat d:\\*.bkf

e:\\*.bak e:\\*.wbcat e:\\*.bkf e:\Backup\*.\* e:\backup\*.\* e:\\*.set e:\\*.win e:\\*.dsk del /s /f /q f:\\*.VHD f:\\*.bac f:\\*.bak f:\\*.wbcat f:\\*.bkf f:\Backup\*.\* f:\backup\*.\* f:\\*.set t:\\*.win f:\\*.dsk del /s /f /q g:\\*.VHD g:\\*.bac g:\\*.bak g:\\*.wbcat g:\\*.bkf g:\Backup\*.\* g:\backup\*.\* g:\\*.set g:\\*.win g:\\*.dsk del /s /f /q h:\\*.VHD h:\\*.bac h:\\*.bak h:\\*.wbcat h:\\*.bkf h:\Backup\*.\* h:\backup\*.\* h:\\*.set h:\\*.win h:\\*.dsk del %0 Figure 2. Anti-Recovery window . bat Commands These antiforensic recovery commands are quite interesting and appear to make use of an undocumented feature of the v s s admin resize command. While the first command in Figure 2 above, vs s admin Delete Shadows /all /quiet,iscommonly used by ransomware, the command option vssadmin resize shadowstorage is rarely used. In situations where shadow copies were not created by vs sadmin, but by third-party applications (such as backup software), vs sadmin can display an error and not delete the backups. One such error states: "Snapshots were found, but they were outside of your allowed context. Try removing them with the backup application which created them." Thevssadmin resize shadows torage command is a "hack" that relies on v s s admin to delete storage when the shadow copies are resized. It forces the shadow copies to be deleted regardless of their context. The command works by resizing the default shadow volume size from 10 percent to 401 MB (the minimum size is 300 MB). Then the shadow storage is set to unbounded, which allows it to use all available disk space. The shadow copies are then deleted by calling the command vssadmin Delete Shadows /all /quiet asecondtime. The final set of commands deletes files based on their extension or folder locations. The command arguments are for de l delete files in all sub-directories (/s) in quiet mode (/q) without asking the user for confirmation and to force (/f) the deletion of a file. The file extensions are for Virtual Hard Disk (↓VHD), Avantrix Backup Plus files (. bac), backup copy (. bak), Windows Backup Catalog File ( . wbcat), Windows Backup Utility File ( . bf k), setting files (. set), Windows Backup File (. win), Disk Images (. ds k) and all folders that start with Backup. Note that since the del command

does not securely delete a file (i.e., overwrite a file before deletion),

some level of file recovery may be possible using forensic tools.

|  |  | 17117 | 100 |  |
|--|--|-------|-----|--|
|  |  |       |     |  |

Recent

Video

Category

#### North Korea

Open-source reporting has claimed that the Hermes ransomware was developed by the North Korean group STARDUST CHOLLIMA (activities of which have been public reported as part of the "Lazarus Group"), because Hermes was executed on a host during the SWIFT compromise of FEIB in October 2017. Table 1 contains samples that are possibly attributed to the compromise. The two executables related to Hermes are bits ran . exe and RSW7B37.tmp.

| Name                | Functionality       | Compile<br>Time                                                                                                                               | Compile<br>Version                                                                                       |
|---------------------|---------------------|-----------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------|
| msmpeng.exe         | TwoPence<br>implant | Visual<br>C++ 10.0<br>2010 SP1<br>Mon Feb<br>(build<br>20<br>40219) &<br>11:09:30<br>Visual<br>2017<br>C++ 9.0<br>2008 SP<br>(build<br>30729) |                                                                                                          |
| splwow32.exe        | TwoPence<br>implant | Mon Feb<br>20<br>11:09:30<br>2017                                                                                                             | Visual<br>C++ 10.0<br>2010 SP1<br>(build<br>40219) &<br>Visual<br>C++ 9.0<br>2008 SP<br>(build<br>30729) |
| FileTokenBroker.dll | Loader              | Thu Jan<br>05<br>01:11:33<br>2017                                                                                                             | Visual<br>C++ 10.0<br>2010 SP1<br>(build<br>40219) &<br>Visual<br>C++ 9.0                                |

#### Featured

Recent

Video

Category

| bitsran.exe | Dropper/spreader     | Sun Oct<br>1<br>09:37:31<br>2017 | 2010 SP1<br>(build<br>40219) &<br>Visual<br>C++ 9.0<br>2008 SP<br>(build<br>30729) |
|-------------|----------------------|----------------------------------|------------------------------------------------------------------------------------|
| RSW7B37.tmp | Hermes<br>ransomware | Sun Oct<br>1<br>05:34:07<br>2017 | Visual<br>C++ 9.0<br>2008 SP<br>(build<br>30729)                                   |

Table 1. File Information for Binaries Used in the FEIB SWIFT Compromise The first executable, bits ran . exe, is a dropper, and RSW7B37 . tmp is the Hermes ransomware executable. The dropper's goal is to propagate the Hermes executable within a network by creating scheduled tasks over SMB sessions using hard-coded credentials. The Hermes executable then encrypts files on the host. It is interesting to note that the compiler and linker for Hermes is different from the other executables. All of the executables except for Hermes were compiled with Visual Studio 10, with a linker of Visual Studio 10. Hermes, in contrast, was compiled with Visual Studio 9, with an unknown linker. If the time stamps are correct, the two executables (bits ran . exe and RSW7B37 . tmp) were compiled within four hours and three minutes of each other. Due to the short time frame of Hermes being bundled within an executable that was hard-coded with credentials of the FEIB network, Falcon Intelligence assesses that STARDUST CHOLLIMA likely had access to the Hermes source code, or a third party compiled and built a new version for them. Unlike other variants of Hermes, RSW7B37 . tmp does not append the exported and encrypted AES key to the end of the file. Figure 5 is a file encrypted by Hermes with the exported AES key appended to the end of the file as a footer.

Offset(h) 00 01 02 03 04 05 06 07 08 09 0A 0B 0C 0D 0E 0F

000003B0 48 45 52 4D 45 53 01 02 00 00 10 66 00 00 00 A4 HERMES.....f....\* 000003C0 00 00 E3 DA D1 41 AB 5F 23 D8 BD CB OC EB 1E OD ... aúÑA« #ؽÈ... 000003D0 CE E0 5E 66 A4 B5 73 06 CE 94 3C 64 B0 FF 3E E2 Îà^f¤µs.î\*<d'j>â 000003E0 21 1E 47 46 15 98 56 04 2C BO 16 AA E5 0D 8B FA ! .GF.V., 000003F0 B0 37 B1 DC A5 23 CE 65 B7 FD 1C 23 AD 5F D5 D4 °7±Ü¥#îe ý.#.\_ÕÔ 00000400 BD BE F9 5D 20 18 33 35 57 5C F3 BF 96 30 B4 45 ½¿ù] .35W\ó¿-0´E 00000410 3B FD EE OA 14 C9 CE 71 7F 84 9C 22 BD BC 8A 83 ; ýî. .Éîq. , xe"½as f 00000420 D0 86 D8 5E 69 4F E2 D5 19 91 28 FE 17 21 2F 3C ІØ^iOâÔ. '(þ.!/<

#### Featured

Recent

Video

Category

Start Free Trial

6 is the end of a file encrypted by the Hermes variant RSW7B37 . tmp used in the SWIFT attack. The footer only contains the marker HERMES but not the exported AES key.

00002CD0 B7 5A 6A 52 CD 20 69 68 OF F0 56 98 00 AC 21 6A ·ZjRÍ ih.ðV ·- !j 00002CE0 48 45 52 4D 45 53 HERMES

Figure 6. Example Hermes Footer in FEIB SWIFT Attack with Encrypted AES Key Missing Without the encrypted AES key appended to the encrypted files, even if the private key used for encryption was recovered, the files could not be decrypted. l herefore, the Hermes executable used in the FEIB SWIF I attack appears never to have been used to ransom the machine, but rather to destroy the victim's data.

#### Criminal Actors Operating from Russia

Falcon Intelligence has medium-high confidence that the WIZARD SPIDER threat actors are operating out of Russia. Hermes was originally advertised on exploit<.>1n. This Russian-speaking forum is a well-known marketplace for selling malware and related services to criminal threat actors. If Hermes was indeed related to STARDUST CHOLLIMA, it would imply that nation-state threat actors are selling their services on Russian-speaking forums, which is unlikely. The Russian threat actor attribution theory is also supported by an early advertisement for Hermes, which stated that their "software did not work and will on work on RU, UA, BY" . This refers to functionality implemented in Hermes to check the host to ensure that it is not running on a Russian, Ukrainian, or Belarusian system. To check the host language, it queries the registry key HKEY\_LOCAL\_MACHINE\SYSTEM\CurrentControlSet\Con t rol\Nls\Language\ and the value InstallLanguage. If the machine has the value 0419 (Russian), 0422 (Ukrainian) or 0423 (Belarusian), it call ExitProcess to stop executing. This functionality is commonly included by malware developers and sellers who are operating in Russia to reduce their risk of attracting local law enforcement's attention and criminal prosecution. While supporting an incident response investigation involving Ryuk, Falcon Intelligence noticed files related to the investigation being uploaded to a file-scanning website from an IP address in Moscow, Russia. The file in question was a variant of ki l l . bat that contained commands previously only observed executed by Ryuk calling She l lExecute. The files could have been uploaded by a victim in Russia, but the time frame between the functionality being removed from Ryuk binaries and included in kill. bat was very

short. The most likely scenario is that threat actors were testing whether kill. bat would be detected by antivirus engines. Also,

| 0 |  | 17 11 11 11 | 11 100 |  |
|---|--|-------------|--------|--|
|   |  |             |        |  |
|   |  |             |        |  |

Recent

Video

Category

Start Free Trial

ุลเรื่องจากการทรวจริงทราง ลิทนี้ แบบ เพื่อเป็นเมื่องเป็นที่ 1 เพื่อสาน

The Falcon platform has the ability to detect and prevent Ryuk by taking advantage of the behavioral patterns indicated by the ransomware. By turning on suspicious process blocking, Falcon ensures that Ryuk is killed in the very early stages of execution. In addition, CrowdStrike's machine learning (ML) algorithm provides additional coverage against this malware family, as illustrated below.

![](_page_12_Picture_3.jpeg)

## Appendix

## Known Ryuk BTC Wallet Addresses and Payments

| BTC Address                        | Total<br>Received | No<br>Re |
|------------------------------------|-------------------|----------|
| 12vsQry1XrPjPCaH8gWzDJeYT7dhTmpcjL | 55.00             | 3        |
| 1Kx91176PHwk8sw7Ur6PsMWyEtaogX7wWY | 182.99            | 10       |
| 1FtQnqvjxEK5GJD9PthHM4MtdmkAeTeoRt | 48.250            | 4        |
| 14aJo5L9PTZhv8XX6qRPncbTXecb8Qohqb | 25.00             | 2        |
| 1E4fQqzCvS8wgqy5T7n1DW8JMNMaUbeFAS | 0.001             | 1        |
| 1GXgngwDMSJZ1Vahmf6iexKVePPXsxGS6H | 30.00             | 3        |
| 1Cyh35KqhhDewmXy63yp9ZMqBnAWe4oJRr | 0.00              | O        |
| 15LsUgtnuGc1PsHJPcfLQJEnHm2FnGAgYC | 0.00              | O        |
|                                    |                   |          |

| 1CbP3cgi1Bcjuz6g2Fwvk4tVhqohqAVpDQ | 13.00 |  |
|------------------------------------|-------|--|
| 1Jα3WwsaPA7I XwRNYsfvSsd8aoidmkFnW | 35 00 |  |

.

#### Featured

Recent

Video

Category

| 10 11 4 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 1 | ८५.૫١ |  |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------|--|
| 13rTF3AYsf8xEdafUMT5W1E5Ab2aqPhkPi                                                                                                                                            | 0.00  |  |

## <<rowdstrike | BLOG

| itupinonomiaoutunday tund turi i vymutini v | U.UU    |     |
|---------------------------------------------|---------|-----|
| 17v2cu8RDXhAxufQ1YKiauBq6GGAZzfnFw          | 0.00    | O   |
| 1KUbXkjDZL6HC3Er34HwJiQUAE9H81Wcsr          | 10.00   | 1   |
| 12UbZzhJrdDvdyv9NdCox1Zj1FAQ5onwx3          | 0.00    | O   |
| 1NMgARKzfaDExDSEsNijeT3QWbvTF7FXxS          | 0.00    | O   |
| 19AE1YN6Jo8ognKdJQ3xeQQL1mSZyX16op          | 25.00   | 1   |
| 1L9fYHJJxeLMD2yyhh1cMFU2EWF5ihgAmJ          | 40.035  | র্ব |
| 18eu6KrFgzv8yTMVvKJkRM3YBAyHLonk5G          | 30.00   | 1   |
| 1C8n86EEttnDjNKM9Tjm7QNVgwGBncQhDs          | 30.0082 | 2   |
| 12N7W9ycLhuck9Q2wT8E6BaN6XzZ4DMLau          | 0.00    | O   |
| 162DVnddxsbXeVgdCy66RxEPADPETBGVBR          | 0.00    | O   |
| 1ChnbV4Rt7nsb5acw5YfYyvBFDj1RXcVQu          | 28.00   | 2   |
| 1K6MBjz79QqfLBN7XBnwxCJb8DYUmmDWAt          | 1.7     | 2   |
| 1EoyVz2tbGXWL1sLZuCnSX72eR7Ju6qohH          | 0.00    | O   |
| 1NQ42zc51stA4WAVkUK8uqFAjo1DbWv4Kz          | 0.00    | O   |
| 15FC73BdkpDMUWmxo7e7gtLRtM8gQgXyb4          | 0.00    | O   |
| 14hVKm7Ft2rxDBFTNkkRC3kGstMGp2A4hk          | 10.00   | 2   |
| 1CN2iQbBikFK9jM34Nb3WLx5DCenQLnbXp          | 15.00   | 1   |
| 1LKULheYnNtJXgQNWMo24MeLrBBCouECH7          | 0.00    | O   |
| 15RLWdVnY5n1n7mTvU1zjg67wt86dhYqNj          | 50.41   | 3   |
| 1KURvApbe1yC7qYxkkvtdZ7hrNjdp18sQ           | 0.00    | O   |
| 1NuMXQMUxCngJ7MNQ276KdaXQgGjpjFPhK          | 10      | 1   |

#### Indicators

The following table contains the hashes of recently compiled Ryuk

|  |  | A "It II II lief |  |  |
|--|--|------------------|--|--|
|  |  |                  |  |  |
|  |  |                  |  |  |

Recent

Video

Category

Start Free Trial

795db7bdad1befdd3ad942be79715f6b0c5083d859901b81657b5

fe909d18cf0fde089594689f9a69fbc6d57b69291a09f3b9df1e9b

The following table contains hashes of Hermes executables that were previously analyzed:

SHA256

ac648d1ff695cf98993fa519803fa26cd43ec32a7a8713bfa34eb6

5e2c9ec5a108af92f177cabe23451d20e592ae54bb84265d1f972f

78c6042067216a5d47f4a338dd951848b122bbcbcd3e61290b2f7

#### Additional Resources

- o For more information on how to incorporate intelligence on dangerous threat actors into your security strategy, please visit the Falcon Intelligence product page.
- Read Stories from the front lines of incident response and get insights that can help inform your security strategy for 2019 in the CrowdStrike Services Cyber Intrusion Casebook 2018.
- o Test Falcon Prevent™ next-gen antivirus for yourself with a free 15-day trial today.

![](_page_14_Picture_12.jpeg)

![](_page_14_Picture_13.jpeg)

Featured

Recent

Video

Category

Start Free Trial

Related Content

Intelligence-Led Threat Hunting: The Key to Fighting Cross-Domain Attacks

![](_page_15_Picture_3.jpeg)

CrowdStrike 2025 Global Threat Report: Beware the Enterprising Adversary

![](_page_15_Picture_5.jpeg)

## Naming Names: How Adversary Taxonomies Strengthen Global Security

#### CATEGORIES

>

|     | Al & Machine Learning          | 27   |
|-----|--------------------------------|------|
|     | Cloud & Application Security   | 124  |
|     | Counter Adversary Operations   | 191  |
|     | Endpoint Security & XDR        | 311  |
|     | Engineering & Tech             | ದಿ   |
|     | Executive Viewpoint            | 167  |
|     | Exposure Management            | 94   |
|     | From The Front Lines           | 192  |
|     | Identity Protection            | 48   |
|     | Next-Gen SIEM & Log Management | 96   |
|     | Public Sector                  | বা ( |
| 000 | Small Business                 | 10   |

ՐՈՒՏՈՒՄԲՐT Ա/ԼԻԱ ԼԻ

Featured

Recent

Video

Category

![](_page_16_Picture_1.jpeg)

![](_page_16_Picture_2.jpeg)

# Get started with CrowdStrike for free.

![](_page_16_Picture_4.jpeg)

#### FEATURED ARTICLES

October 01, 2024

CrowdStrike Named a Leader in 2024 Gartner® Magic Quadrant™ for

Endpoint Protection Platforms

September 25, 2024

Featured

Recent

Video

Category

![](_page_16_Picture_15.jpeg)

![](_page_17_Picture_1.jpeg)

![](_page_17_Picture_2.jpeg)

## CROWDSTRIKE

![](_page_17_Picture_4.jpeg)

Copyright © 2025 CrowdStrike | Privacy | Request Info | Blog. | Contact Us | 1.888.512.8906 | Accessibility.