Home ( > News (

- > Security (
- > Ryuk Ransomware Uses Wake-on-Lan To Encrypt Offline Devices

# Ryuk Ransomware Uses Wake-on-Lan To Encrypt Offline Devices

By January 14, 2020 Lawrence Abrams (

![](_page_0_Picture_5.jpeg)

03:30 AM

5

The Ryuk Ransomware uses the Wake-on-Lan feature to turn on powered off devices on a compromised network to have greater success encrypting them.

Wake-on-Lan is a hardware feature that allows a powered down device to be woken up, or powered on, by sending a special network packet to it. This is useful for administrators who may need to push out updates to a computer or perform schedu

According to a recent analysis ( of the Ryuk Ransomware by Head of SentinelLabs Vitali Kremez ( when the malware is executed it will spawn subprocesses with the argument '8 LAN'.

![](_page_1_Picture_1.jpeg)

When this argument is used, Ryuk will scan the device's ARP table, which is a list of known IP addresses on the network and their associated mac addresses, and check if the entries are part of the private IP address subnets of "10.", "172.16.", and "192.168."

```
if ( u6 )
                                while ( 1 )
.
                                     sub_35004458( _ M0R0   * ) ( v                                                                                                                                                
00
                                       でもありませんが、
この他の人気がないと、
2017年08月20日 20:00:00 【送料無料】 2018/06/07 01:00 - 01:00:00 ~ 01:00:00 ~ 01:00:00 ~ 01:00:00 ~ 01
2 ~ 00:00:00 【 03:00:00 ~ 03:00 1
3 ~ 00:00:00 ~ 0 ~ 0 ~ 
. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . 
                                               _DWORD = ) ( บริ
 (   บ8   ) =   ( บ 8    ) =                                                                                                                                 
                                                                                         += HIDWORD(U8) + U9;
                                                                    BxFF )
       78
                                         else
ା ପ୍ରଭା
     79
                                          410 = BALE3(035);
                                                                                               Checking for private network
```
If the ARP entry is part of any of those networks, Ryuk will send a Wakeon-Lan (WoL) packet to the device's MAC address to have it power up. This WoL request comes in the form of a 'magic packet' containing 'FF FF FF FF FF FF FF FF'.

#### Ryuk sending a WoL packet

If the WoL request was successful, Ryuk will then attempt to mount the remote device's C\$ administrative share.

#### Mount drive to the Remote C\$ Share

If they can mount the share, Ryuk will encrypt that remote computer's drive as well.

In conversations with BleepingComputer, Kremez stated that this evolution in Ryuk's tactics allow a better reach in a compromised network from a single device and shows the Ryuk operator's skill traversing a corporate network.

"This is how the group adapted the network-wide ransomware model to affect more machines via the single infection and by reaching the machines via WOL & ARP," Kremez told BleepingComputer. "It allows for more reach and less isolation and demonstrates their experience dealing with large corporate environments."

To mitigate this new feature, administrators should only allow Wake-on-Lan packets from administrative devices and workstations.

This would allow administrators to still benefit from this feature while adding some security to the endpoints.

At the same time, this does not help if an administrative workstation is compromised, which happens quite often in targeted ransomware attacks.

Update 1/14/20 11:28 AM: CrowdStrike also has analysis of this feature here (

## Related Articles:

Kidney dialysis firm DaVita hit by weekend ransomware attack (

Ransomware attack cost IKEA operator in Eastern Europe \$23 million (

Sensata Technologies hit by ransomware attack impacting operations (

Microsoft: Windows CLFS zero-day exploited by ransomware gang (

New SuperBlack ransomware exploits Fortinet auth bypass flaws (

ARP (HTTPS://WWW.BLEEPINGCOMPUTER.COM/TAG/ARP/)

PACKET (HTTPS://WWW.BLEEPINGCOMPUTER.COM/TAG/PACKET/)

RANSOMWARE (HTTPS://WWW.BLEEPINGCOMPUTER.COM/TAG/RANSOMWARE/)

RYUK (HTTPS://WWW.BLEEPINGCOMPUTER.COM/TAG/RYUK/)

WAKE-ON-LAN (HTTPS://WWW.BLEEPINGCOMPUTER.COM/TAG/WAKE-ON-LAN/)

WOL (HTTPS://WWW.BLEEPINGCOMPUTER.COM/TAG/WOL/)

(

## LAWRENCE ABRAMS (HTTPS://WWW.BLEEPINGCOMPUTER.COM/AUTHOR/LAWRENCE-ABRAMS/)

![](_page_5_Picture_8.jpeg)

### (MAILTO:LAWRENCE.ABRAMS@BLEEPINGCOMPUTER.COM) \* (HTTPS://TWITTER.COM/LAWRENCEABRAMS)

Lawrence Abrams is the owner and Editor in Chief of BleepingComputer.com. Lawrence's area of expertise includes Windows, malware removal, and computer forensics. Lawrence Abrams is a co-author of the Winternals Defragmentation, Recovery, and Administration Field Guide and the technical editor for Rootkits for Dummies.

#### く PREVIOUS ARTICLE

NEXT ARTICLE >

#### Cdfbffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff

7-REACHES 995-05-OF-LIFE-NATIONS-TARGETED-WITH-( - 5 years ago TOMORROW-WHAT-YOU-NEED- EMOTET-MALWARE-PHISHING-

Terrifying how much criminal energy goes into the TO-KNOWEVelopment of RYUK ransomware. ATTACK/) Hello, i've found SEVERAL WAYS to recover Ryuk encrypted files. I would be glad if anyone could give me some sample because it could be useful in finding a way to calculate the key instead of just recovering files. This ransomware is so advanced (in terms of his code and process) that they forgot about some SIMPLE WINDOWS'S ENVIROMENTS things that are helpful in recovering files.

#### buddy215

( - 5 years ago

Other than using external backup copies of files encrypted on the computer....what other way have you found for "recovering" encrypted files other than decryting? Inquiring minds want to know.

#### Alovalovayea

( - 5 years ago

Just to tell you something, working on file history could let you recover everything on a company network. Every workstation can help you decrypt another workstation, but I can't give you details for now. Talking about any other method, would result on helping the hacker team behind ryuk and that's why I want to use my samples (and some more, If can get some) to calculate the key (it's not that difficult understanding how if you analyze the infection through a network sniffer on a sandbox)

#### Alovalovayea

( - 5 years ago

Sodinokibi (post August 2019 version) successfully decrypted thanks to a Facebook group who submitted samples. Ryuk's taking a bit more time but it's "vulnerable to the same method", could someone send samples?

| Post a Comment<br>Community Rules ( |  |
|------------------------------------------------------------------------------------------|--|
|                                                                                          |  |
| You need to login in order to post a comment                                             |  |

Login

 Not a member yet? Register Now ( app=core&module=global&section=register)

You may also like:

#### POPULAR STORIES

 SSL/TLS certificate lifespans reduced to 47 days by 2029

 (

### CISA extends funding to ensure 'no lapse in critical CVE services'

 (

### Infamous message board 4chan taken down following major hack

 ( message-board-4chan-takendown-following-major-hack/)

#### SPONSOR POSTS

Are Your Security Controls Working Right Now? Put Them to The Test with OnDefend's Validation Services. ( utm\_source=Bleeping+Computer&utm\_medium=sidebar&utm\_campaign=Ransomware+Defense+Validation)

Enhancing your DevSecOps with Wazuh, the open source XDR platform

( utm\_source=bleepingcomputer.com&utm\_medium=sidebar\_referral&utm\_campaign=wazuh\_bleepingcomputer) View your organization's attack surface & digital frauds - at no cost. Register now for CTM360's Community Edition

 ( utm\_source=bleepingcomputer.com&utm\_medium=sidebar&utm\_campaign=ctm360\_bleepingcomputer)

Overdue a password healthcheck? Audit your Active Directory for free ( utm\_source=bleepingcomputer&utm\_medium=referral&utm\_campaign=bleepingcomputer\_referral&utm\_content=article)

Rethinking Automated Penetration Testing: Why Validation Changes Everything ( utm\_campaign=7149959-

Red%20Report%202025&utm\_source=bleepingcomputer&utm\_content=blog)

#### FOLLOW US:

#### f 1 @ 0 7

## ( ) } } } } } {{ } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } } }

News (

VPN Buyer Guides (

SysAdmin Software Guides (

Downloads (

Virus Removal Guides (

Tutorials (

Startup Database (

Uninstall Database (

Glossary (

#### COMMUNITY

Forums ( Forum Rules ( Chat ( USEFUL RESOURCES

Welcome Guide ( Sitemap (

#### COMPANY

About BleepingComputer ( Contact Us ( Send us a Tip! ( Advertising ( Write for BleepingComputer ( Social & Feeds ( Changelog (

Terms of Use ( - Privacy Policy ( -Ethics Statement ( - Affiliate Disclosure (

Copyright @ 2003 - 2025 Bleeping Computer® LLC ( - All Rights Reserved