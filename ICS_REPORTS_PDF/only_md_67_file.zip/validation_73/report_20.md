#### Cybercrime

# BlackEnergy by the SSHBearDoor: attacks against Ukrainian news media and electric industry

The cybercriminal group behind BlackEnergy, the malware family that has been around since 2007 and has made a comeback in 2014, was also active in the year 2015.

![](_page_0_Picture_4.jpeg)

03 Jan 2016 , 6 min. read

![](_page_0_Picture_7.jpeg)

## Your account, your cookies choice

We and our partners use cookies to give you the best optimized online experience, analyze our website traffic, and serve you with personalized ads. You can agree to the collection of all cookies by clicking "Accept all and close" or adjust your cookie settings by clicking "Manage cookies". You also have the right to withdraw your consent to cookies anytime. For more information, please see our Cookie Policy.

Accept all and close

Manage cookies

Update: In case you want to have a more simplified version of this article, please check out BlackEnergy trojan strikes again: Attacks Ukrainian electric power industry.

The cybercriminal group behind BlackEnergy, the malware family that has been around since 2007 and has made a comeback in 2014 (see our previous blog posts on Back in BlackEnergy \*: 2014 Targeted Attacks in Ukraine and Poland and BlackEnergy PowerPoint Campaigns, as well as our Virus Bulletin talk on the subject), was also active in the year 2015.

ESET has recently discovered that the BlackEnergy trojan was recently used as a backdoor to deliver a destructive KillDisk component in attacks against Ukrainian news media companies and against the electrical power industry. In this blog, we provide details on the BlackEnergy samples ESET has detected in 2015, as well as the KillDisk components used in the attacks. Furthermore, we examine a previously unknown SSH backdoor that was also used as another channel of accessing the infected systems, in addition to BlackEnergy.

We continue to monitor the BlackEnergy malware operations for future developments. For any inquiries or to make sample submissions related to the subject, contact us at: threatintel@eset.com

## BlackEnergy evolution in 2015

Once activated, variants of BlackEnergy Lite allow a malware operator to check specific criteria in order to assess whether the infected computer truly belongs to the intended target. If that is the case, the dropper of a regular BlackEnergy variant is pushed to the system. The exact mechanism of infection by BlackEnergy is described in our Virus Bulletin

![](_page_1_Picture_6.jpeg)

## Your account, your cookies choice

ibedded in the binary of DLL

We and our partners use cookies to give you the best optimized online experience, analyze our website traffic, and serve you with personalized ads. You can agree to the collection of all cookies by clicking "Accept all and close" or adjust your cookie settings by clicking "Manage cookies". You also have the right to withdraw your consent to cookies anytime. For more information, please see our Cookie Policy.

ft/derstatus.php</addr>

KS081274.php</addr>

Apart from a list of C&C servers, the BlackEnergy config contains a value called build\_id. This value is a unique text string used to identify individual infections or infection attempts by the BlackEnergy malware operators. The combinations of letters and numbers used can sometimes reveal information about the campaign and targets.

Here is the list of Build ID values that we identified in 2015:

- ◎ 2015en ○ khm10 O khelm O 2015telsmi O 2015ts 0 2015stb O kiev o
- O brd2015

## Your account, your cookies choice

We and our partners use cookies to give you the best optimized online experience, analyze our website traffic, and serve you with personalized ads. You can agree to the collection of all cookies by clicking "Accept all and close" or adjust your cookie settings by clicking "Manage cookies". You also have the right to withdraw your consent to cookies anytime. For more information, please see our Cookie Policy.

r. For example 2015telsmi could macii, 2015en could mean

plugin designed for the

lactruction of the infoctod cuctom i

destruction of the intected System, named usti.

In 2015 the BlackEnergy group started to use a new destructive BlackEnergy component detected by ESET products as Win32/KillDisk.NBB, Win32/KillDisk.NBC and Win32/KillDisk.NBD trojan variants.

The main purpose of this component is to do damage to data stored on the computer: it overwrites documents with random data and makes the OS unbootable.

The first known case where the KillDisk component of BlackEnergy was used was documented by CERT-UA in November 2015. In that instance, a number of news media companies were attacked at the time of the 2015 Ukrainian local elections. The report claims that a large number of video materials and various documents were destroyed as a result of the attack.

It should be noted that the Win32/KillDisk.NBB variant used against media companies is more focused on destroying various types of files and documents. It has a long list of file extensions that it tries to overwrite and delete. The complete list contains more than 4000 file extensions.

unicode 0, <a.iuf.ivr.ivs.izz.izzy.jnv.jss.jts.jtv.k3g.kmv.lrec.lrv.l> unicode 0, <sf.lsx.lvix.m15.m1pg.m1v.m21.m21.m21.m2ts.m2v.m4e.m4u> unicode 0, <.m4v.m75.mani.meta.mgv.mj2.mjp.mjpg.mk3d.mkv.mnv.mnv.mob.> unicode 0, <mod.moff.moi.mov.mov.movie.mp21.mp21.mp2v.mp4.infovi> unicode 0, <d.mp4v.mpe.mpeg1.mpeg4.mpf.mpg.mpg2.mpgindex.mpl.mpl> unicode 0, <s.mpsub.mpv.mpv2.mqv.msdvd.msh.mswmm.mts.mtv.mvd.> unicode 0, <mve.moex.mop.my.my.mys.ncor.nut.nuv.nuc.nuv.nvc.ogm.ogv> unicode 0, <. ogx.orv.otrkey.par.pds.pgi.photoshow.piv.pjs.playlist.pl> unicode 0, <proj.pmF.pmv.ppj.prel.pro.pro4dvd.pro5dvd.progc.prproj.pr>

truction by KillDisk.NBB

![](_page_3_Picture_7.jpeg)

### Your account, your cookies choice

We and our partners use cookies to give you the best optimized online experience, analyze our website traffic, and serve you with personalized ads. You can agree to the collection of all cookies by clicking "Accept all and close" or adjust your cookie settings by clicking "Manage cookies". You also have the right to withdraw your consent to cookies anytime. For more information, please see our Cookie Policy.

oanies in Ukraine was slightly hanges made in the newest

delay when the destructive

System.

are targeted.

. unicode 0, <tx.tib.vhd.iso.lib.mdb.accdb.sq1.ndf.xml.rtf.ini.cfg.boot> unicode 0, <.txt.rar.msi.zip.jpg.bmp.jpeg.tiff>,0

Figure 3 – A list of file extensions targeted for destruction by new variant of KillDisk component

As well as being able to delete system files to make the system unbootable – functionality typical for such destructive trojans – the KillDisk variant detected in the electricity distribution companies also appears to contain some additional functionality specifically intended to sabotage industrial systems.

Once activated, this variant of the KillDisk component looks for and terminates two nonstandard processes with the following names:

- O komut.exe
- O sec service.exe

We didn't manage to find any information regarding the name of the first process (komut.exe).

The second process name may belong to software called ASEM Ubiquity, a software platform that is often used in Industrial control systems (ICS), or to ELTIMA Serial to Ethernet Connector. In case the process is found, the malware does not just terminate it, but also overwrites the executable file with random data.

![](_page_4_Picture_8.jpeg)

### Your account, your cookies choice

We and our partners use cookies to give you the best optimized online experience, analyze our website traffic, and serve you with personalized ads. You can agree to the collection of all cookies by clicking "Accept all and close" or adjust your cookie settings by clicking "Manage cookies". You also have the right to withdraw your consent to cookies anytime. For more information, please see our Cookie Policy.

ave discovered an interesting tion of one of the lance, appeared to be a

BS file with the following

opbear\" 6789", 0, false

port number 6789. By running

SSH on the server in a compromised network attackers can come back to the network

al ill of sellipletings ingerlailly blogs whenever they want.

However, for some reason this was not enough for them. After detailed analysis we discovered that the binary of the SSH server actually contains a backdoor.

![](_page_5_Picture_2.jpeg)

Figure 4 – Backdoored authentication function in SSH server

![](_page_5_Picture_4.jpeg)

We and our partners use cookies to give you the best optimized online experience, analyze our website traffic, and serve you with personalized ads. You can agree to the collection of all cookies by clicking "Accept all and close" or adjust your cookie settings by clicking "Manage cookies". You also have the right to withdraw your consent to cookies anytime. For more information, please see our Cookie Policy.

authenticate the user if the pplies to authentication by key and it allows authentication

![](_page_5_Picture_7.jpeg)

SSH server

)oor.A trojan.

## Indicators of Compromise (IoC)

IP addresses of BlackEnergy C2-servers:

5.149.254.114 5.9.32.230 31.210.111.154 88.198.25.92 146.0.74.7 188.40.8.72

XLS document with malicious macro SHA-1: AA67CA4FB712374F5301D1D2BAB0AC66107A4DF1

BlackEnergy Lite dropper SHA-1: 4C424D5C8CFFDF8D2164B9F833F7C631F94C5A4C

BlackEnergy Big dropper SHA-1: 896FCACFF6310BBE5335677E99E4C3D370F73D96

BlackEnergy drivers SHA-1:

069163E1FB606c6178E23066E0AC7B7F0E18506B 0B4BE96ADA3B54453BD37130087618EA90168D72 1A716BF5532C13FA0DC407D00ACDC4A457FA87CD 1A86F7EF10849DA7D36CA27D0C9B1D686768E177 1CBE4E22B034EE8EA8567E3F8EB9426B30D4AFFE 20001007670年5月20c720676550161766705で27

![](_page_6_Picture_8.jpeg)

## Your account, your cookies choice

E1C2B28E6A35AEADB508C60A9D09AB7B1041AFB8 E40F0D402FDCBA6DD7467C1366D040B02A44628C E5A2204F085C07250DA07D71CB4E48769328D7DC

#### KillDisk-components SHA-1:

16F44FAC7E8BC94ECCD7AD9692E6665EF540EEC4 8AD6F88C5813C2B4CD7ABAB1D6C056D95D6AC569 6D6BA221DA5B1AE1E910BBEAA07BD44AFF26A7C0 F3E41EB94C4D72A98CD743BBB02D248F510AD925

#### VBS/Agent.AD trojan SHA-1:

72D0B326410E1D0705281FDE83CB7C33C67BC8CA

#### Win32/SSHBearDoor.A trojan SHA-1:

166D71C63D0EB609C4F77499112965DB7D9A51BB

## Let us keep you up to date

Sign up for our newsletters

![](_page_7_Picture_9.jpeg)

## Your account, your cookies choice

#### Cybercrime

Don't let cybercriminals steal your Spotify account

#### Cybercrime

Don't become a statistic: Tips to help keep your personal data off the dark web

#### Cybercrime

Cybercriminals play dirty: A look back at 10 cyber hits on the sporting world

![](_page_8_Picture_6.jpeg)

### Your account, your cookies choice

![](_page_9_Picture_1.jpeg)

Legal Manage Information Cookies

RSS Feed

Copyright © ESET, All Rights Reserved

![](_page_10_Picture_2.jpeg)

## Your account, your cookies choice