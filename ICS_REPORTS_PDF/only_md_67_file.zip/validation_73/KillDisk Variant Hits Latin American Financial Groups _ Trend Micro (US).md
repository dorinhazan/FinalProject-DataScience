![](_page_0_Picture_0.jpeg)

#### Cyber Threats

# KillDisk Variant Hits Latin American Financial Groups

Trend Micro Research came across a new variant of the disk-wiping KillDisk targeting financial organizations in Latin America. Initial analysis reveals that it may be a component of another payload, or part of a bigger attack.

By: Gilbert Sison, Rheniel Ramos, Jay Yaneza, Alfredo Oliveira January 15, 2018 Read time: 4 min (959 words)

![](_page_0_Picture_7.jpeg)

Updated as of January 15, 11:58 PM PDT to clarify that the new variant of KillDisk we found does not have a ransom note.

We came across a new variant of the disk-wiping KillDisk targeting financial organizations in Latin America. Trend Micro detects it as TROJ\_KILLDISK.IUB. Trend Micro™ Deep Discovery™ proactively blocks any intrusions or attacks associated with this threat. Initial analysis (which is still ongoing) reveals that it may be a component of another payload, or part of a bigger attack. We are still analyzing this new KillDisk variant and we will update this post as we

aarsa dataila about this this this a

This website uses cookies for website functionality, traffic analytics, personalization, social media functionality and advertising. Our Cookie Notice provides more information and explains how to amend your cookie settings. Learn more

Cookies Settings

Accept

overwrites and deletes files (and don't store the encryption keys on disk or online), recovering the scrambled files was out of the question. The new variant we found, however, does not include a ransom note.

![](_page_1_Figure_3.jpeg)

Figure 1. KillDisk's infection chain

# How is it dropped in the system?

This KillDisk variant looks like it is intentionally dropped by another process/attacker. Its file path is hardcoded in the malware (c:\windows\dimens.exe), which means that it is tightly coupled with its installer or is a part of a bigger package.

> v5 = CommandLineToArgvW(v4, &pNumArgs); if / nNumAras == 9 \

This website uses cookies for website functionality, traffic analytics, personalization, social media functionality and advertising. Our Cookie Notice provides more information and explains how to amend your cookie settings. Learn more

Q

![](_page_2_Picture_0.jpeg)

KillDisk also has a self-destruct process, although it isn't really deleting itself. It renames its file to c:\windows\0123456789 while running. This string is hardcoded in the sample we analyzed. It expects its file path to be c:\windows\dimens.exe (also hardcoded). Accordingly, if disk forensics is performed and dimens.exe is searched, the file that will be retrieved will be the newly created file with 0x00 byte content.

## How does it delete files?

This new KillDisk variant goes through all logical drives (fixed and removable) starting from drive b:. If the logical drive contains the system directory, the files and folders in the following directories and subdirectories are exempted from deletion:

- · WINNT
- Users
- Windows
- Program Files
- · Program Files (x86)
- ProgramData
- · Recovery (case-sensitive check)
- · \$Recycle.Bin
- System Volume Information
- old
- · PerfLogs

```
Business
                                                                        Q
        v1 = 1pPathName,
      -
    }
    while ( FindNextFileA(hFindFile, &FindFileData) );
    result = (HANDLE)RemoveDirectoryA(UI);
result = CreateFileA(lpFileHame, ØxC0000000, 3u, 0, 0);
04 = result;
if ( result != (HANDLE)-1 )
く
 NumberOfBytesWritten = 0;
  05 = 10;
  do
  {
    WriteFile(v4, &unk_410BA8, 0x400u, &NumberOfBytesWritten, 0);
    -- 05 ;
  }
  while ( v5 );
  v6 = _ PAIR_((unsigned int)a3, a2) >> 1;
  DistanceToMoveHigh = __CFADD_(v6, 0xFFFFEC00) + ((unsigned int)a3 >> 1) - 1;
  SetFilePointer(v4, v6 - 0x1400, &DistanceToMoveHigh, 0);
  NumberOfBytesWritten = 0;
  07 = 10;
  do
  {
    WriteFile(v4, &unk_410BA8, 0x400u, &NumberOfBytesWritten, 0);
    --07;
  }
  while ( v7 );
  CloseHandle(v4);
  result = (HANDLE)DeleteFileA(lpFileName);
```
Figure 3. Code snippets showing how KillDisk overwrites then deletes files

## How does it wipe the disk?

The malware attempts to wipe \\.\PhysicalDrive0 to \\.\PhysicalDrive4. It reads the Master Boot Record (MBR) of every device it successfully opens and proceeds to overwrite the first 0x20 sectors of the device with "0x00". It uses the information from the MBR to do further damage to the partitions it linto If the normition it finala in as a so a

```
TUL.
 while ( v2 < 0x20 );
partitionentry = &PTE;
do
{
  RelativeSectors = *((_DWORD *)partitionentry + 2);
  TotalSectors = *({_DWORD *)partitionentry + 3);
  ppartitionentry = *(_DWORD *)partitionentry;
  systemID = *({_DWORD *)partitionentry + 1);
  v13 = systemID;
 v14 = _ PAIR_(TotalSectors, RelativeSectors);
if ( (_BYTE)systemID )
  ﻬ
   if ( (_BYTE)systemID == 0xF )
                                           // Extended partition using BIOS INT 13h extensions
   ﺗﻬ
     if ( overwriteextendedpart_401740(v1, (int)&ppartitionentry) )
       goto LABEL_3;
   }
   else
    く
      overwritestartofvol_401690((int)&ppartitionentry, v1);
    ﺮ
  }
                                           // point to next partition table entry
  partitionentry += 0x10;
  ++NumberOfBytesRead;
}
while ( (signed int)NumberOfBytesRead < 4 );
v2 = *(_DWORD *)(a1 + 8);
                                                  // Relative Sectors
if ( v2 < v2 + 0x10 )
ﮩ
  do
  く
    v5 = (unsigned ___int64)v2 << 9;
    if ( SetFilePointer(a2, v2 << 9, (PLONG)&v5 + 1, 0) == (_DWORD)v5 )
      WriteFile(a2, &unk_410BA8, 0x200u, &NumberOfBytesWritten, 0);
    ++v2;
  }
  while ( v2 < *(_DWORD *)(a1 + 8) + 0x10 );
>
v3 = *(_DWORD *)(a1 + 8xC) + *(_DWORD *)(a1 + 8) - 1;// thotal number of sectors
HIDWORD(v5) = (unsigned __int64)(unsigned int)v3 >> 0x17;
if ( SetFilePointer(a2, v3 << 9, (PLONG)&u5 + 1, 0) == u3 << 9 }// overwrite last sector
  WriteFile(a2, &unk_410BA8, 0x200u, &NumberOfBytesWritten, 0);
```
Figure 4. Code snippets showing how KillDisk reads/scans the MBR (top,

center), and overwrites the EBR (bottom)

## What happens after the MBR, files, and folders are overwritten and/or deleted?

KillDisk has a numeric parameter that denotes the number of minutes (15

This website uses cookies for website functionality, traffic analytics, personalization, social media functionality and advertising. Our Cookie Notice provides more information and explains how to amend your cookie settings. Learn more

Q

![](_page_5_Picture_0.jpeg)

· Local Security Authority Subsystem Service (Isass.exe)

This is done most likely to force a reboot or dupe the user into restarting the machine. Terminating csrss.exe and wininit.exe, for instance, will cause a blue screen of death (BSOD). Terminating winlogon.exe will prompt the user to log in again, while terminating lsass.exe will cause a reboot. KillDisk also uses the ExitWindowsEx function to forcefully restart the machine.

![](_page_5_Picture_4.jpeg)

### What can organizations do?

KillDisk's destructive capabilities, and how it could be just a part of a bigger attack, highlight the significance of defense in depth: securing the perimeters — from gateways, endpoints, and networks to servers — to further reduce the attack surface. Here are some best practices for organizations.

ronec une primupic of number privinge, necerrorin segmentument and auto categorization help prevent lateral movement and further exposure.

• Deploy security mechanisms such as application control/whitelisting and behavior monitoring, which can block suspicious programs from running and thwart anomalous system modifications.

Q

- · Proactively monitor the system and network; enable and employ firewalls as well as intrusion prevention and detection systems.
- Implement a managed incident response policy that will drive proactive remediation strategies; further strengthen the organization's security posture by cultivating a cybersecurity-aware workplace.

Trend Micro™ XGen™ security provides a cross-generational blend of threat defense techniques against a full range of threats for data centers, cloud environments, networks, and endpoints. It features high-fidelity machine learning to secure the gateway and endpoint data and applications, and protects physical, virtual, and cloud workloads. With capabilities like web/URL filtering, behavioral analysis, and custom sandboxing, XGen protects against today's purpose-built threats that bypass traditional controls and exploit known, unknown, or undisclosed vulnerabilities. Smart, optimized, and connected, XGen powers Trend Micro's suite of security solutions: Hybrid Cloud Security, User Protection, and Network Defense.

#### Related Hash (SHA-256):

#### • 8a81a1d0fae933862b51f63064069aa5af3854763f5edc29c997964de5e284e5 - TROJ\_KILLDISK.IUB

![](_page_7_Picture_0.jpeg)

Authors

Gilbert Sison Threats Analyst

Rheniel Ramos Threats Analyst

Jay Yaneza Director, MDR Operations

Alfredo Oliveira Sr. Security Researcher

#### CONTACT US

Strengthen Security with Cyber Risk Advisory

See all articles >

| Resources            | > |
|----------------------|---|
| Support              | > |
| About Trend          | > |
| Country Headquarters | > |

![](_page_8_Picture_6.jpeg)

Select a country / region

| United States |
|---------------|
|---------------|

![](_page_9_Picture_0.jpeg)

Q

Privacy Accessibility Legal

Terms of Use

Sitemap

Copyright ©2025 Trend Micro Incorporated. All rights reserved.