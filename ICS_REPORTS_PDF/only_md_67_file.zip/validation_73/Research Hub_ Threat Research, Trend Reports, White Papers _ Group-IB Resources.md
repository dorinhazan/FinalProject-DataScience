# High-Tech Crime Trends Report 2025

Group-IB's annual report delves into the most critical high-tech crime trends, offering a comprehensive analysis of emerging threats, tactics, and their impact on global security

![](_page_0_Picture_3.jpeg)

Learn more

## Research Hub

All Threat Research

Trend Report

Analytical Reports

White Papers

![](_page_1_Figure_0.jpeg)

![](_page_1_Picture_1.jpeg)

Intelligence Insights, February 2025

Explore the most notable cybersecurity events in the region and the best practices

Learn more

| Emerging Tech: 5 Elements to Prevent Digital<br>Commerce Friud<br>Tillehome NOA R-MUSEUR - '8 wis and<br>Actuals<br>Oserijalium in the Ballal strivierer fandissarring face suffishisted online fread<br>indhools. Podka listers mail nom product afferiria antians hissellintelligense account.<br>"Welcons buttress routin minitured collusion and proportions and schillions and effectively<br>comber color free<br>Cuerview<br>Kato Finalimia<br>"levels, howe and this verior beggents' seconds, Addresses ancerta, Addresses and Anglissess, Trans alon puns<br>Included pline free free for a lor processor of loudelers plus ind allorid would.<br>1 Aunura arthur matury atchround of the arrace bound router secure and the many to analy bout<br>institues inspection's anondrage in minumentantin of versually mater mation and creates and creative in<br>data varian stars and status and services and services and services and services and services and series and services and services and series and services and series and serv<br>A DISPANT DODGITA ATVO KNATHEREIDAN AVAUROVANIO PARKO USDAY<br>могу постали услу.<br>ithers/30/posts/loos/logs/organism and papers/lines/a/shorize/stations/response/selone book<br>and of the very E I I Mon's broanch 302 Jun responsibility procession in the normalian in be normal to laters in<br>4<br>Recommendediana<br>· Persons Box entrast research possible gover abilis for more as column on articular set-<br>improved summercial submundustriales aucellin marking marce Brolation mating<br>· Rodal Brider MAGNETLy VONDSORIA RESOLUTION BECOLOR BACKERS A BARRETARENSE STARTS STARTS SHOULD<br>MODER BE ROOF SOCIOST STRENT AND SHOUDER ENDAINS<br>· Person leaters hats show is incompressional worngenomi for infrastran'orolphon more the with assess<br>Imoma, Delectives Arighterra Radon's give wordtoni grade relocita wibrial andytis.<br>L'END AUDWOUT BACTURER SECTIVES CANDR BUSINESS PARKET PATRIESE PARTIEN PAT<br>mation accuses and and and to the Busans managelios/relative man formers and offer romanism<br>letemployers<br>BITH SHOUPENE D-M A DIECONDA CON-SE THE SCHIP ACCURES ACCISCENT ST CHICULAR<br>dent. Them advance and auction commend sumersions of these into financients and sections<br>answords hand programs af the moders of the mult matures askess coupling and quine and suries<br>loosed or acroponiand orestration or gramment markeds. Possmon, Ale knowlerger to elder hauf<br>promotive and other and station its from accommendom change of alsocient | Learn hous Curtear can | Garless | Demont or Desires and |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------|---------|-----------------------|
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         | beforem succeed.      |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |
|                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 |                        |         |                       |

## Analytical Report

Gartner® Report Emerging Tech: 5 Elements to Prevent Digital Commerce Fraud

The essential part of constructing a 'secure' digital commerce experience isn't just centered around...

Learn more

#### Trend Report

High-Tech Crime Trends Report 2025

Group-IB's annual report delves into the most critical high-tech crime trends, offering a comprehensive...

Learn more

## Trend Report

Intelligence Insights, North America – January 2025

Spotlighting critical cybercrime trends in North America and beyond.

Learn more

## Trend Report

Intelligence Insights, APAC - January 2025

Delve into critical shifts and emerging dangers in the Asia-Pacific (APAC) cyberthreat landscape with...

Intelligence Insights, META - January 2025

Uncover the Latest Cyber Threats and Trends. Stay informed and protect your organization with...

Learn more

## Trend Report

Intelligence Insights Europe – January 2025

Don't miss key cybersecurity events that affected the region, and get defenseequipped by exploring ...

Learn more

#### White Paper

Cybersecurity Ultimate Assessment Guide: Part 1. Assessment Compass

Navigate the complexities of modern assessments with Group-IB's expertdesigned guide.

Learn more

#### Trend Report

Intelligence Insights, APAC - December 2024

Explore the most notable cybersecurity events and best practices in the Asia-Pacific (APAC) region...

Learn more

## Trend Report

Intelligence Insights, META – December 2024

Explore the most notable cybersecurity events in the region and the best practices.

Learn more

## Trend Report

Intelligence Insights, LATAM – December 2024

Explore the most notable cybersecurity events in the region and the best practices.

Intelligence Insights, North America – December 2024

Explore the most notable cybersecurity events in the region and the best practices.

Learn more

## Analytical Report

IDC Spotlight: "The Weakest Link" — Email Security Should Be Your Top Cyberdefense Priority

Discover how to safeguard your organization against phishing, business email compromise attacks, and advanced...

Learn more

## Trend Report

Intelligence Insights -November 2024

Explore the most notable cybersecurity events in the region and the best practices.

![](_page_4_Picture_0.jpeg)

Adversary Hunting Code: Uncover and eliminate unknown cyber threats with Group-IB

Threats often lurk in the shadows, undetected, until they escalate into full-blown crises. The ...

Learn more

## Trend Report

Intelligence Insights, APAC – November 2024

Explore the most notable cybersecurity events in the Asia-Pacific (APAC) region from November 2024...

Learn more

## Trend Report

Intelligence Insights -October 2024

Explore the most notable cybersecurity events in the region and the best practices.

Learn more

## Trend Report

Intelligence Insights, APAC - October 2024

Explore the most notable cybersecurity events in the Asia-Pacific (APAC) region from October 2024...

Learn more

## Trend Report

Intelligence Insights -September 2024

Explore the most notable cybersecurity events in the META region and the best practices ...

Intelligence Insights -August 2024

Explore the most notable cybersecurity events in the META region and the best practices.

Learn more

## White Paper

CYBERSECURITY X AI: Building capabilities to defend assets and defeat attackers

There's no denying it: Artificial intelligence has emboldened and empowered cyber criminals, helping them...

Learn more

## Trend Report

Intelligence Insights -June 2024

Explore the most notable cybersecurity events in the META region and the best practices.

Learn more

## White Paper

Ransomware readiness: From quick wins to longterm strategies

Check all the key ransomware readiness boxes and shield your infrastructure with Group-IB's industryproven...

Learn more

## White Paper

The Reconnaissance Handbook: Map and mitigate intrusion pathways into your network

As adversaries use reconnaissance to plot their attacks against you, discover how you can...

Learn more

## Trend Report

Hi-Tech Crime Trends 2023/2024 – Global

Discover the Group-IB's annual threat research to discover the global cybersecurity landscape and get...

Hi-Tech Crime Trends 2023/2024 - Latin America

Discover Group-IB's unmatched annual report delivering valuable findings related to the Latin American region

Learn more

## Trend Report

Hi-Tech Crime Trends 2023/2024 - Middle East and Africa

Dive into Group-IB's comprehensive report sharing facts, data, findings, and our takes on these...

Learn more

## Trend Report

Hi-Tech Crime Trends 2023/2024 – Europe

Discover Group-IB's unparalleled annual report calibrated by the latest findings related to the European...

Learn more

## Trend Report

Hi-Tech Crime Trends 2023/2024 - Asia-Pacific

Discover Group-IB's unmatched annual report fine-tuned by the latest insights related to the Asia-Pacific ...

Learn more

## Trend Report

Hi-Tech Crime Trends 2023/2024 - North America

Explore Group-IB's unmatched annual report delivering actionable cybersecurity insights related to the North American ...

Learn more

## Analytical Report

Frost & Sullivan's 2023 Competitive Strategy Leadership Award

Gain unmatched localized cybersecurity with Group-IB's awardwinning decentralized model and tailored cyber-fraud framework.

The Art of SOC

Ultimate guide to establishing and evolving intelligencedriven security operations with Group-IB SOC Framework

Learn more

## Threat Research

W3LL done: uncovering hidden phishing ecosystem driving BEC attacks

Access untapped details into the scope and sophistication of the W3LL's BECfocused criminal enterprise

Learn more

## White Paper

Beyond OWASP Top 10: The ultimate guide to web application security (2023 and onwards)

Leverage the latest OWASP list combined with Group-IB experts' manual analysis techniques to identify,...

Digital Risk Trends 2023

Explore the most dangerous risks for brands and learn how to mitigate them

Learn more

#### Threat Research

Old Snake, New Skin: Analysis of SideWinder APT activity in 2021

Group-IB Threat Intelligence team uncovered a previously undocumented spear phishing campaign carried out by...

Learn more

Download report

## Trend Report

Hi-Tech Crime Trends 2022/2023

Benefit from Group-IB's flagship cybersecurity report and explore the current threat landscape trends and...

Learn more

Read report

The financial sector VS Fraud

Keep up with the biggest threats to the financial sector and learn how to...

Learn more

Download ebook

## Analytical Report

Threat Intelligence: Insights for pre-emptive strategies against cyber adversaries

Download a new Frost & Sullivan report to learn how to approach cybersecurity proactively...

Learn more

Download report

### Threat Research

OPERA1ER: Playing God Without Permission

The group relied solely on known "off-theshelf" tools to steal millions from financial service...

Learn more

OldGremlin Ransomware: Never Ever Feed Them after The Locknight

The case of OldGremlin illustrates how the ransomware industry has evolved in recent years....

#### Learn more

Download report

## White Paper

The 5 Step Guide to Making Your MDR More Efficient

Ultimate guide on how to optimize your managed detection and response offering and SOC...

Learn more

#### Threat Research

Demystifying Classiscam

Deep dive into where the scheme started, how it works and evolves. Learn more...

Learn more

Conti Armada: The ARMattack Campaign

Take a deep dive into "ARMattack", one of the shortest yet most successful campaigns...

Learn more

Download report

## Analytical Report

Aite-Novarica Group Named Group-IB the Largest and Most Experienced IRR Provider

The Aite-Novarica Group 2022 Incident Response Retainer Services report recognized Group-IB as one of...

Learn more

## Threat Research

Ransomware Uncovered 2021/2022

The well-known complete guide to the latest tactics, techniques, and procedures of ransomware operators...

Learn more

A Guide to Cyber Threats Targeting the Financial Sector

Learn why cyber threats are one of the biggest business risks for the financial...

#### Learn more

Download whitepaper

### Trend Report

Hi-Tech Crime Trends 2021/2022. Scams and Phishing: The Epidemic of Online Fraud

New fraud technologies & an analysis of schemes, tools and infrastructure

#### Learn more

Download report

#### Trend Report

Hi-Tech Crime Trends 2021/2022. Big Money: Threats to Financial Sector

A look at the cyber threat landscape: ransomware attacks, carding activity, network access sales,...

#### Learn more

Hi-Tech Crime Trends 2021/2022. Corporansom: Threat Number One

The history and analysis of affiliate programs and trends in the ransomware market.

#### Learn more

Download report

## Trend Report

Hi-Tech Crime Trends 2021/2022. Uninvited Guests: The Sale of Access to Corporate Networks

Analysis of dark web forums to understand the sale of access to compromised infrastructure.

#### Learn more

Download report

#### Threat Research

RedCurl: The Awakening

Commercial cyber espionage remains a rare and largely unique phenomenon. We cannot rule out,...

#### Learn more

## Analytical Report

Forrester: Group-IB TI Solution Generated Significant Return on Investment

Cost savings and business benefits enabled by Threat Intelligence & Attribution

#### Learn more

Download report

## Analytical Report

The Total Economic Impact™ of Group-IB Fraud Protection

Cost savings and business benefits enabled by Group-IB Fraud Protection (ex. Fraud Hunting Platform)

#### Learn more

Download report

## White Paper

#### Digital Risk Insights

The complete guide to the threat landscape in the digital space and latest techniques...

#### Learn more

Download whitepaper

The Easy First Step to Starting Your Zero Trust Journey

Learn how cybersecurity consulting can put you on the path to realizing Zero Trust ...

Learn more

Download whitepaper

## Analytical Report

Group-IB Is Recognized by Frost & Sullivan As a Leader on The Cyber Threat Intelligence Market

A benchmarking system to Spark Companies to action - innovation that fuels new deal...

Learn more

Download report

## Threat Research

Ransomware Uncovered 2020/2021

The complete guide to the latest tactics, techniques, and procedures of ransomware operators based ...

Learn more

Download report

## Trend Report

Hi-Tech Crime Trends 2020/2021

Source of strategic data on the global cyber threat landscape and forecasts for its...

Learn more

View report

## Analytical Report

Frost & Sullivan recognized Group-IB as a leader in Digital Risk Protection

Frost & Sullivan recognized Group-IB as a leader in Digital Risk Protection

#### Learn more

Download report

## White Paper

Egregor Ransomware: The Legacy of Maze Lives On

The new gang may be young, but it is already doing serious damage

l earn more

Lock like a Pro: How Qakbot Fuels Enterprise Ransomware Campaigns

Group-IB alerted the world to ProLock. Now, it's exposing the threat actor further.

#### Learn more

Download report

## Threat Research

UltraRank: The Unexpected Twist of a JS-Sniffer Triple Threat

New stage in JS-sniffers research. From analyzing malware families to identifying threat actors

#### Learn more

Download report

### Threat Research

RedCurl: The Pentest You Didn't Know About

The APT group continues to successfully attack enterprise companies in North America, Europe, and...

Learn more

View report

#### Threat Research

Jolly Roger's Patrons

Group-IB exposes financial crime network of online pirates in developing countries

Learn more

Download report

#### Threat Research

Fxmsp: "The Invisible God of Networks"

The report shows how Fxmsp's cybercriminal career evolved from a newbie hacker to one...

Learn more

Download report

## Analytical Report

Leadership Compass "Network Detection and Response"

KuppingerCole Analysts AG Names Group-IB a Product Leader for Managed XDR

Learn more

View report

The Possibilities of Mobile Forensics: Extraction, Investigation, and Crime Solving

A forensic expert's guide to the latest methods of extracting data from mobile devices.

#### Learn more

Download whitepaper

## Trend Report

Hi-Tech Crime Trends 2019/2020

A single comprehensive source of strategic data on cyberthreats and reliable forecasts of their...

#### Learn more

View report

## White Paper

Ransomware Uncovered 2019: Attackers' Latest Methods

The complete guide to the TTPs used by ransomware operators in 2019

Learn more

Download whitepaper

Cybersecurity Challenges to Pharmaceutical Brands in 2019

Learn what methods criminals use to abuse pharmaceutical brands and popular drugs and distribute ...

#### Learn more

Download whitepaper

## Threat Research

Silence 2.0: Going Global

A comprehensive technical analysis of Silence's tools, tactics, and evolution. This is the first...

#### Learn more

View report

## Threat Research

Crime Without Punishment: In-depth Analysis of JS-Sniffers

JS-sniffers pose a growing threat by attacking online stores and stealing payment data and...

Learn more

View report

## White Paper

Relevant Cyberthreats to Perfume Brands in 2019

The scent of fraud. Learn how threat actors are stealing the names and reputations ...

#### Learn more

Download whitepaper

## Trend Report

Hi-Tech Crime Trends 2018

Group-IB annual report on cybercrime trends

Learn more

View report

## White Paper

The Evolution of Ransomware And Its Distribution Methods in 2018

Ransomware attacks were still on the rise in 2018. Some of them became more...

#### Learn more

Download whitepaper

Silence: Moving Into The Darkside

The first detailed report on the tactics and tools used by Silence

Learn more

View report

## Threat Research

2018 Cryptocurrency Exchanges. User Accounts Leaks Analysis

Estimation of the number of login and passwords leaks of cryptocurrency exchanges users and...

Learn more

View report

## Threat Research

Lazarus Arisen: Architecture, Tools and Attribution

The only in-depth report outlining multiple layers of Lazarus infrastructure, thorough analysis of hacker's...

Learn more

View report

Cobalt: Their Evolution And Joint Operations

Learn about Cobalt's development and modification of tools and tactics which were used to...

Learn more

View report

#### White Paper

Red Teaming: The Tactics and Methods Involved in Full-Scale Attack Simulations

So what is the difference between a pentest and Red Teaming? Find out this...

#### Learn more

Download whitepaper

#### White Paper

Analysis of The Counterfeit Goods Market Infringing on Sports Brands

This report contains the results of Group-IB Digital Risk Protection's study into the counterfeit...

#### Learn more

Download whitepaper

eDiscovery: Basics, Methods and Techniques of Strategic Digital Evidence Management

Learn about the delicate process of collecting, processing, and analyzing digital evidence so that...

#### Learn more

Download whitepaper

## White Paper

Internet Distribution of Counterfeit Alcohol 2017-2018

Investigation of counterfeit alcohol market in Russia

#### Learn more

Download whitepaper

## Trend Report

Hi-Tech Crime Trends 2017

Group-IB annual report on cybercrime trends

Learn more

View report

## Threat Research

MoneyTaker: Revealed After 1.5 Years of Silent Operations

Explore how this group managed to hide their traces while conducting 20+ attacks on...

Learn more

View report

## Threat Research

Cobalt: Logical Attacks on ATMs

Report outlining activity of the Cobalt hacker group attacking banks in Europe and Asia

Learn more

View report

## Trend Report

Hi-Tech Crime Trends 2016

Group-IB annual report on cybercrime trends

Learn more

View report

Buhtrap: The Evolution of Targeted Attacks Against Financial Institutions

The report outlines the activity of the most dangerous and comprehensive cybercriminal group attacking...

#### Learn more

View report

## Threat Research

Analysis of Attacks Against Trading and Bank Card System

Group-IB annual report on speculative fluctuations of exchange rate and other incidents in 2015 ...

#### Learn more

View report

## Threat Research

Anunak: APT Against Financial Institutions

This research includes the findings of Group-IB and Fox-IT on Anunak (Carbanak) group, which...

Learn more

Learn more

Load more

Subscribe to stay up to date with the latest cyber threat trends

#### Products

| Threat Intelligence       | Research Hub       |
|---------------------------|--------------------|
| Fraud Protection          | Success Stories    |
| Managed XDR               | Knowledge Hub      |
| Attack Surface Management | Certificates       |
|                           | Webinars           |
| Digital Risk Protection   | TOP Investigations |
| Business Email Protection | Ransomware Notes   |
| Unified Risk Platform     |                    |
|                           |                    |

## Partners

Integrations

| Partner Program      |
|----------------------|
| MSSP and MDR Partner |
| Program              |
| Technology Partners  |
| Partner Locator      |

## Company

Resources

About Group-IB Team CERT-GIB Careers Internship Media Center Contact

Subscription plans

Services

| Contact                   | Subscribe to stay up to date with the<br>latest cyber threat trends |
|---------------------------|---------------------------------------------------------------------|
| APAC: +65 3159 3798       |                                                                     |
| EU & NA: +31 20 226 90 90 |                                                                     |
| MEA: +971 4 508 1605      |                                                                     |
|                           |                                                                     |
| info@group-ib.com         |                                                                     |
|                           |                                                                     |
|                           |                                                                     |
|                           |                                                                     |

© 2003 – 2025 Group-IB is a global leader in the fight against cybercrime, protecting customers around the world by preventing breaches, eliminating fraud and protecting brands.

Terms of Use Cookie Policy Privacy Policy